gdjs.PrototypeCannonBlockCode = {};
gdjs.PrototypeCannonBlockCode.forEachIndex2 = 0;

gdjs.PrototypeCannonBlockCode.forEachIndex4 = 0;

gdjs.PrototypeCannonBlockCode.forEachObjects2 = [];

gdjs.PrototypeCannonBlockCode.forEachObjects4 = [];

gdjs.PrototypeCannonBlockCode.forEachTemporary2 = null;

gdjs.PrototypeCannonBlockCode.forEachTemporary4 = null;

gdjs.PrototypeCannonBlockCode.forEachTotalCount2 = 0;

gdjs.PrototypeCannonBlockCode.forEachTotalCount4 = 0;

gdjs.PrototypeCannonBlockCode.GDBulletObjects1= [];
gdjs.PrototypeCannonBlockCode.GDBulletObjects2= [];
gdjs.PrototypeCannonBlockCode.GDBulletObjects3= [];
gdjs.PrototypeCannonBlockCode.GDBulletObjects4= [];
gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects1= [];
gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects2= [];
gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects3= [];
gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects4= [];
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1= [];
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects2= [];
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects3= [];
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4= [];
gdjs.PrototypeCannonBlockCode.GDtileBackgroungObjects1= [];
gdjs.PrototypeCannonBlockCode.GDtileBackgroungObjects2= [];
gdjs.PrototypeCannonBlockCode.GDtileBackgroungObjects3= [];
gdjs.PrototypeCannonBlockCode.GDtileBackgroungObjects4= [];

gdjs.PrototypeCannonBlockCode.conditionTrue_0 = {val:false};
gdjs.PrototypeCannonBlockCode.condition0IsTrue_0 = {val:false};
gdjs.PrototypeCannonBlockCode.condition1IsTrue_0 = {val:false};


gdjs.PrototypeCannonBlockCode.eventsList0 = function(runtimeScene) {

};gdjs.PrototypeCannonBlockCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.PrototypeCannonBlockCode.GDCannonAimObjects3);

for(gdjs.PrototypeCannonBlockCode.forEachIndex4 = 0;gdjs.PrototypeCannonBlockCode.forEachIndex4 < gdjs.PrototypeCannonBlockCode.GDCannonAimObjects3.length;++gdjs.PrototypeCannonBlockCode.forEachIndex4) {
gdjs.copyArray(gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects2, gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects4);

gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4.length = 0;


gdjs.PrototypeCannonBlockCode.forEachTemporary4 = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects3[gdjs.PrototypeCannonBlockCode.forEachIndex4];
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4.push(gdjs.PrototypeCannonBlockCode.forEachTemporary4);
gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4[i].getVariableNumber(gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4[i].getVariables().get("ID")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects4[0].getVariables()).getFromIndex(0))) ) {
        gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = true;
        gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4[k] = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4.length = k;}if (gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4[i].setCenterPositionInScene((( gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects4.length === 0 ) ? 0 :gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects4[0].getCenterXInScene()),(( gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects4.length === 0 ) ? 0 :gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects4[0].getCenterYInScene()));
}
}}
}

}


};gdjs.PrototypeCannonBlockCode.eventsList2 = function(runtimeScene) {

{

/* Reuse gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1 */

gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length;i<l;++i) {
    if ( gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].getAngle() <= (gdjs.RuntimeObject.getVariableNumber(gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].getVariables().getFromIndex(0))) ) {
        gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = true;
        gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[k] = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i];
        ++k;
    }
}
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length = k;}if (gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1 */
{for(var i = 0, len = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length ;i < len;++i) {
    gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].setAngle((gdjs.RuntimeObject.getVariableNumber(gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].getVariables().getFromIndex(0))));
}
}}

}


};gdjs.PrototypeCannonBlockCode.eventsList3 = function(runtimeScene) {

{

/* Reuse gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1 */

gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length;i<l;++i) {
    if ( gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].getAngle() >= (gdjs.RuntimeObject.getVariableNumber(gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].getVariables().getFromIndex(1))) ) {
        gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = true;
        gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[k] = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i];
        ++k;
    }
}
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length = k;}if (gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1 */
{for(var i = 0, len = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length ;i < len;++i) {
    gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].setAngle((gdjs.RuntimeObject.getVariableNumber(gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].getVariables().getFromIndex(1))));
}
}}

}


};gdjs.PrototypeCannonBlockCode.mapOfGDgdjs_46PrototypeCannonBlockCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.PrototypeCannonBlockCode.GDBulletObjects2});gdjs.PrototypeCannonBlockCode.eventsList4 = function(runtimeScene) {

};gdjs.PrototypeCannonBlockCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1);

for(gdjs.PrototypeCannonBlockCode.forEachIndex2 = 0;gdjs.PrototypeCannonBlockCode.forEachIndex2 < gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length;++gdjs.PrototypeCannonBlockCode.forEachIndex2) {
gdjs.PrototypeCannonBlockCode.GDBulletObjects2.length = 0;

gdjs.PrototypeCannonBlockCode.GDCannonAimObjects2.length = 0;


gdjs.PrototypeCannonBlockCode.forEachTemporary2 = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[gdjs.PrototypeCannonBlockCode.forEachIndex2];
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects2.push(gdjs.PrototypeCannonBlockCode.forEachTemporary2);
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PrototypeCannonBlockCode.mapOfGDgdjs_46PrototypeCannonBlockCode_46GDBulletObjects2Objects, (( gdjs.PrototypeCannonBlockCode.GDCannonAimObjects2.length === 0 ) ? 0 :gdjs.PrototypeCannonBlockCode.GDCannonAimObjects2[0].getCenterXInScene()), (( gdjs.PrototypeCannonBlockCode.GDCannonAimObjects2.length === 0 ) ? 0 :gdjs.PrototypeCannonBlockCode.GDCannonAimObjects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.PrototypeCannonBlockCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.PrototypeCannonBlockCode.GDBulletObjects2[i].getBehavior("Physics2").applyPolarForce((( gdjs.PrototypeCannonBlockCode.GDCannonAimObjects2.length === 0 ) ? 0 :gdjs.PrototypeCannonBlockCode.GDCannonAimObjects2[0].getAngle()), 2, 1, 1);
}
}}
}

}


};gdjs.PrototypeCannonBlockCode.mapOfGDgdjs_46PrototypeCannonBlockCode_46GDBlockCannonObjects1Objects = Hashtable.newFrom({"BlockCannon": gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects1});gdjs.PrototypeCannonBlockCode.mapOfGDgdjs_46PrototypeCannonBlockCode_46GDCannonAimObjects1Objects = Hashtable.newFrom({"CannonAim": gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1});gdjs.PrototypeCannonBlockCode.eventsList6 = function(runtimeScene) {

{


{
gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects1.length = 0;

gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PrototypeCannonBlockCode.mapOfGDgdjs_46PrototypeCannonBlockCode_46GDBlockCannonObjects1Objects, gdjs.random(300), gdjs.random(300), "");
}{for(var i = 0, len = gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects1.length ;i < len;++i) {
    gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects1[i].returnVariable(gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects1[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PrototypeCannonBlockCode.mapOfGDgdjs_46PrototypeCannonBlockCode_46GDCannonAimObjects1Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length ;i < len;++i) {
    gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].setZOrder(gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].getZOrder() + (1));
}
}{for(var i = 0, len = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length ;i < len;++i) {
    gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].returnVariable(gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].getVariables().get("ID")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}}

}


};gdjs.PrototypeCannonBlockCode.eventsList7 = function(runtimeScene) {

{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects1);

for(gdjs.PrototypeCannonBlockCode.forEachIndex2 = 0;gdjs.PrototypeCannonBlockCode.forEachIndex2 < gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects1.length;++gdjs.PrototypeCannonBlockCode.forEachIndex2) {
gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects2.length = 0;


gdjs.PrototypeCannonBlockCode.forEachTemporary2 = gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects1[gdjs.PrototypeCannonBlockCode.forEachIndex2];
gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects2.push(gdjs.PrototypeCannonBlockCode.forEachTemporary2);
if (true) {

{ //Subevents: 
gdjs.PrototypeCannonBlockCode.eventsList1(runtimeScene);} //Subevents end.
}
}

}


{


gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = false;
{
gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1);
{for(var i = 0, len = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length ;i < len;++i) {
    gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].rotate(-(100), runtimeScene);
}
}
{ //Subevents
gdjs.PrototypeCannonBlockCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = false;
{
gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1);
{for(var i = 0, len = gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length ;i < len;++i) {
    gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1[i].rotate(100, runtimeScene);
}
}
{ //Subevents
gdjs.PrototypeCannonBlockCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = false;
{
gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
}if (gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.PrototypeCannonBlockCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = false;
{
gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "c");
}if (gdjs.PrototypeCannonBlockCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.PrototypeCannonBlockCode.eventsList6(runtimeScene);} //End of subevents
}

}


};

gdjs.PrototypeCannonBlockCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PrototypeCannonBlockCode.GDBulletObjects1.length = 0;
gdjs.PrototypeCannonBlockCode.GDBulletObjects2.length = 0;
gdjs.PrototypeCannonBlockCode.GDBulletObjects3.length = 0;
gdjs.PrototypeCannonBlockCode.GDBulletObjects4.length = 0;
gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects1.length = 0;
gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects2.length = 0;
gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects3.length = 0;
gdjs.PrototypeCannonBlockCode.GDBlockCannonObjects4.length = 0;
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects1.length = 0;
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects2.length = 0;
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects3.length = 0;
gdjs.PrototypeCannonBlockCode.GDCannonAimObjects4.length = 0;
gdjs.PrototypeCannonBlockCode.GDtileBackgroungObjects1.length = 0;
gdjs.PrototypeCannonBlockCode.GDtileBackgroungObjects2.length = 0;
gdjs.PrototypeCannonBlockCode.GDtileBackgroungObjects3.length = 0;
gdjs.PrototypeCannonBlockCode.GDtileBackgroungObjects4.length = 0;

gdjs.PrototypeCannonBlockCode.eventsList7(runtimeScene);
return;

}

gdjs['PrototypeCannonBlockCode'] = gdjs.PrototypeCannonBlockCode;
