gdjs.MainMenuCode = {};
gdjs.MainMenuCode.GDBulletObjects1= [];
gdjs.MainMenuCode.GDBulletObjects2= [];
gdjs.MainMenuCode.GDBulletObjects3= [];
gdjs.MainMenuCode.GDBlockCannonObjects1= [];
gdjs.MainMenuCode.GDBlockCannonObjects2= [];
gdjs.MainMenuCode.GDBlockCannonObjects3= [];
gdjs.MainMenuCode.GDCannonAimObjects1= [];
gdjs.MainMenuCode.GDCannonAimObjects2= [];
gdjs.MainMenuCode.GDCannonAimObjects3= [];
gdjs.MainMenuCode.GDtileBackgroungObjects1= [];
gdjs.MainMenuCode.GDtileBackgroungObjects2= [];
gdjs.MainMenuCode.GDtileBackgroungObjects3= [];
gdjs.MainMenuCode.GDButtonObjects1= [];
gdjs.MainMenuCode.GDButtonObjects2= [];
gdjs.MainMenuCode.GDButtonObjects3= [];
gdjs.MainMenuCode.GDPlayIconObjects1= [];
gdjs.MainMenuCode.GDPlayIconObjects2= [];
gdjs.MainMenuCode.GDPlayIconObjects3= [];
gdjs.MainMenuCode.GDCreditsObjects1= [];
gdjs.MainMenuCode.GDCreditsObjects2= [];
gdjs.MainMenuCode.GDCreditsObjects3= [];
gdjs.MainMenuCode.GDTutorialIconObjects1= [];
gdjs.MainMenuCode.GDTutorialIconObjects2= [];
gdjs.MainMenuCode.GDTutorialIconObjects3= [];
gdjs.MainMenuCode.GDTitleObjects1= [];
gdjs.MainMenuCode.GDTitleObjects2= [];
gdjs.MainMenuCode.GDTitleObjects3= [];
gdjs.MainMenuCode.GDPlayer2Objects1= [];
gdjs.MainMenuCode.GDPlayer2Objects2= [];
gdjs.MainMenuCode.GDPlayer2Objects3= [];
gdjs.MainMenuCode.GDPlayer1Objects1= [];
gdjs.MainMenuCode.GDPlayer1Objects2= [];
gdjs.MainMenuCode.GDPlayer1Objects3= [];
gdjs.MainMenuCode.GDNewObjectObjects1= [];
gdjs.MainMenuCode.GDNewObjectObjects2= [];
gdjs.MainMenuCode.GDNewObjectObjects3= [];
gdjs.MainMenuCode.GDNewObject2Objects1= [];
gdjs.MainMenuCode.GDNewObject2Objects2= [];
gdjs.MainMenuCode.GDNewObject2Objects3= [];
gdjs.MainMenuCode.GDAObjects1= [];
gdjs.MainMenuCode.GDAObjects2= [];
gdjs.MainMenuCode.GDAObjects3= [];
gdjs.MainMenuCode.GDWObjects1= [];
gdjs.MainMenuCode.GDWObjects2= [];
gdjs.MainMenuCode.GDWObjects3= [];
gdjs.MainMenuCode.GDSObjects1= [];
gdjs.MainMenuCode.GDSObjects2= [];
gdjs.MainMenuCode.GDSObjects3= [];
gdjs.MainMenuCode.GDDObjects1= [];
gdjs.MainMenuCode.GDDObjects2= [];
gdjs.MainMenuCode.GDDObjects3= [];
gdjs.MainMenuCode.GDArrowObjects1= [];
gdjs.MainMenuCode.GDArrowObjects2= [];
gdjs.MainMenuCode.GDArrowObjects3= [];

gdjs.MainMenuCode.conditionTrue_0 = {val:false};
gdjs.MainMenuCode.condition0IsTrue_0 = {val:false};
gdjs.MainMenuCode.condition1IsTrue_0 = {val:false};
gdjs.MainMenuCode.condition2IsTrue_0 = {val:false};


gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDButtonObjects1Objects = Hashtable.newFrom({"Button": gdjs.MainMenuCode.GDButtonObjects1});gdjs.MainMenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainMenuCode.GDButtonObjects1, gdjs.MainMenuCode.GDButtonObjects2);


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDButtonObjects2.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDButtonObjects2[i].getVariableString(gdjs.MainMenuCode.GDButtonObjects2[i].getVariables().getFromIndex(0)) == "Play" ) {
        gdjs.MainMenuCode.condition0IsTrue_0.val = true;
        gdjs.MainMenuCode.GDButtonObjects2[k] = gdjs.MainMenuCode.GDButtonObjects2[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDButtonObjects2.length = k;}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Battle", false);
}}

}


{

gdjs.copyArray(gdjs.MainMenuCode.GDButtonObjects1, gdjs.MainMenuCode.GDButtonObjects2);


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDButtonObjects2.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDButtonObjects2[i].getVariableString(gdjs.MainMenuCode.GDButtonObjects2[i].getVariables().getFromIndex(0)) == "Credits" ) {
        gdjs.MainMenuCode.condition0IsTrue_0.val = true;
        gdjs.MainMenuCode.GDButtonObjects2[k] = gdjs.MainMenuCode.GDButtonObjects2[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDButtonObjects2.length = k;}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Credits", false);
}}

}


{

/* Reuse gdjs.MainMenuCode.GDButtonObjects1 */

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDButtonObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDButtonObjects1[i].getVariableString(gdjs.MainMenuCode.GDButtonObjects1[i].getVariables().getFromIndex(0)) == "Tutorial" ) {
        gdjs.MainMenuCode.condition0IsTrue_0.val = true;
        gdjs.MainMenuCode.GDButtonObjects1[k] = gdjs.MainMenuCode.GDButtonObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDButtonObjects1.length = k;}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}

}


};gdjs.MainMenuCode.eventsList1 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\block-break.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\block-break.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\bullet-hit.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\core-damage.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\game-over.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\select-block.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\shoot.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\game-over.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\music\\Frantic-Gameplay_v001.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\music\\Blissful-Trance.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\music\\Friendly-Machines.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\music\\Techno-Celebration-Looping.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\music\\the-executive-lounge-dan-barton-main-version-01-00-8850.mp3");
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "assets\\sound\\music\\Blissful-Trance.mp3", 1, false, 20, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button"), gdjs.MainMenuCode.GDButtonObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
gdjs.MainMenuCode.condition1IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.MainMenuCode.condition0IsTrue_0.val ) {
{
gdjs.MainMenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDButtonObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.MainMenuCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.MainMenuCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.MainMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainMenuCode.GDBulletObjects1.length = 0;
gdjs.MainMenuCode.GDBulletObjects2.length = 0;
gdjs.MainMenuCode.GDBulletObjects3.length = 0;
gdjs.MainMenuCode.GDBlockCannonObjects1.length = 0;
gdjs.MainMenuCode.GDBlockCannonObjects2.length = 0;
gdjs.MainMenuCode.GDBlockCannonObjects3.length = 0;
gdjs.MainMenuCode.GDCannonAimObjects1.length = 0;
gdjs.MainMenuCode.GDCannonAimObjects2.length = 0;
gdjs.MainMenuCode.GDCannonAimObjects3.length = 0;
gdjs.MainMenuCode.GDtileBackgroungObjects1.length = 0;
gdjs.MainMenuCode.GDtileBackgroungObjects2.length = 0;
gdjs.MainMenuCode.GDtileBackgroungObjects3.length = 0;
gdjs.MainMenuCode.GDButtonObjects1.length = 0;
gdjs.MainMenuCode.GDButtonObjects2.length = 0;
gdjs.MainMenuCode.GDButtonObjects3.length = 0;
gdjs.MainMenuCode.GDPlayIconObjects1.length = 0;
gdjs.MainMenuCode.GDPlayIconObjects2.length = 0;
gdjs.MainMenuCode.GDPlayIconObjects3.length = 0;
gdjs.MainMenuCode.GDCreditsObjects1.length = 0;
gdjs.MainMenuCode.GDCreditsObjects2.length = 0;
gdjs.MainMenuCode.GDCreditsObjects3.length = 0;
gdjs.MainMenuCode.GDTutorialIconObjects1.length = 0;
gdjs.MainMenuCode.GDTutorialIconObjects2.length = 0;
gdjs.MainMenuCode.GDTutorialIconObjects3.length = 0;
gdjs.MainMenuCode.GDTitleObjects1.length = 0;
gdjs.MainMenuCode.GDTitleObjects2.length = 0;
gdjs.MainMenuCode.GDTitleObjects3.length = 0;
gdjs.MainMenuCode.GDPlayer2Objects1.length = 0;
gdjs.MainMenuCode.GDPlayer2Objects2.length = 0;
gdjs.MainMenuCode.GDPlayer2Objects3.length = 0;
gdjs.MainMenuCode.GDPlayer1Objects1.length = 0;
gdjs.MainMenuCode.GDPlayer1Objects2.length = 0;
gdjs.MainMenuCode.GDPlayer1Objects3.length = 0;
gdjs.MainMenuCode.GDNewObjectObjects1.length = 0;
gdjs.MainMenuCode.GDNewObjectObjects2.length = 0;
gdjs.MainMenuCode.GDNewObjectObjects3.length = 0;
gdjs.MainMenuCode.GDNewObject2Objects1.length = 0;
gdjs.MainMenuCode.GDNewObject2Objects2.length = 0;
gdjs.MainMenuCode.GDNewObject2Objects3.length = 0;
gdjs.MainMenuCode.GDAObjects1.length = 0;
gdjs.MainMenuCode.GDAObjects2.length = 0;
gdjs.MainMenuCode.GDAObjects3.length = 0;
gdjs.MainMenuCode.GDWObjects1.length = 0;
gdjs.MainMenuCode.GDWObjects2.length = 0;
gdjs.MainMenuCode.GDWObjects3.length = 0;
gdjs.MainMenuCode.GDSObjects1.length = 0;
gdjs.MainMenuCode.GDSObjects2.length = 0;
gdjs.MainMenuCode.GDSObjects3.length = 0;
gdjs.MainMenuCode.GDDObjects1.length = 0;
gdjs.MainMenuCode.GDDObjects2.length = 0;
gdjs.MainMenuCode.GDDObjects3.length = 0;
gdjs.MainMenuCode.GDArrowObjects1.length = 0;
gdjs.MainMenuCode.GDArrowObjects2.length = 0;
gdjs.MainMenuCode.GDArrowObjects3.length = 0;

gdjs.MainMenuCode.eventsList1(runtimeScene);
return;

}

gdjs['MainMenuCode'] = gdjs.MainMenuCode;
