gdjs.MainMenuCode = {};
gdjs.MainMenuCode.GDButtonPlayObjects1_1final = [];

gdjs.MainMenuCode.GDGameTitleObjects1_1final = [];

gdjs.MainMenuCode.GDBulletObjects1= [];
gdjs.MainMenuCode.GDBulletObjects2= [];
gdjs.MainMenuCode.GDBlockCannonObjects1= [];
gdjs.MainMenuCode.GDBlockCannonObjects2= [];
gdjs.MainMenuCode.GDCannonAimObjects1= [];
gdjs.MainMenuCode.GDCannonAimObjects2= [];
gdjs.MainMenuCode.GDtileBackgroungObjects1= [];
gdjs.MainMenuCode.GDtileBackgroungObjects2= [];
gdjs.MainMenuCode.GDGlobalLightObjects1= [];
gdjs.MainMenuCode.GDGlobalLightObjects2= [];
gdjs.MainMenuCode.GDCoreLightPlayer2Objects1= [];
gdjs.MainMenuCode.GDCoreLightPlayer2Objects2= [];
gdjs.MainMenuCode.GDCoreLightPlayer1Objects1= [];
gdjs.MainMenuCode.GDCoreLightPlayer1Objects2= [];
gdjs.MainMenuCode.GDButtonObjects1= [];
gdjs.MainMenuCode.GDButtonObjects2= [];
gdjs.MainMenuCode.GDPlayIconObjects1= [];
gdjs.MainMenuCode.GDPlayIconObjects2= [];
gdjs.MainMenuCode.GDCreditsObjects1= [];
gdjs.MainMenuCode.GDCreditsObjects2= [];
gdjs.MainMenuCode.GDTutorialIconObjects1= [];
gdjs.MainMenuCode.GDTutorialIconObjects2= [];
gdjs.MainMenuCode.GDTitleObjects1= [];
gdjs.MainMenuCode.GDTitleObjects2= [];
gdjs.MainMenuCode.GDPlayer2Objects1= [];
gdjs.MainMenuCode.GDPlayer2Objects2= [];
gdjs.MainMenuCode.GDPlayer1Objects1= [];
gdjs.MainMenuCode.GDPlayer1Objects2= [];
gdjs.MainMenuCode.GDNewObjectObjects1= [];
gdjs.MainMenuCode.GDNewObjectObjects2= [];
gdjs.MainMenuCode.GDNewObject2Objects1= [];
gdjs.MainMenuCode.GDNewObject2Objects2= [];
gdjs.MainMenuCode.GDAObjects1= [];
gdjs.MainMenuCode.GDAObjects2= [];
gdjs.MainMenuCode.GDWObjects1= [];
gdjs.MainMenuCode.GDWObjects2= [];
gdjs.MainMenuCode.GDSObjects1= [];
gdjs.MainMenuCode.GDSObjects2= [];
gdjs.MainMenuCode.GDDObjects1= [];
gdjs.MainMenuCode.GDDObjects2= [];
gdjs.MainMenuCode.GDArrowObjects1= [];
gdjs.MainMenuCode.GDArrowObjects2= [];
gdjs.MainMenuCode.GDNewObject3Objects1= [];
gdjs.MainMenuCode.GDNewObject3Objects2= [];
gdjs.MainMenuCode.GDGameTitleObjects1= [];
gdjs.MainMenuCode.GDGameTitleObjects2= [];
gdjs.MainMenuCode.GDButtonPlayObjects1= [];
gdjs.MainMenuCode.GDButtonPlayObjects2= [];

gdjs.MainMenuCode.conditionTrue_0 = {val:false};
gdjs.MainMenuCode.condition0IsTrue_0 = {val:false};
gdjs.MainMenuCode.condition1IsTrue_0 = {val:false};
gdjs.MainMenuCode.condition2IsTrue_0 = {val:false};
gdjs.MainMenuCode.conditionTrue_1 = {val:false};
gdjs.MainMenuCode.condition0IsTrue_1 = {val:false};
gdjs.MainMenuCode.condition1IsTrue_1 = {val:false};
gdjs.MainMenuCode.condition2IsTrue_1 = {val:false};


gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDButtonPlayObjects1Objects = Hashtable.newFrom({"ButtonPlay": gdjs.MainMenuCode.GDButtonPlayObjects1});gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDCreditsObjects1Objects = Hashtable.newFrom({"Credits": gdjs.MainMenuCode.GDCreditsObjects1});gdjs.MainMenuCode.eventsList0 = function(runtimeScene) {

};gdjs.MainMenuCode.eventsList1 = function(runtimeScene) {

{


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainMenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Lights", 0, 0);
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\block-break.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\block-break.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\bullet-hit.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\core-damage.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\game-over.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\select-block.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\shoot.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\effects\\game-over.wav");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\music\\Frantic-Gameplay_v001.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\music\\Blissful-Trance.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\music\\Friendly-Machines.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\music\\Techno-Celebration-Looping.mp3");
}{gdjs.evtTools.sound.preloadSound(runtimeScene, "assets\\sound\\music\\the-executive-lounge-dan-barton-main-version-01-00-8850.mp3");
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "assets\\sound\\music\\Blissful-Trance.mp3", 1, false, 20, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ButtonPlay"), gdjs.MainMenuCode.GDButtonPlayObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
gdjs.MainMenuCode.condition1IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.MainMenuCode.condition0IsTrue_0.val ) {
{
gdjs.MainMenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDButtonPlayObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.MainMenuCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Battle", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Credits"), gdjs.MainMenuCode.GDCreditsObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
gdjs.MainMenuCode.condition1IsTrue_0.val = false;
{
gdjs.MainMenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.MainMenuCode.condition0IsTrue_0.val ) {
{
gdjs.MainMenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainMenuCode.mapOfGDgdjs_46MainMenuCode_46GDCreditsObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.MainMenuCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Credits", false);
}}

}


{


gdjs.MainMenuCode.eventsList0(runtimeScene);
}


{



}


{

gdjs.MainMenuCode.GDButtonPlayObjects1.length = 0;


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
gdjs.MainMenuCode.condition1IsTrue_0.val = false;
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition0IsTrue_0;
gdjs.MainMenuCode.GDButtonPlayObjects1_1final.length = 0;gdjs.MainMenuCode.condition0IsTrue_1.val = false;
gdjs.MainMenuCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("ButtonPlay"), gdjs.MainMenuCode.GDButtonPlayObjects2);
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDButtonPlayObjects2.length;i<l;++i) {
    if ( !(gdjs.MainMenuCode.GDButtonPlayObjects2[i].getBehavior("Tween").exists("green")) ) {
        gdjs.MainMenuCode.condition0IsTrue_1.val = true;
        gdjs.MainMenuCode.GDButtonPlayObjects2[k] = gdjs.MainMenuCode.GDButtonPlayObjects2[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDButtonPlayObjects2.length = k;if( gdjs.MainMenuCode.condition0IsTrue_1.val ) {
    gdjs.MainMenuCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainMenuCode.GDButtonPlayObjects2.length;j<jLen;++j) {
        if ( gdjs.MainMenuCode.GDButtonPlayObjects1_1final.indexOf(gdjs.MainMenuCode.GDButtonPlayObjects2[j]) === -1 )
            gdjs.MainMenuCode.GDButtonPlayObjects1_1final.push(gdjs.MainMenuCode.GDButtonPlayObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("ButtonPlay"), gdjs.MainMenuCode.GDButtonPlayObjects2);
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDButtonPlayObjects2.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDButtonPlayObjects2[i].getBehavior("Tween").hasFinished("green") ) {
        gdjs.MainMenuCode.condition1IsTrue_1.val = true;
        gdjs.MainMenuCode.GDButtonPlayObjects2[k] = gdjs.MainMenuCode.GDButtonPlayObjects2[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDButtonPlayObjects2.length = k;if( gdjs.MainMenuCode.condition1IsTrue_1.val ) {
    gdjs.MainMenuCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainMenuCode.GDButtonPlayObjects2.length;j<jLen;++j) {
        if ( gdjs.MainMenuCode.GDButtonPlayObjects1_1final.indexOf(gdjs.MainMenuCode.GDButtonPlayObjects2[j]) === -1 )
            gdjs.MainMenuCode.GDButtonPlayObjects1_1final.push(gdjs.MainMenuCode.GDButtonPlayObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainMenuCode.GDButtonPlayObjects1_1final, gdjs.MainMenuCode.GDButtonPlayObjects1);
}
}
}if ( gdjs.MainMenuCode.condition0IsTrue_0.val ) {
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition1IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10213716);
}
}}
if (gdjs.MainMenuCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDButtonPlayObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDButtonPlayObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDButtonPlayObjects1[i].getBehavior("Tween").addObjectColorTween("pink", "255;128;167", "linear", 1000, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ButtonPlay"), gdjs.MainMenuCode.GDButtonPlayObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
gdjs.MainMenuCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDButtonPlayObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDButtonPlayObjects1[i].getBehavior("Tween").hasFinished("pink") ) {
        gdjs.MainMenuCode.condition0IsTrue_0.val = true;
        gdjs.MainMenuCode.GDButtonPlayObjects1[k] = gdjs.MainMenuCode.GDButtonPlayObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDButtonPlayObjects1.length = k;}if ( gdjs.MainMenuCode.condition0IsTrue_0.val ) {
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition1IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10214620);
}
}}
if (gdjs.MainMenuCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDButtonPlayObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDButtonPlayObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDButtonPlayObjects1[i].getBehavior("Tween").addObjectColorTween("blue", "128;128;255", "linear", 1000, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ButtonPlay"), gdjs.MainMenuCode.GDButtonPlayObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
gdjs.MainMenuCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDButtonPlayObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDButtonPlayObjects1[i].getBehavior("Tween").hasFinished("blue") ) {
        gdjs.MainMenuCode.condition0IsTrue_0.val = true;
        gdjs.MainMenuCode.GDButtonPlayObjects1[k] = gdjs.MainMenuCode.GDButtonPlayObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDButtonPlayObjects1.length = k;}if ( gdjs.MainMenuCode.condition0IsTrue_0.val ) {
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition1IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10215620);
}
}}
if (gdjs.MainMenuCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDButtonPlayObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDButtonPlayObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDButtonPlayObjects1[i].getBehavior("Tween").addObjectColorTween("yellow", "255;208;112", "linear", 1000, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ButtonPlay"), gdjs.MainMenuCode.GDButtonPlayObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
gdjs.MainMenuCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDButtonPlayObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDButtonPlayObjects1[i].getBehavior("Tween").hasFinished("yellow") ) {
        gdjs.MainMenuCode.condition0IsTrue_0.val = true;
        gdjs.MainMenuCode.GDButtonPlayObjects1[k] = gdjs.MainMenuCode.GDButtonPlayObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDButtonPlayObjects1.length = k;}if ( gdjs.MainMenuCode.condition0IsTrue_0.val ) {
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition1IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10215956);
}
}}
if (gdjs.MainMenuCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDButtonPlayObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDButtonPlayObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDButtonPlayObjects1[i].getBehavior("Tween").addObjectColorTween("red", "255;112;112", "linear", 1000, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ButtonPlay"), gdjs.MainMenuCode.GDButtonPlayObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
gdjs.MainMenuCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDButtonPlayObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDButtonPlayObjects1[i].getBehavior("Tween").hasFinished("red") ) {
        gdjs.MainMenuCode.condition0IsTrue_0.val = true;
        gdjs.MainMenuCode.GDButtonPlayObjects1[k] = gdjs.MainMenuCode.GDButtonPlayObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDButtonPlayObjects1.length = k;}if ( gdjs.MainMenuCode.condition0IsTrue_0.val ) {
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition1IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10217716);
}
}}
if (gdjs.MainMenuCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDButtonPlayObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDButtonPlayObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDButtonPlayObjects1[i].getBehavior("Tween").addObjectColorTween("green", "96;255;128", "linear", 1000, false, false);
}
}}

}


{



}


{

gdjs.MainMenuCode.GDGameTitleObjects1.length = 0;


gdjs.MainMenuCode.condition0IsTrue_0.val = false;
gdjs.MainMenuCode.condition1IsTrue_0.val = false;
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition0IsTrue_0;
gdjs.MainMenuCode.GDGameTitleObjects1_1final.length = 0;gdjs.MainMenuCode.condition0IsTrue_1.val = false;
gdjs.MainMenuCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("GameTitle"), gdjs.MainMenuCode.GDGameTitleObjects2);
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDGameTitleObjects2.length;i<l;++i) {
    if ( !(gdjs.MainMenuCode.GDGameTitleObjects2[i].getBehavior("Tween").exists("scaleDown")) ) {
        gdjs.MainMenuCode.condition0IsTrue_1.val = true;
        gdjs.MainMenuCode.GDGameTitleObjects2[k] = gdjs.MainMenuCode.GDGameTitleObjects2[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDGameTitleObjects2.length = k;if( gdjs.MainMenuCode.condition0IsTrue_1.val ) {
    gdjs.MainMenuCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainMenuCode.GDGameTitleObjects2.length;j<jLen;++j) {
        if ( gdjs.MainMenuCode.GDGameTitleObjects1_1final.indexOf(gdjs.MainMenuCode.GDGameTitleObjects2[j]) === -1 )
            gdjs.MainMenuCode.GDGameTitleObjects1_1final.push(gdjs.MainMenuCode.GDGameTitleObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("GameTitle"), gdjs.MainMenuCode.GDGameTitleObjects2);
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDGameTitleObjects2.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDGameTitleObjects2[i].getBehavior("Tween").hasFinished("scaleDown") ) {
        gdjs.MainMenuCode.condition1IsTrue_1.val = true;
        gdjs.MainMenuCode.GDGameTitleObjects2[k] = gdjs.MainMenuCode.GDGameTitleObjects2[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDGameTitleObjects2.length = k;if( gdjs.MainMenuCode.condition1IsTrue_1.val ) {
    gdjs.MainMenuCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainMenuCode.GDGameTitleObjects2.length;j<jLen;++j) {
        if ( gdjs.MainMenuCode.GDGameTitleObjects1_1final.indexOf(gdjs.MainMenuCode.GDGameTitleObjects2[j]) === -1 )
            gdjs.MainMenuCode.GDGameTitleObjects1_1final.push(gdjs.MainMenuCode.GDGameTitleObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainMenuCode.GDGameTitleObjects1_1final, gdjs.MainMenuCode.GDGameTitleObjects1);
}
}
}if ( gdjs.MainMenuCode.condition0IsTrue_0.val ) {
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition1IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10219276);
}
}}
if (gdjs.MainMenuCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDGameTitleObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDGameTitleObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDGameTitleObjects1[i].getBehavior("Tween").addObjectScaleTween("scaleUp", 1.15, 1.15, "easeInOutQuad", 3000, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GameTitle"), gdjs.MainMenuCode.GDGameTitleObjects1);

gdjs.MainMenuCode.condition0IsTrue_0.val = false;
gdjs.MainMenuCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainMenuCode.GDGameTitleObjects1.length;i<l;++i) {
    if ( gdjs.MainMenuCode.GDGameTitleObjects1[i].getBehavior("Tween").hasFinished("scaleUp") ) {
        gdjs.MainMenuCode.condition0IsTrue_0.val = true;
        gdjs.MainMenuCode.GDGameTitleObjects1[k] = gdjs.MainMenuCode.GDGameTitleObjects1[i];
        ++k;
    }
}
gdjs.MainMenuCode.GDGameTitleObjects1.length = k;}if ( gdjs.MainMenuCode.condition0IsTrue_0.val ) {
{
{gdjs.MainMenuCode.conditionTrue_1 = gdjs.MainMenuCode.condition1IsTrue_0;
gdjs.MainMenuCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10219932);
}
}}
if (gdjs.MainMenuCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainMenuCode.GDGameTitleObjects1 */
{for(var i = 0, len = gdjs.MainMenuCode.GDGameTitleObjects1.length ;i < len;++i) {
    gdjs.MainMenuCode.GDGameTitleObjects1[i].getBehavior("Tween").addObjectScaleTween("scaleDown", 0.9, 0.9, "easeInOutQuad", 3000, false, true);
}
}}

}


};

gdjs.MainMenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainMenuCode.GDBulletObjects1.length = 0;
gdjs.MainMenuCode.GDBulletObjects2.length = 0;
gdjs.MainMenuCode.GDBlockCannonObjects1.length = 0;
gdjs.MainMenuCode.GDBlockCannonObjects2.length = 0;
gdjs.MainMenuCode.GDCannonAimObjects1.length = 0;
gdjs.MainMenuCode.GDCannonAimObjects2.length = 0;
gdjs.MainMenuCode.GDtileBackgroungObjects1.length = 0;
gdjs.MainMenuCode.GDtileBackgroungObjects2.length = 0;
gdjs.MainMenuCode.GDGlobalLightObjects1.length = 0;
gdjs.MainMenuCode.GDGlobalLightObjects2.length = 0;
gdjs.MainMenuCode.GDCoreLightPlayer2Objects1.length = 0;
gdjs.MainMenuCode.GDCoreLightPlayer2Objects2.length = 0;
gdjs.MainMenuCode.GDCoreLightPlayer1Objects1.length = 0;
gdjs.MainMenuCode.GDCoreLightPlayer1Objects2.length = 0;
gdjs.MainMenuCode.GDButtonObjects1.length = 0;
gdjs.MainMenuCode.GDButtonObjects2.length = 0;
gdjs.MainMenuCode.GDPlayIconObjects1.length = 0;
gdjs.MainMenuCode.GDPlayIconObjects2.length = 0;
gdjs.MainMenuCode.GDCreditsObjects1.length = 0;
gdjs.MainMenuCode.GDCreditsObjects2.length = 0;
gdjs.MainMenuCode.GDTutorialIconObjects1.length = 0;
gdjs.MainMenuCode.GDTutorialIconObjects2.length = 0;
gdjs.MainMenuCode.GDTitleObjects1.length = 0;
gdjs.MainMenuCode.GDTitleObjects2.length = 0;
gdjs.MainMenuCode.GDPlayer2Objects1.length = 0;
gdjs.MainMenuCode.GDPlayer2Objects2.length = 0;
gdjs.MainMenuCode.GDPlayer1Objects1.length = 0;
gdjs.MainMenuCode.GDPlayer1Objects2.length = 0;
gdjs.MainMenuCode.GDNewObjectObjects1.length = 0;
gdjs.MainMenuCode.GDNewObjectObjects2.length = 0;
gdjs.MainMenuCode.GDNewObject2Objects1.length = 0;
gdjs.MainMenuCode.GDNewObject2Objects2.length = 0;
gdjs.MainMenuCode.GDAObjects1.length = 0;
gdjs.MainMenuCode.GDAObjects2.length = 0;
gdjs.MainMenuCode.GDWObjects1.length = 0;
gdjs.MainMenuCode.GDWObjects2.length = 0;
gdjs.MainMenuCode.GDSObjects1.length = 0;
gdjs.MainMenuCode.GDSObjects2.length = 0;
gdjs.MainMenuCode.GDDObjects1.length = 0;
gdjs.MainMenuCode.GDDObjects2.length = 0;
gdjs.MainMenuCode.GDArrowObjects1.length = 0;
gdjs.MainMenuCode.GDArrowObjects2.length = 0;
gdjs.MainMenuCode.GDNewObject3Objects1.length = 0;
gdjs.MainMenuCode.GDNewObject3Objects2.length = 0;
gdjs.MainMenuCode.GDGameTitleObjects1.length = 0;
gdjs.MainMenuCode.GDGameTitleObjects2.length = 0;
gdjs.MainMenuCode.GDButtonPlayObjects1.length = 0;
gdjs.MainMenuCode.GDButtonPlayObjects2.length = 0;

gdjs.MainMenuCode.eventsList1(runtimeScene);
return;

}

gdjs['MainMenuCode'] = gdjs.MainMenuCode;
