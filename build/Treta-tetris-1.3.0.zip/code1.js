gdjs.TutorialCode = {};

gdjs.TutorialCode.conditionTrue_0 = {val:false};
gdjs.TutorialCode.condition0IsTrue_0 = {val:false};


gdjs.TutorialCode.eventsList0 = function(runtimeScene) {

};

gdjs.TutorialCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.TutorialCode.eventsList0(runtimeScene);
return;

}

gdjs['TutorialCode'] = gdjs.TutorialCode;
