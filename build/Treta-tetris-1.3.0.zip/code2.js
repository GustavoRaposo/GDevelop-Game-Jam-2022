gdjs.BattleCode = {};
gdjs.BattleCode.GDCoreObjects3_1final = [];

gdjs.BattleCode.forEachIndex2 = 0;

gdjs.BattleCode.forEachIndex3 = 0;

gdjs.BattleCode.forEachIndex4 = 0;

gdjs.BattleCode.forEachIndex6 = 0;

gdjs.BattleCode.forEachObjects2 = [];

gdjs.BattleCode.forEachObjects3 = [];

gdjs.BattleCode.forEachObjects4 = [];

gdjs.BattleCode.forEachObjects6 = [];

gdjs.BattleCode.forEachTemporary2 = null;

gdjs.BattleCode.forEachTemporary3 = null;

gdjs.BattleCode.forEachTemporary4 = null;

gdjs.BattleCode.forEachTemporary6 = null;

gdjs.BattleCode.forEachTotalCount2 = 0;

gdjs.BattleCode.forEachTotalCount3 = 0;

gdjs.BattleCode.forEachTotalCount4 = 0;

gdjs.BattleCode.forEachTotalCount6 = 0;

gdjs.BattleCode.repeatCount5 = 0;

gdjs.BattleCode.repeatIndex5 = 0;

gdjs.BattleCode.GDBulletObjects1= [];
gdjs.BattleCode.GDBulletObjects2= [];
gdjs.BattleCode.GDBulletObjects3= [];
gdjs.BattleCode.GDBulletObjects4= [];
gdjs.BattleCode.GDBulletObjects5= [];
gdjs.BattleCode.GDBulletObjects6= [];
gdjs.BattleCode.GDBulletObjects7= [];
gdjs.BattleCode.GDBulletObjects8= [];
gdjs.BattleCode.GDBlockCannonObjects1= [];
gdjs.BattleCode.GDBlockCannonObjects2= [];
gdjs.BattleCode.GDBlockCannonObjects3= [];
gdjs.BattleCode.GDBlockCannonObjects4= [];
gdjs.BattleCode.GDBlockCannonObjects5= [];
gdjs.BattleCode.GDBlockCannonObjects6= [];
gdjs.BattleCode.GDBlockCannonObjects7= [];
gdjs.BattleCode.GDBlockCannonObjects8= [];
gdjs.BattleCode.GDCannonAimObjects1= [];
gdjs.BattleCode.GDCannonAimObjects2= [];
gdjs.BattleCode.GDCannonAimObjects3= [];
gdjs.BattleCode.GDCannonAimObjects4= [];
gdjs.BattleCode.GDCannonAimObjects5= [];
gdjs.BattleCode.GDCannonAimObjects6= [];
gdjs.BattleCode.GDCannonAimObjects7= [];
gdjs.BattleCode.GDCannonAimObjects8= [];
gdjs.BattleCode.GDtileBackgroungObjects1= [];
gdjs.BattleCode.GDtileBackgroungObjects2= [];
gdjs.BattleCode.GDtileBackgroungObjects3= [];
gdjs.BattleCode.GDtileBackgroungObjects4= [];
gdjs.BattleCode.GDtileBackgroungObjects5= [];
gdjs.BattleCode.GDtileBackgroungObjects6= [];
gdjs.BattleCode.GDtileBackgroungObjects7= [];
gdjs.BattleCode.GDtileBackgroungObjects8= [];
gdjs.BattleCode.GDGlobalLightObjects1= [];
gdjs.BattleCode.GDGlobalLightObjects2= [];
gdjs.BattleCode.GDGlobalLightObjects3= [];
gdjs.BattleCode.GDGlobalLightObjects4= [];
gdjs.BattleCode.GDGlobalLightObjects5= [];
gdjs.BattleCode.GDGlobalLightObjects6= [];
gdjs.BattleCode.GDGlobalLightObjects7= [];
gdjs.BattleCode.GDGlobalLightObjects8= [];
gdjs.BattleCode.GDCoreLightPlayer2Objects1= [];
gdjs.BattleCode.GDCoreLightPlayer2Objects2= [];
gdjs.BattleCode.GDCoreLightPlayer2Objects3= [];
gdjs.BattleCode.GDCoreLightPlayer2Objects4= [];
gdjs.BattleCode.GDCoreLightPlayer2Objects5= [];
gdjs.BattleCode.GDCoreLightPlayer2Objects6= [];
gdjs.BattleCode.GDCoreLightPlayer2Objects7= [];
gdjs.BattleCode.GDCoreLightPlayer2Objects8= [];
gdjs.BattleCode.GDCoreLightPlayer1Objects1= [];
gdjs.BattleCode.GDCoreLightPlayer1Objects2= [];
gdjs.BattleCode.GDCoreLightPlayer1Objects3= [];
gdjs.BattleCode.GDCoreLightPlayer1Objects4= [];
gdjs.BattleCode.GDCoreLightPlayer1Objects5= [];
gdjs.BattleCode.GDCoreLightPlayer1Objects6= [];
gdjs.BattleCode.GDCoreLightPlayer1Objects7= [];
gdjs.BattleCode.GDCoreLightPlayer1Objects8= [];
gdjs.BattleCode.GDBlockObjects1= [];
gdjs.BattleCode.GDBlockObjects2= [];
gdjs.BattleCode.GDBlockObjects3= [];
gdjs.BattleCode.GDBlockObjects4= [];
gdjs.BattleCode.GDBlockObjects5= [];
gdjs.BattleCode.GDBlockObjects6= [];
gdjs.BattleCode.GDBlockObjects7= [];
gdjs.BattleCode.GDBlockObjects8= [];
gdjs.BattleCode.GDFloorObjects1= [];
gdjs.BattleCode.GDFloorObjects2= [];
gdjs.BattleCode.GDFloorObjects3= [];
gdjs.BattleCode.GDFloorObjects4= [];
gdjs.BattleCode.GDFloorObjects5= [];
gdjs.BattleCode.GDFloorObjects6= [];
gdjs.BattleCode.GDFloorObjects7= [];
gdjs.BattleCode.GDFloorObjects8= [];
gdjs.BattleCode.GDCoreObjects1= [];
gdjs.BattleCode.GDCoreObjects2= [];
gdjs.BattleCode.GDCoreObjects3= [];
gdjs.BattleCode.GDCoreObjects4= [];
gdjs.BattleCode.GDCoreObjects5= [];
gdjs.BattleCode.GDCoreObjects6= [];
gdjs.BattleCode.GDCoreObjects7= [];
gdjs.BattleCode.GDCoreObjects8= [];
gdjs.BattleCode.GDBackground2Objects1= [];
gdjs.BattleCode.GDBackground2Objects2= [];
gdjs.BattleCode.GDBackground2Objects3= [];
gdjs.BattleCode.GDBackground2Objects4= [];
gdjs.BattleCode.GDBackground2Objects5= [];
gdjs.BattleCode.GDBackground2Objects6= [];
gdjs.BattleCode.GDBackground2Objects7= [];
gdjs.BattleCode.GDBackground2Objects8= [];
gdjs.BattleCode.GDSpawnObjects1= [];
gdjs.BattleCode.GDSpawnObjects2= [];
gdjs.BattleCode.GDSpawnObjects3= [];
gdjs.BattleCode.GDSpawnObjects4= [];
gdjs.BattleCode.GDSpawnObjects5= [];
gdjs.BattleCode.GDSpawnObjects6= [];
gdjs.BattleCode.GDSpawnObjects7= [];
gdjs.BattleCode.GDSpawnObjects8= [];
gdjs.BattleCode.GDBlock1x2Objects1= [];
gdjs.BattleCode.GDBlock1x2Objects2= [];
gdjs.BattleCode.GDBlock1x2Objects3= [];
gdjs.BattleCode.GDBlock1x2Objects4= [];
gdjs.BattleCode.GDBlock1x2Objects5= [];
gdjs.BattleCode.GDBlock1x2Objects6= [];
gdjs.BattleCode.GDBlock1x2Objects7= [];
gdjs.BattleCode.GDBlock1x2Objects8= [];
gdjs.BattleCode.GDBlock2x1Objects1= [];
gdjs.BattleCode.GDBlock2x1Objects2= [];
gdjs.BattleCode.GDBlock2x1Objects3= [];
gdjs.BattleCode.GDBlock2x1Objects4= [];
gdjs.BattleCode.GDBlock2x1Objects5= [];
gdjs.BattleCode.GDBlock2x1Objects6= [];
gdjs.BattleCode.GDBlock2x1Objects7= [];
gdjs.BattleCode.GDBlock2x1Objects8= [];
gdjs.BattleCode.GDBlock2x2Objects1= [];
gdjs.BattleCode.GDBlock2x2Objects2= [];
gdjs.BattleCode.GDBlock2x2Objects3= [];
gdjs.BattleCode.GDBlock2x2Objects4= [];
gdjs.BattleCode.GDBlock2x2Objects5= [];
gdjs.BattleCode.GDBlock2x2Objects6= [];
gdjs.BattleCode.GDBlock2x2Objects7= [];
gdjs.BattleCode.GDBlock2x2Objects8= [];
gdjs.BattleCode.GDBlockLObjects1= [];
gdjs.BattleCode.GDBlockLObjects2= [];
gdjs.BattleCode.GDBlockLObjects3= [];
gdjs.BattleCode.GDBlockLObjects4= [];
gdjs.BattleCode.GDBlockLObjects5= [];
gdjs.BattleCode.GDBlockLObjects6= [];
gdjs.BattleCode.GDBlockLObjects7= [];
gdjs.BattleCode.GDBlockLObjects8= [];
gdjs.BattleCode.GDBlockIObjects1= [];
gdjs.BattleCode.GDBlockIObjects2= [];
gdjs.BattleCode.GDBlockIObjects3= [];
gdjs.BattleCode.GDBlockIObjects4= [];
gdjs.BattleCode.GDBlockIObjects5= [];
gdjs.BattleCode.GDBlockIObjects6= [];
gdjs.BattleCode.GDBlockIObjects7= [];
gdjs.BattleCode.GDBlockIObjects8= [];
gdjs.BattleCode.GDDebugObjects1= [];
gdjs.BattleCode.GDDebugObjects2= [];
gdjs.BattleCode.GDDebugObjects3= [];
gdjs.BattleCode.GDDebugObjects4= [];
gdjs.BattleCode.GDDebugObjects5= [];
gdjs.BattleCode.GDDebugObjects6= [];
gdjs.BattleCode.GDDebugObjects7= [];
gdjs.BattleCode.GDDebugObjects8= [];
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects1= [];
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects2= [];
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects3= [];
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects4= [];
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects5= [];
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects6= [];
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects7= [];
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects8= [];
gdjs.BattleCode.GDTextGameOverWinnerObjects1= [];
gdjs.BattleCode.GDTextGameOverWinnerObjects2= [];
gdjs.BattleCode.GDTextGameOverWinnerObjects3= [];
gdjs.BattleCode.GDTextGameOverWinnerObjects4= [];
gdjs.BattleCode.GDTextGameOverWinnerObjects5= [];
gdjs.BattleCode.GDTextGameOverWinnerObjects6= [];
gdjs.BattleCode.GDTextGameOverWinnerObjects7= [];
gdjs.BattleCode.GDTextGameOverWinnerObjects8= [];
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects1= [];
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects2= [];
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects3= [];
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects4= [];
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects5= [];
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects6= [];
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects7= [];
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects8= [];
gdjs.BattleCode.GDTextBattleTurnObjects1= [];
gdjs.BattleCode.GDTextBattleTurnObjects2= [];
gdjs.BattleCode.GDTextBattleTurnObjects3= [];
gdjs.BattleCode.GDTextBattleTurnObjects4= [];
gdjs.BattleCode.GDTextBattleTurnObjects5= [];
gdjs.BattleCode.GDTextBattleTurnObjects6= [];
gdjs.BattleCode.GDTextBattleTurnObjects7= [];
gdjs.BattleCode.GDTextBattleTurnObjects8= [];
gdjs.BattleCode.GDTextGameOverObjects1= [];
gdjs.BattleCode.GDTextGameOverObjects2= [];
gdjs.BattleCode.GDTextGameOverObjects3= [];
gdjs.BattleCode.GDTextGameOverObjects4= [];
gdjs.BattleCode.GDTextGameOverObjects5= [];
gdjs.BattleCode.GDTextGameOverObjects6= [];
gdjs.BattleCode.GDTextGameOverObjects7= [];
gdjs.BattleCode.GDTextGameOverObjects8= [];
gdjs.BattleCode.GDTextBuildTurnObjects1= [];
gdjs.BattleCode.GDTextBuildTurnObjects2= [];
gdjs.BattleCode.GDTextBuildTurnObjects3= [];
gdjs.BattleCode.GDTextBuildTurnObjects4= [];
gdjs.BattleCode.GDTextBuildTurnObjects5= [];
gdjs.BattleCode.GDTextBuildTurnObjects6= [];
gdjs.BattleCode.GDTextBuildTurnObjects7= [];
gdjs.BattleCode.GDTextBuildTurnObjects8= [];
gdjs.BattleCode.GDButtonPlayObjects1= [];
gdjs.BattleCode.GDButtonPlayObjects2= [];
gdjs.BattleCode.GDButtonPlayObjects3= [];
gdjs.BattleCode.GDButtonPlayObjects4= [];
gdjs.BattleCode.GDButtonPlayObjects5= [];
gdjs.BattleCode.GDButtonPlayObjects6= [];
gdjs.BattleCode.GDButtonPlayObjects7= [];
gdjs.BattleCode.GDButtonPlayObjects8= [];
gdjs.BattleCode.GDTextPlayerAgainObjects1= [];
gdjs.BattleCode.GDTextPlayerAgainObjects2= [];
gdjs.BattleCode.GDTextPlayerAgainObjects3= [];
gdjs.BattleCode.GDTextPlayerAgainObjects4= [];
gdjs.BattleCode.GDTextPlayerAgainObjects5= [];
gdjs.BattleCode.GDTextPlayerAgainObjects6= [];
gdjs.BattleCode.GDTextPlayerAgainObjects7= [];
gdjs.BattleCode.GDTextPlayerAgainObjects8= [];
gdjs.BattleCode.GDBulletParticlePlayer2Objects1= [];
gdjs.BattleCode.GDBulletParticlePlayer2Objects2= [];
gdjs.BattleCode.GDBulletParticlePlayer2Objects3= [];
gdjs.BattleCode.GDBulletParticlePlayer2Objects4= [];
gdjs.BattleCode.GDBulletParticlePlayer2Objects5= [];
gdjs.BattleCode.GDBulletParticlePlayer2Objects6= [];
gdjs.BattleCode.GDBulletParticlePlayer2Objects7= [];
gdjs.BattleCode.GDBulletParticlePlayer2Objects8= [];
gdjs.BattleCode.GDBulletParticleObjects1= [];
gdjs.BattleCode.GDBulletParticleObjects2= [];
gdjs.BattleCode.GDBulletParticleObjects3= [];
gdjs.BattleCode.GDBulletParticleObjects4= [];
gdjs.BattleCode.GDBulletParticleObjects5= [];
gdjs.BattleCode.GDBulletParticleObjects6= [];
gdjs.BattleCode.GDBulletParticleObjects7= [];
gdjs.BattleCode.GDBulletParticleObjects8= [];
gdjs.BattleCode.GDRoofObjects1= [];
gdjs.BattleCode.GDRoofObjects2= [];
gdjs.BattleCode.GDRoofObjects3= [];
gdjs.BattleCode.GDRoofObjects4= [];
gdjs.BattleCode.GDRoofObjects5= [];
gdjs.BattleCode.GDRoofObjects6= [];
gdjs.BattleCode.GDRoofObjects7= [];
gdjs.BattleCode.GDRoofObjects8= [];
gdjs.BattleCode.GDTextBattleTimerObjects1= [];
gdjs.BattleCode.GDTextBattleTimerObjects2= [];
gdjs.BattleCode.GDTextBattleTimerObjects3= [];
gdjs.BattleCode.GDTextBattleTimerObjects4= [];
gdjs.BattleCode.GDTextBattleTimerObjects5= [];
gdjs.BattleCode.GDTextBattleTimerObjects6= [];
gdjs.BattleCode.GDTextBattleTimerObjects7= [];
gdjs.BattleCode.GDTextBattleTimerObjects8= [];
gdjs.BattleCode.GDTesteObjects1= [];
gdjs.BattleCode.GDTesteObjects2= [];
gdjs.BattleCode.GDTesteObjects3= [];
gdjs.BattleCode.GDTesteObjects4= [];
gdjs.BattleCode.GDTesteObjects5= [];
gdjs.BattleCode.GDTesteObjects6= [];
gdjs.BattleCode.GDTesteObjects7= [];
gdjs.BattleCode.GDTesteObjects8= [];
gdjs.BattleCode.GDDarkOverlayObjects1= [];
gdjs.BattleCode.GDDarkOverlayObjects2= [];
gdjs.BattleCode.GDDarkOverlayObjects3= [];
gdjs.BattleCode.GDDarkOverlayObjects4= [];
gdjs.BattleCode.GDDarkOverlayObjects5= [];
gdjs.BattleCode.GDDarkOverlayObjects6= [];
gdjs.BattleCode.GDDarkOverlayObjects7= [];
gdjs.BattleCode.GDDarkOverlayObjects8= [];
gdjs.BattleCode.GDTextExitObjects1= [];
gdjs.BattleCode.GDTextExitObjects2= [];
gdjs.BattleCode.GDTextExitObjects3= [];
gdjs.BattleCode.GDTextExitObjects4= [];
gdjs.BattleCode.GDTextExitObjects5= [];
gdjs.BattleCode.GDTextExitObjects6= [];
gdjs.BattleCode.GDTextExitObjects7= [];
gdjs.BattleCode.GDTextExitObjects8= [];
gdjs.BattleCode.GDTextContinueObjects1= [];
gdjs.BattleCode.GDTextContinueObjects2= [];
gdjs.BattleCode.GDTextContinueObjects3= [];
gdjs.BattleCode.GDTextContinueObjects4= [];
gdjs.BattleCode.GDTextContinueObjects5= [];
gdjs.BattleCode.GDTextContinueObjects6= [];
gdjs.BattleCode.GDTextContinueObjects7= [];
gdjs.BattleCode.GDTextContinueObjects8= [];
gdjs.BattleCode.GDTextPauseTitleObjects1= [];
gdjs.BattleCode.GDTextPauseTitleObjects2= [];
gdjs.BattleCode.GDTextPauseTitleObjects3= [];
gdjs.BattleCode.GDTextPauseTitleObjects4= [];
gdjs.BattleCode.GDTextPauseTitleObjects5= [];
gdjs.BattleCode.GDTextPauseTitleObjects6= [];
gdjs.BattleCode.GDTextPauseTitleObjects7= [];
gdjs.BattleCode.GDTextPauseTitleObjects8= [];
gdjs.BattleCode.GDNewObjectObjects1= [];
gdjs.BattleCode.GDNewObjectObjects2= [];
gdjs.BattleCode.GDNewObjectObjects3= [];
gdjs.BattleCode.GDNewObjectObjects4= [];
gdjs.BattleCode.GDNewObjectObjects5= [];
gdjs.BattleCode.GDNewObjectObjects6= [];
gdjs.BattleCode.GDNewObjectObjects7= [];
gdjs.BattleCode.GDNewObjectObjects8= [];
gdjs.BattleCode.GDTextPlayer2ControlsObjects1= [];
gdjs.BattleCode.GDTextPlayer2ControlsObjects2= [];
gdjs.BattleCode.GDTextPlayer2ControlsObjects3= [];
gdjs.BattleCode.GDTextPlayer2ControlsObjects4= [];
gdjs.BattleCode.GDTextPlayer2ControlsObjects5= [];
gdjs.BattleCode.GDTextPlayer2ControlsObjects6= [];
gdjs.BattleCode.GDTextPlayer2ControlsObjects7= [];
gdjs.BattleCode.GDTextPlayer2ControlsObjects8= [];
gdjs.BattleCode.GDTextPlayer1ControlsObjects1= [];
gdjs.BattleCode.GDTextPlayer1ControlsObjects2= [];
gdjs.BattleCode.GDTextPlayer1ControlsObjects3= [];
gdjs.BattleCode.GDTextPlayer1ControlsObjects4= [];
gdjs.BattleCode.GDTextPlayer1ControlsObjects5= [];
gdjs.BattleCode.GDTextPlayer1ControlsObjects6= [];
gdjs.BattleCode.GDTextPlayer1ControlsObjects7= [];
gdjs.BattleCode.GDTextPlayer1ControlsObjects8= [];
gdjs.BattleCode.GDWObjects1= [];
gdjs.BattleCode.GDWObjects2= [];
gdjs.BattleCode.GDWObjects3= [];
gdjs.BattleCode.GDWObjects4= [];
gdjs.BattleCode.GDWObjects5= [];
gdjs.BattleCode.GDWObjects6= [];
gdjs.BattleCode.GDWObjects7= [];
gdjs.BattleCode.GDWObjects8= [];
gdjs.BattleCode.GDSObjects1= [];
gdjs.BattleCode.GDSObjects2= [];
gdjs.BattleCode.GDSObjects3= [];
gdjs.BattleCode.GDSObjects4= [];
gdjs.BattleCode.GDSObjects5= [];
gdjs.BattleCode.GDSObjects6= [];
gdjs.BattleCode.GDSObjects7= [];
gdjs.BattleCode.GDSObjects8= [];
gdjs.BattleCode.GDAObjects1= [];
gdjs.BattleCode.GDAObjects2= [];
gdjs.BattleCode.GDAObjects3= [];
gdjs.BattleCode.GDAObjects4= [];
gdjs.BattleCode.GDAObjects5= [];
gdjs.BattleCode.GDAObjects6= [];
gdjs.BattleCode.GDAObjects7= [];
gdjs.BattleCode.GDAObjects8= [];
gdjs.BattleCode.GDDObjects1= [];
gdjs.BattleCode.GDDObjects2= [];
gdjs.BattleCode.GDDObjects3= [];
gdjs.BattleCode.GDDObjects4= [];
gdjs.BattleCode.GDDObjects5= [];
gdjs.BattleCode.GDDObjects6= [];
gdjs.BattleCode.GDDObjects7= [];
gdjs.BattleCode.GDDObjects8= [];
gdjs.BattleCode.GDArrowObjects1= [];
gdjs.BattleCode.GDArrowObjects2= [];
gdjs.BattleCode.GDArrowObjects3= [];
gdjs.BattleCode.GDArrowObjects4= [];
gdjs.BattleCode.GDArrowObjects5= [];
gdjs.BattleCode.GDArrowObjects6= [];
gdjs.BattleCode.GDArrowObjects7= [];
gdjs.BattleCode.GDArrowObjects8= [];
gdjs.BattleCode.GDTextMoveBlocksObjects1= [];
gdjs.BattleCode.GDTextMoveBlocksObjects2= [];
gdjs.BattleCode.GDTextMoveBlocksObjects3= [];
gdjs.BattleCode.GDTextMoveBlocksObjects4= [];
gdjs.BattleCode.GDTextMoveBlocksObjects5= [];
gdjs.BattleCode.GDTextMoveBlocksObjects6= [];
gdjs.BattleCode.GDTextMoveBlocksObjects7= [];
gdjs.BattleCode.GDTextMoveBlocksObjects8= [];
gdjs.BattleCode.GDAimObjects1= [];
gdjs.BattleCode.GDAimObjects2= [];
gdjs.BattleCode.GDAimObjects3= [];
gdjs.BattleCode.GDAimObjects4= [];
gdjs.BattleCode.GDAimObjects5= [];
gdjs.BattleCode.GDAimObjects6= [];
gdjs.BattleCode.GDAimObjects7= [];
gdjs.BattleCode.GDAimObjects8= [];
gdjs.BattleCode.GDKeyObjects1= [];
gdjs.BattleCode.GDKeyObjects2= [];
gdjs.BattleCode.GDKeyObjects3= [];
gdjs.BattleCode.GDKeyObjects4= [];
gdjs.BattleCode.GDKeyObjects5= [];
gdjs.BattleCode.GDKeyObjects6= [];
gdjs.BattleCode.GDKeyObjects7= [];
gdjs.BattleCode.GDKeyObjects8= [];
gdjs.BattleCode.GDBlockAreaBorderLeftObjects1= [];
gdjs.BattleCode.GDBlockAreaBorderLeftObjects2= [];
gdjs.BattleCode.GDBlockAreaBorderLeftObjects3= [];
gdjs.BattleCode.GDBlockAreaBorderLeftObjects4= [];
gdjs.BattleCode.GDBlockAreaBorderLeftObjects5= [];
gdjs.BattleCode.GDBlockAreaBorderLeftObjects6= [];
gdjs.BattleCode.GDBlockAreaBorderLeftObjects7= [];
gdjs.BattleCode.GDBlockAreaBorderLeftObjects8= [];
gdjs.BattleCode.GDButtonPlayAgainObjects1= [];
gdjs.BattleCode.GDButtonPlayAgainObjects2= [];
gdjs.BattleCode.GDButtonPlayAgainObjects3= [];
gdjs.BattleCode.GDButtonPlayAgainObjects4= [];
gdjs.BattleCode.GDButtonPlayAgainObjects5= [];
gdjs.BattleCode.GDButtonPlayAgainObjects6= [];
gdjs.BattleCode.GDButtonPlayAgainObjects7= [];
gdjs.BattleCode.GDButtonPlayAgainObjects8= [];

gdjs.BattleCode.conditionTrue_0 = {val:false};
gdjs.BattleCode.condition0IsTrue_0 = {val:false};
gdjs.BattleCode.condition1IsTrue_0 = {val:false};
gdjs.BattleCode.condition2IsTrue_0 = {val:false};
gdjs.BattleCode.conditionTrue_1 = {val:false};
gdjs.BattleCode.condition0IsTrue_1 = {val:false};
gdjs.BattleCode.condition1IsTrue_1 = {val:false};
gdjs.BattleCode.condition2IsTrue_1 = {val:false};
gdjs.BattleCode.conditionTrue_2 = {val:false};
gdjs.BattleCode.condition0IsTrue_2 = {val:false};
gdjs.BattleCode.condition1IsTrue_2 = {val:false};
gdjs.BattleCode.condition2IsTrue_2 = {val:false};


gdjs.BattleCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.BattleCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Aim"), gdjs.BattleCode.GDAimObjects1);
gdjs.copyArray(runtimeScene.getObjects("Arrow"), gdjs.BattleCode.GDArrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects1);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects1);
gdjs.copyArray(runtimeScene.getObjects("ButtonPlay"), gdjs.BattleCode.GDButtonPlayObjects1);
gdjs.copyArray(runtimeScene.getObjects("ButtonPlayAgain"), gdjs.BattleCode.GDButtonPlayAgainObjects1);
gdjs.copyArray(runtimeScene.getObjects("Core"), gdjs.BattleCode.GDCoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("D"), gdjs.BattleCode.GDDObjects1);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.BattleCode.GDFloorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Key"), gdjs.BattleCode.GDKeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("S"), gdjs.BattleCode.GDSObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextBattleTurn"), gdjs.BattleCode.GDTextBattleTurnObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextBattleTurnDescription"), gdjs.BattleCode.GDTextBattleTurnDescriptionObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextBuildTurn"), gdjs.BattleCode.GDTextBuildTurnObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextBuildTurnDescription"), gdjs.BattleCode.GDTextBuildTurnDescriptionObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextContinue"), gdjs.BattleCode.GDTextContinueObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextExit"), gdjs.BattleCode.GDTextExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextGameOver"), gdjs.BattleCode.GDTextGameOverObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextGameOverWinner"), gdjs.BattleCode.GDTextGameOverWinnerObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextMoveBlocks"), gdjs.BattleCode.GDTextMoveBlocksObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextPauseTitle"), gdjs.BattleCode.GDTextPauseTitleObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextPlayer1Controls"), gdjs.BattleCode.GDTextPlayer1ControlsObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextPlayer2Controls"), gdjs.BattleCode.GDTextPlayer2ControlsObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextPlayerAgain"), gdjs.BattleCode.GDTextPlayerAgainObjects1);
gdjs.copyArray(runtimeScene.getObjects("W"), gdjs.BattleCode.GDWObjects1);
{for(var i = 0, len = gdjs.BattleCode.GDFloorObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDFloorObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.BattleCode.GDTextBuildTurnDescriptionObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBuildTurnDescriptionObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextBuildTurnObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBuildTurnObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.BattleCode.GDTextBattleTurnObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBattleTurnObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextBattleTurnDescriptionObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBattleTurnDescriptionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.BattleCode.GDTextGameOverObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextGameOverObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextGameOverWinnerObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextGameOverWinnerObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDButtonPlayObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDButtonPlayObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextPlayerAgainObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextPlayerAgainObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDButtonPlayAgainObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDButtonPlayAgainObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.BattleCode.GDTextPauseTitleObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextPauseTitleObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextContinueObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextContinueObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextExitObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextExitObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDAObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDAObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDArrowObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDArrowObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDWObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDWObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDSObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDSObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDDObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDDObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDKeyObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDKeyObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextPlayer1ControlsObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextPlayer1ControlsObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextPlayer2ControlsObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextPlayer2ControlsObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextMoveBlocksObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextMoveBlocksObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDAimObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDAimObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects1[i].setAnimationName((gdjs.RuntimeObject.getVariableString(gdjs.BattleCode.GDCoreObjects1[i].getVariables().getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects1[i].enableEffect("Glow_Player1", false);
}
}{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects1[i].enableEffect("Glow_Player2", false);
}
}{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects1[i].enableEffect("Glow_" + (gdjs.RuntimeObject.getVariableString(gdjs.BattleCode.GDCoreObjects1[i].getVariables().getFromIndex(1))), true);
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects1[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects1.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects1[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects1.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects1[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects1.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects1[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects1[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects1[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects1[i].resetTimer("tetris");
}
}}

}


};gdjs.BattleCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.BattleCode.GDCoreObjects2, gdjs.BattleCode.GDCoreObjects3);


gdjs.BattleCode.condition0IsTrue_0.val = false;
gdjs.BattleCode.condition1IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.GDCoreObjects3_1final.length = 0;gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.BattleCode.GDCoreObjects2, gdjs.BattleCode.GDCoreObjects4);

{gdjs.BattleCode.conditionTrue_2 = gdjs.BattleCode.condition0IsTrue_1;
gdjs.BattleCode.condition0IsTrue_2.val = false;
gdjs.BattleCode.condition1IsTrue_2.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCoreObjects4.length;i<l;++i) {
    if ( !(gdjs.BattleCode.GDCoreObjects4[i].getBehavior("Tween").exists("fadeOut")) ) {
        gdjs.BattleCode.condition0IsTrue_2.val = true;
        gdjs.BattleCode.GDCoreObjects4[k] = gdjs.BattleCode.GDCoreObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCoreObjects4.length = k;}if ( gdjs.BattleCode.condition0IsTrue_2.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCoreObjects4.length;i<l;++i) {
    if ( !(gdjs.BattleCode.GDCoreObjects4[i].getBehavior("Tween").exists("fadeIn")) ) {
        gdjs.BattleCode.condition1IsTrue_2.val = true;
        gdjs.BattleCode.GDCoreObjects4[k] = gdjs.BattleCode.GDCoreObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCoreObjects4.length = k;}}
gdjs.BattleCode.conditionTrue_2.val = true && gdjs.BattleCode.condition0IsTrue_2.val && gdjs.BattleCode.condition1IsTrue_2.val;
}
if( gdjs.BattleCode.condition0IsTrue_1.val ) {
    gdjs.BattleCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.BattleCode.GDCoreObjects4.length;j<jLen;++j) {
        if ( gdjs.BattleCode.GDCoreObjects3_1final.indexOf(gdjs.BattleCode.GDCoreObjects4[j]) === -1 )
            gdjs.BattleCode.GDCoreObjects3_1final.push(gdjs.BattleCode.GDCoreObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.BattleCode.GDCoreObjects2, gdjs.BattleCode.GDCoreObjects4);

for(var i = 0, k = 0, l = gdjs.BattleCode.GDCoreObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCoreObjects4[i].getBehavior("Tween").hasFinished("fadeIn") ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDCoreObjects4[k] = gdjs.BattleCode.GDCoreObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCoreObjects4.length = k;if( gdjs.BattleCode.condition1IsTrue_1.val ) {
    gdjs.BattleCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.BattleCode.GDCoreObjects4.length;j<jLen;++j) {
        if ( gdjs.BattleCode.GDCoreObjects3_1final.indexOf(gdjs.BattleCode.GDCoreObjects4[j]) === -1 )
            gdjs.BattleCode.GDCoreObjects3_1final.push(gdjs.BattleCode.GDCoreObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.BattleCode.GDCoreObjects3_1final, gdjs.BattleCode.GDCoreObjects3);
}
}
}if ( gdjs.BattleCode.condition0IsTrue_0.val ) {
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition1IsTrue_0;
gdjs.BattleCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10261356);
}
}}
if (gdjs.BattleCode.condition1IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCoreObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects3[i].getBehavior("Tween").addObjectOpacityTween("fadeOut", 0, "linear", 200, false);
}
}}

}


{

/* Reuse gdjs.BattleCode.GDCoreObjects2 */

gdjs.BattleCode.condition0IsTrue_0.val = false;
gdjs.BattleCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCoreObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCoreObjects2[i].getBehavior("Tween").hasFinished("fadeOut") ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCoreObjects2[k] = gdjs.BattleCode.GDCoreObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDCoreObjects2.length = k;}if ( gdjs.BattleCode.condition0IsTrue_0.val ) {
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition1IsTrue_0;
gdjs.BattleCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10262332);
}
}}
if (gdjs.BattleCode.condition1IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCoreObjects2 */
{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects2[i].getBehavior("Tween").addObjectOpacityTween("fadeIn", 255, "linear", 200, false);
}
}}

}


};gdjs.BattleCode.eventsList2 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects2[i].getVariableNumber(gdjs.BattleCode.GDBlockObjects2[i].getVariables().get("Health")) == 2 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockObjects2[k] = gdjs.BattleCode.GDBlockObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects2[i].getVariableNumber(gdjs.BattleCode.GDBlock1x2Objects2[i].getVariables().get("Health")) == 2 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock1x2Objects2[k] = gdjs.BattleCode.GDBlock1x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects2[i].getVariableNumber(gdjs.BattleCode.GDBlock2x1Objects2[i].getVariables().get("Health")) == 2 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x1Objects2[k] = gdjs.BattleCode.GDBlock2x1Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects2[i].getVariableNumber(gdjs.BattleCode.GDBlock2x2Objects2[i].getVariables().get("Health")) == 2 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x2Objects2[k] = gdjs.BattleCode.GDBlock2x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects2[i].getVariableNumber(gdjs.BattleCode.GDBlockLObjects2[i].getVariables().get("Health")) == 2 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockLObjects2[k] = gdjs.BattleCode.GDBlockLObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects2[i].getVariableNumber(gdjs.BattleCode.GDBlockIObjects2[i].getVariables().get("Health")) == 2 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockIObjects2[k] = gdjs.BattleCode.GDBlockIObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects2.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects2 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlockIObjects2 */
/* Reuse gdjs.BattleCode.GDBlockLObjects2 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects2[i].setAnimation(1);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects2[i].setAnimation(1);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects2[i].setAnimation(1);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects2[i].setAnimation(1);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects2[i].setAnimation(1);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects2[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects2[i].getVariableNumber(gdjs.BattleCode.GDBlockObjects2[i].getVariables().get("Health")) == 1 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockObjects2[k] = gdjs.BattleCode.GDBlockObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects2[i].getVariableNumber(gdjs.BattleCode.GDBlock1x2Objects2[i].getVariables().get("Health")) == 1 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock1x2Objects2[k] = gdjs.BattleCode.GDBlock1x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects2[i].getVariableNumber(gdjs.BattleCode.GDBlock2x1Objects2[i].getVariables().get("Health")) == 1 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x1Objects2[k] = gdjs.BattleCode.GDBlock2x1Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects2[i].getVariableNumber(gdjs.BattleCode.GDBlock2x2Objects2[i].getVariables().get("Health")) == 1 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x2Objects2[k] = gdjs.BattleCode.GDBlock2x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects2[i].getVariableNumber(gdjs.BattleCode.GDBlockLObjects2[i].getVariables().get("Health")) == 1 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockLObjects2[k] = gdjs.BattleCode.GDBlockLObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects2[i].getVariableNumber(gdjs.BattleCode.GDBlockIObjects2[i].getVariables().get("Health")) == 1 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockIObjects2[k] = gdjs.BattleCode.GDBlockIObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects2.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects2 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlockIObjects2 */
/* Reuse gdjs.BattleCode.GDBlockLObjects2 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects2[i].setAnimation(2);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects2[i].setAnimation(2);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects2[i].setAnimation(2);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects2[i].setAnimation(2);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects2[i].setAnimation(2);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects2[i].setAnimation(2);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Core"), gdjs.BattleCode.GDCoreObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCoreObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCoreObjects2[i].getVariableBoolean(gdjs.BattleCode.GDCoreObjects2[i].getVariables().getFromIndex(2), true) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCoreObjects2[k] = gdjs.BattleCode.GDCoreObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDCoreObjects2.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Core"), gdjs.BattleCode.GDCoreObjects1);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCoreObjects1.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCoreObjects1[i].getTimerElapsedTimeInSecondsOrNaN("invulnerableCooldown") >= (gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCoreObjects1[i].getVariables().getFromIndex(3))) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCoreObjects1[k] = gdjs.BattleCode.GDCoreObjects1[i];
        ++k;
    }
}
gdjs.BattleCode.GDCoreObjects1.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCoreObjects1 */
{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects1[i].setVariableBoolean(gdjs.BattleCode.GDCoreObjects1[i].getVariables().getFromIndex(2), false);
}
}{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects1[i].removeTimer("invulnerableCooldown");
}
}{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects1[i].getBehavior("Tween").removeTween("fadeOut");
}
}{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects1[i].getBehavior("Tween").removeTween("fadeIn");
}
}{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects1[i].setOpacity(255);
}
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDRoofObjects2Objects = Hashtable.newFrom({"Roof": gdjs.BattleCode.GDRoofObjects2});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects2ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlockLObjects2ObjectsGDgdjs_46BattleCode_46GDBlockIObjects2ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects2Objects = Hashtable.newFrom({"Block": gdjs.BattleCode.GDBlockObjects2, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects2, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects2, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects2, "BlockL": gdjs.BattleCode.GDBlockLObjects2, "BlockI": gdjs.BattleCode.GDBlockIObjects2, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects2});gdjs.BattleCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.BattleCode.GDRoofObjects2, gdjs.BattleCode.GDRoofObjects3);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDRoofObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDRoofObjects3[i].getVariableString(gdjs.BattleCode.GDRoofObjects3[i].getVariables().getFromIndex(0)) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDRoofObjects3[k] = gdjs.BattleCode.GDRoofObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDRoofObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(17).setString("Player 2");
}}

}


{

gdjs.copyArray(gdjs.BattleCode.GDRoofObjects2, gdjs.BattleCode.GDRoofObjects3);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDRoofObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDRoofObjects3[i].getVariableString(gdjs.BattleCode.GDRoofObjects3[i].getVariables().getFromIndex(0)) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDRoofObjects3[k] = gdjs.BattleCode.GDRoofObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDRoofObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(17).setString("Player 1");
}}

}


{


{
{runtimeScene.getVariables().getFromIndex(2).setString("gameOver");
}}

}


};gdjs.BattleCode.eventsList4 = function(runtimeScene) {

{

/* Reuse gdjs.BattleCode.GDBlockObjects2 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects2 */
/* Reuse gdjs.BattleCode.GDBlockIObjects2 */
/* Reuse gdjs.BattleCode.GDBlockLObjects2 */

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockObjects2[i].getVariables().get("Fixed"), true) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockObjects2[k] = gdjs.BattleCode.GDBlockObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects2[i].getVariables().get("Fixed"), true) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock1x2Objects2[k] = gdjs.BattleCode.GDBlock1x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects2[i].getVariables().get("Fixed"), true) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x1Objects2[k] = gdjs.BattleCode.GDBlock2x1Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects2[i].getVariables().get("Fixed"), true) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x2Objects2[k] = gdjs.BattleCode.GDBlock2x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockLObjects2[i].getVariables().get("Fixed"), true) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockLObjects2[k] = gdjs.BattleCode.GDBlockLObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockIObjects2[i].getVariables().get("Fixed"), true) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockIObjects2[k] = gdjs.BattleCode.GDBlockIObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects2[i].getVariables().get("Fixed"), true) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockCannonObjects2[k] = gdjs.BattleCode.GDBlockCannonObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects2.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList5 = function(runtimeScene) {

};gdjs.BattleCode.eventsList6 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("TextBattleTimer"), gdjs.BattleCode.GDTextBattleTimerObjects4);
gdjs.copyArray(runtimeScene.getObjects("TextBuildTurn"), gdjs.BattleCode.GDTextBuildTurnObjects4);
gdjs.copyArray(runtimeScene.getObjects("TextBuildTurnDescription"), gdjs.BattleCode.GDTextBuildTurnDescriptionObjects4);
{gdjs.evtTools.debuggerTools.log("Build start", "info", "");
}{for(var i = 0, len = gdjs.BattleCode.GDTextBattleTimerObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBattleTimerObjects4[i].setString("--");
}
}{runtimeScene.getVariables().getFromIndex(4).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(5).setNumber(0);
}{runtimeScene.getVariables().get("index").setNumber(0);
}{runtimeScene.getVariables().get("turnBlocksFixedCount").setNumber(0);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "turnTransition");
}{for(var i = 0, len = gdjs.BattleCode.GDTextBuildTurnDescriptionObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBuildTurnDescriptionObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDTextBuildTurnObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBuildTurnObjects4[i].hide(false);
}
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "assets\\sound\\music\\Friendly-Machines.mp3", 1, false, 5, 1);
}{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getVariables().getFromIndex(7));
}}

}


{


gdjs.BattleCode.repeatCount5 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(11)) - 1;
for(gdjs.BattleCode.repeatIndex5 = 0;gdjs.BattleCode.repeatIndex5 < gdjs.BattleCode.repeatCount5;++gdjs.BattleCode.repeatIndex5) {

if (true)
{
{runtimeScene.getVariables().getFromIndex(7).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("index"))).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(6).getChild(gdjs.random(gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getVariables().getFromIndex(6)) - 1))));
}{runtimeScene.getVariables().get("index").add(1);
}}
}

}


{


{
{runtimeScene.getVariables().get("cannonIndex").setNumber(gdjs.randomInRange(0, gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getVariables().getFromIndex(7)) - 1));
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects4Objects = Hashtable.newFrom({"Block": gdjs.BattleCode.GDBlockObjects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock1x2Objects4Objects = Hashtable.newFrom({"Block1x2": gdjs.BattleCode.GDBlock1x2Objects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x1Objects4Objects = Hashtable.newFrom({"Block2x1": gdjs.BattleCode.GDBlock2x1Objects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x2Objects4Objects = Hashtable.newFrom({"Block2x2": gdjs.BattleCode.GDBlock2x2Objects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockLObjects4Objects = Hashtable.newFrom({"BlockL": gdjs.BattleCode.GDBlockLObjects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockIObjects3Objects = Hashtable.newFrom({"BlockI": gdjs.BattleCode.GDBlockIObjects3});gdjs.BattleCode.eventsList7 = function(runtimeScene) {

{


{
{runtimeScene.getVariables().get("CurrentBlock").setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(7).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)))));
}{runtimeScene.getVariables().get("CurrentPlayer").setString("Player1");
}}

}


{



}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects4);
gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.GDBlockObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}{runtimeScene.getVariables().getFromIndex(19).add(1);
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block1x2";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects4);
gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.GDBlock1x2Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock1x2Objects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block2x1";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects4);
gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.GDBlock2x1Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x1Objects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block2x2";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects4);
gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.GDBlock2x2Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x2Objects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "BlockL";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.GDBlockLObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockLObjects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "BlockI";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects3);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects3);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects3);
/* Reuse gdjs.BattleCode.GDSpawnObjects3 */
gdjs.BattleCode.GDBlockIObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockIObjects3Objects, (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].returnVariable(gdjs.BattleCode.GDBlockObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].returnVariable(gdjs.BattleCode.GDBlockLObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].returnVariable(gdjs.BattleCode.GDBlockIObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].resetTimer("tetris");
}
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects4Objects = Hashtable.newFrom({"Block": gdjs.BattleCode.GDBlockObjects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock1x2Objects4Objects = Hashtable.newFrom({"Block1x2": gdjs.BattleCode.GDBlock1x2Objects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x1Objects4Objects = Hashtable.newFrom({"Block2x1": gdjs.BattleCode.GDBlock2x1Objects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x2Objects4Objects = Hashtable.newFrom({"Block2x2": gdjs.BattleCode.GDBlock2x2Objects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockLObjects4Objects = Hashtable.newFrom({"BlockL": gdjs.BattleCode.GDBlockLObjects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockIObjects3Objects = Hashtable.newFrom({"BlockI": gdjs.BattleCode.GDBlockIObjects3});gdjs.BattleCode.eventsList8 = function(runtimeScene) {

{


{
{runtimeScene.getVariables().get("CurrentBlock").setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(7).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(5)))));
}{runtimeScene.getVariables().get("CurrentPlayer").setString("Player2");
}}

}


{



}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects4);
gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.GDBlockObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}{runtimeScene.getVariables().getFromIndex(19).add(1);
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block1x2";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects4);
gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.GDBlock1x2Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock1x2Objects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block2x1";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects4);
gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.GDBlock2x1Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x1Objects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block2x2";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects4);
gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.GDBlock2x2Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x2Objects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "BlockL";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.GDBlockLObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockLObjects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "BlockI";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects3);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects3);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects3);
/* Reuse gdjs.BattleCode.GDSpawnObjects3 */
gdjs.BattleCode.GDBlockIObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockIObjects3Objects, (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].returnVariable(gdjs.BattleCode.GDBlockObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].returnVariable(gdjs.BattleCode.GDBlockLObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].returnVariable(gdjs.BattleCode.GDBlockIObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].resetTimer("tetris");
}
}}

}


};gdjs.BattleCode.eventsList9 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spawn"), gdjs.BattleCode.GDSpawnObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDSpawnObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDSpawnObjects3[i].getVariableString(gdjs.BattleCode.GDSpawnObjects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDSpawnObjects3[k] = gdjs.BattleCode.GDSpawnObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDSpawnObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList7(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spawn"), gdjs.BattleCode.GDSpawnObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDSpawnObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDSpawnObjects3[i].getVariableString(gdjs.BattleCode.GDSpawnObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDSpawnObjects3[k] = gdjs.BattleCode.GDSpawnObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDSpawnObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList8(runtimeScene);} //End of subevents
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("TextBuildTurn"), gdjs.BattleCode.GDTextBuildTurnObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextBuildTurnDescription"), gdjs.BattleCode.GDTextBuildTurnDescriptionObjects2);
{for(var i = 0, len = gdjs.BattleCode.GDTextBuildTurnDescriptionObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBuildTurnDescriptionObjects2[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextBuildTurnObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBuildTurnObjects2[i].hide();
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "turnTransition");
}{runtimeScene.getVariables().getFromIndex(3).setString("main");
}}

}


};gdjs.BattleCode.eventsList10 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10267940);
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList6(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "turnTransition") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1));
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects4ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects4ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects4ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects4ObjectsGDgdjs_46BattleCode_46GDBlockLObjects4ObjectsGDgdjs_46BattleCode_46GDBlockIObjects4ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects4Objects = Hashtable.newFrom({"Block": gdjs.BattleCode.GDBlockObjects4, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects4, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects4, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects4, "BlockL": gdjs.BattleCode.GDBlockLObjects4, "BlockI": gdjs.BattleCode.GDBlockIObjects4, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDFloorObjects4ObjectsGDgdjs_46BattleCode_46GDCoreObjects4ObjectsGDgdjs_46BattleCode_46GDBlockObjects4ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects4ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects4ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects4ObjectsGDgdjs_46BattleCode_46GDBlockIObjects4ObjectsGDgdjs_46BattleCode_46GDBlockLObjects4ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects4Objects = Hashtable.newFrom({"Floor": gdjs.BattleCode.GDFloorObjects4, "Core": gdjs.BattleCode.GDCoreObjects4, "Block": gdjs.BattleCode.GDBlockObjects4, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects4, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects4, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects4, "BlockI": gdjs.BattleCode.GDBlockIObjects4, "BlockL": gdjs.BattleCode.GDBlockLObjects4, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects4});gdjs.BattleCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects5);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects5);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects5);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects5);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects5);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects5);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects5);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects5[i].getVariableBoolean(gdjs.BattleCode.GDBlockObjects5[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects5[k] = gdjs.BattleCode.GDBlockObjects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects5[i].getVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects5[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects5[k] = gdjs.BattleCode.GDBlock1x2Objects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects5[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects5[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects5[k] = gdjs.BattleCode.GDBlock2x1Objects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects5[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects5[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects5[k] = gdjs.BattleCode.GDBlock2x2Objects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects5[i].getVariableBoolean(gdjs.BattleCode.GDBlockLObjects5[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects5[k] = gdjs.BattleCode.GDBlockLObjects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects5[i].getVariableBoolean(gdjs.BattleCode.GDBlockIObjects5[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects5[k] = gdjs.BattleCode.GDBlockIObjects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects5[i].getVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects5[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects5[k] = gdjs.BattleCode.GDBlockCannonObjects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects5.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects5[i].getVariableString(gdjs.BattleCode.GDBlockObjects5[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects5[k] = gdjs.BattleCode.GDBlockObjects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects5[i].getVariableString(gdjs.BattleCode.GDBlock1x2Objects5[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects5[k] = gdjs.BattleCode.GDBlock1x2Objects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects5[i].getVariableString(gdjs.BattleCode.GDBlock2x1Objects5[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects5[k] = gdjs.BattleCode.GDBlock2x1Objects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects5[i].getVariableString(gdjs.BattleCode.GDBlock2x2Objects5[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects5[k] = gdjs.BattleCode.GDBlock2x2Objects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects5[i].getVariableString(gdjs.BattleCode.GDBlockLObjects5[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects5[k] = gdjs.BattleCode.GDBlockLObjects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects5[i].getVariableString(gdjs.BattleCode.GDBlockIObjects5[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects5[k] = gdjs.BattleCode.GDBlockIObjects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects5.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects5.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects5[i].getVariableString(gdjs.BattleCode.GDBlockCannonObjects5[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects5[k] = gdjs.BattleCode.GDBlockCannonObjects5[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects5.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects5 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects5 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects5 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects5 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects5 */
/* Reuse gdjs.BattleCode.GDBlockIObjects5 */
/* Reuse gdjs.BattleCode.GDBlockLObjects5 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects5[i].setX(gdjs.BattleCode.GDBlockObjects5[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects5[i].setX(gdjs.BattleCode.GDBlock1x2Objects5[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects5[i].setX(gdjs.BattleCode.GDBlock2x1Objects5[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects5[i].setX(gdjs.BattleCode.GDBlock2x2Objects5[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects5[i].setX(gdjs.BattleCode.GDBlockLObjects5[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects5[i].setX(gdjs.BattleCode.GDBlockIObjects5[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects5[i].setX(gdjs.BattleCode.GDBlockCannonObjects5[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects4);
gdjs.copyArray(runtimeScene.getObjects("Core"), gdjs.BattleCode.GDCoreObjects4);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.BattleCode.GDFloorObjects4);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
gdjs.BattleCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects4ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects4ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects4ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects4ObjectsGDgdjs_46BattleCode_46GDBlockLObjects4ObjectsGDgdjs_46BattleCode_46GDBlockIObjects4ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects4Objects, gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDFloorObjects4ObjectsGDgdjs_46BattleCode_46GDCoreObjects4ObjectsGDgdjs_46BattleCode_46GDBlockObjects4ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects4ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects4ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects4ObjectsGDgdjs_46BattleCode_46GDBlockIObjects4ObjectsGDgdjs_46BattleCode_46GDBlockLObjects4ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects4Objects, false, runtimeScene, true);
}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects4[k] = gdjs.BattleCode.GDBlockObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects4[i].getVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects4[k] = gdjs.BattleCode.GDBlock1x2Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects4[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects4[k] = gdjs.BattleCode.GDBlock2x1Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects4[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects4[k] = gdjs.BattleCode.GDBlock2x2Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects4[k] = gdjs.BattleCode.GDBlockLObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects4[k] = gdjs.BattleCode.GDBlockIObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects4[k] = gdjs.BattleCode.GDBlockCannonObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects4.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects4 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects4 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects4 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects4 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects4 */
/* Reuse gdjs.BattleCode.GDBlockIObjects4 */
/* Reuse gdjs.BattleCode.GDBlockLObjects4 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].setX(gdjs.BattleCode.GDBlockObjects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].setX(gdjs.BattleCode.GDBlock1x2Objects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].setX(gdjs.BattleCode.GDBlock2x1Objects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].setX(gdjs.BattleCode.GDBlock2x2Objects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].setX(gdjs.BattleCode.GDBlockLObjects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].setX(gdjs.BattleCode.GDBlockIObjects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].setX(gdjs.BattleCode.GDBlockCannonObjects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects3ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlockLObjects3ObjectsGDgdjs_46BattleCode_46GDBlockIObjects3ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects = Hashtable.newFrom({"Block": gdjs.BattleCode.GDBlockObjects3, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects3, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects3, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects3, "BlockL": gdjs.BattleCode.GDBlockLObjects3, "BlockI": gdjs.BattleCode.GDBlockIObjects3, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects3});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDFloorObjects3ObjectsGDgdjs_46BattleCode_46GDCoreObjects3ObjectsGDgdjs_46BattleCode_46GDBlockObjects3ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects3ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlockIObjects3ObjectsGDgdjs_46BattleCode_46GDBlockLObjects3ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects = Hashtable.newFrom({"Floor": gdjs.BattleCode.GDFloorObjects3, "Core": gdjs.BattleCode.GDCoreObjects3, "Block": gdjs.BattleCode.GDBlockObjects3, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects3, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects3, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects3, "BlockI": gdjs.BattleCode.GDBlockIObjects3, "BlockL": gdjs.BattleCode.GDBlockLObjects3, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects3});gdjs.BattleCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects4);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects4[k] = gdjs.BattleCode.GDBlockObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects4[i].getVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects4[k] = gdjs.BattleCode.GDBlock1x2Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects4[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects4[k] = gdjs.BattleCode.GDBlock2x1Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects4[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects4[k] = gdjs.BattleCode.GDBlock2x2Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects4[k] = gdjs.BattleCode.GDBlockLObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects4[k] = gdjs.BattleCode.GDBlockIObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects4[k] = gdjs.BattleCode.GDBlockCannonObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects4.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects4[i].getVariableString(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects4[k] = gdjs.BattleCode.GDBlockObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects4[i].getVariableString(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects4[k] = gdjs.BattleCode.GDBlock1x2Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects4[i].getVariableString(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects4[k] = gdjs.BattleCode.GDBlock2x1Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects4[i].getVariableString(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects4[k] = gdjs.BattleCode.GDBlock2x2Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects4[i].getVariableString(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects4[k] = gdjs.BattleCode.GDBlockLObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects4[i].getVariableString(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects4[k] = gdjs.BattleCode.GDBlockIObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects4[i].getVariableString(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects4[k] = gdjs.BattleCode.GDBlockCannonObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects4.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects4 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects4 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects4 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects4 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects4 */
/* Reuse gdjs.BattleCode.GDBlockIObjects4 */
/* Reuse gdjs.BattleCode.GDBlockLObjects4 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].setX(gdjs.BattleCode.GDBlockObjects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].setX(gdjs.BattleCode.GDBlock1x2Objects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].setX(gdjs.BattleCode.GDBlock2x1Objects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].setX(gdjs.BattleCode.GDBlock2x2Objects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].setX(gdjs.BattleCode.GDBlockLObjects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].setX(gdjs.BattleCode.GDBlockIObjects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].setX(gdjs.BattleCode.GDBlockCannonObjects4[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects3);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects3);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects3);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects3);
gdjs.copyArray(runtimeScene.getObjects("Core"), gdjs.BattleCode.GDCoreObjects3);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.BattleCode.GDFloorObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
gdjs.BattleCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects3ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlockLObjects3ObjectsGDgdjs_46BattleCode_46GDBlockIObjects3ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects, gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDFloorObjects3ObjectsGDgdjs_46BattleCode_46GDCoreObjects3ObjectsGDgdjs_46BattleCode_46GDBlockObjects3ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects3ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlockIObjects3ObjectsGDgdjs_46BattleCode_46GDBlockLObjects3ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects, false, runtimeScene, true);
}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects3[k] = gdjs.BattleCode.GDBlockObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects3[i].getVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects3[k] = gdjs.BattleCode.GDBlock1x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects3[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects3[k] = gdjs.BattleCode.GDBlock2x1Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects3[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects3[k] = gdjs.BattleCode.GDBlock2x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockLObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects3[k] = gdjs.BattleCode.GDBlockLObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockIObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects3[k] = gdjs.BattleCode.GDBlockIObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects3[k] = gdjs.BattleCode.GDBlockCannonObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects3.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects3 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects3 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects3 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects3 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects3 */
/* Reuse gdjs.BattleCode.GDBlockIObjects3 */
/* Reuse gdjs.BattleCode.GDBlockLObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].setX(gdjs.BattleCode.GDBlockObjects3[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].setX(gdjs.BattleCode.GDBlock1x2Objects3[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].setX(gdjs.BattleCode.GDBlock2x1Objects3[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].setX(gdjs.BattleCode.GDBlock2x2Objects3[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].setX(gdjs.BattleCode.GDBlockLObjects3[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].setX(gdjs.BattleCode.GDBlockIObjects3[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].setX(gdjs.BattleCode.GDBlockCannonObjects3[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
}}

}


};gdjs.BattleCode.eventsList13 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList11(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects3ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlockLObjects3ObjectsGDgdjs_46BattleCode_46GDBlockIObjects3ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects = Hashtable.newFrom({"Block": gdjs.BattleCode.GDBlockObjects3, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects3, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects3, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects3, "BlockL": gdjs.BattleCode.GDBlockLObjects3, "BlockI": gdjs.BattleCode.GDBlockIObjects3, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects3});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDFloorObjects3ObjectsGDgdjs_46BattleCode_46GDCoreObjects3ObjectsGDgdjs_46BattleCode_46GDBlockObjects3ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects3ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlockIObjects3ObjectsGDgdjs_46BattleCode_46GDBlockLObjects3ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects = Hashtable.newFrom({"Floor": gdjs.BattleCode.GDFloorObjects3, "Core": gdjs.BattleCode.GDCoreObjects3, "Block": gdjs.BattleCode.GDBlockObjects3, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects3, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects3, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects3, "BlockI": gdjs.BattleCode.GDBlockIObjects3, "BlockL": gdjs.BattleCode.GDBlockLObjects3, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects3});gdjs.BattleCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects4);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects4);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects4);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects4);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects4);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects4[k] = gdjs.BattleCode.GDBlockObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects4[i].getVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects4[k] = gdjs.BattleCode.GDBlock1x2Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects4[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects4[k] = gdjs.BattleCode.GDBlock2x1Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects4[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects4[k] = gdjs.BattleCode.GDBlock2x2Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects4[k] = gdjs.BattleCode.GDBlockLObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects4[k] = gdjs.BattleCode.GDBlockIObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects4[i].getVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects4[k] = gdjs.BattleCode.GDBlockCannonObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects4.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects4[i].getVariableString(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects4[k] = gdjs.BattleCode.GDBlockObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects4[i].getVariableString(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects4[k] = gdjs.BattleCode.GDBlock1x2Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects4[i].getVariableString(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects4[k] = gdjs.BattleCode.GDBlock2x1Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects4[i].getVariableString(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects4[k] = gdjs.BattleCode.GDBlock2x2Objects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects4[i].getVariableString(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects4[k] = gdjs.BattleCode.GDBlockLObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects4[i].getVariableString(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects4[k] = gdjs.BattleCode.GDBlockIObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects4.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects4[i].getVariableString(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects4[k] = gdjs.BattleCode.GDBlockCannonObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects4.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects4 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects4 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects4 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects4 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects4 */
/* Reuse gdjs.BattleCode.GDBlockIObjects4 */
/* Reuse gdjs.BattleCode.GDBlockLObjects4 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].setX(gdjs.BattleCode.GDBlockObjects4[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].setX(gdjs.BattleCode.GDBlock1x2Objects4[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].setX(gdjs.BattleCode.GDBlock2x1Objects4[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].setX(gdjs.BattleCode.GDBlock2x2Objects4[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].setX(gdjs.BattleCode.GDBlockLObjects4[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].setX(gdjs.BattleCode.GDBlockIObjects4[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].setX(gdjs.BattleCode.GDBlockCannonObjects4[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects3);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects3);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects3);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects3);
gdjs.copyArray(runtimeScene.getObjects("Core"), gdjs.BattleCode.GDCoreObjects3);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.BattleCode.GDFloorObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
gdjs.BattleCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects3ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlockLObjects3ObjectsGDgdjs_46BattleCode_46GDBlockIObjects3ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects, gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDFloorObjects3ObjectsGDgdjs_46BattleCode_46GDCoreObjects3ObjectsGDgdjs_46BattleCode_46GDBlockObjects3ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects3ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlockIObjects3ObjectsGDgdjs_46BattleCode_46GDBlockLObjects3ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects, false, runtimeScene, true);
}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects3[k] = gdjs.BattleCode.GDBlockObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects3[i].getVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects3[k] = gdjs.BattleCode.GDBlock1x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects3[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects3[k] = gdjs.BattleCode.GDBlock2x1Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects3[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects3[k] = gdjs.BattleCode.GDBlock2x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockLObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects3[k] = gdjs.BattleCode.GDBlockLObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockIObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects3[k] = gdjs.BattleCode.GDBlockIObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects3[k] = gdjs.BattleCode.GDBlockCannonObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects3.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects3 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects3 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects3 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects3 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects3 */
/* Reuse gdjs.BattleCode.GDBlockIObjects3 */
/* Reuse gdjs.BattleCode.GDBlockLObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].setX(gdjs.BattleCode.GDBlockObjects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].setX(gdjs.BattleCode.GDBlock1x2Objects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].setX(gdjs.BattleCode.GDBlock2x1Objects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].setX(gdjs.BattleCode.GDBlock2x2Objects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].setX(gdjs.BattleCode.GDBlockLObjects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].setX(gdjs.BattleCode.GDBlockIObjects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].setX(gdjs.BattleCode.GDBlockCannonObjects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects2ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlockLObjects2ObjectsGDgdjs_46BattleCode_46GDBlockIObjects2ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects2Objects = Hashtable.newFrom({"Block": gdjs.BattleCode.GDBlockObjects2, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects2, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects2, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects2, "BlockL": gdjs.BattleCode.GDBlockLObjects2, "BlockI": gdjs.BattleCode.GDBlockIObjects2, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects2});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDFloorObjects2ObjectsGDgdjs_46BattleCode_46GDCoreObjects2ObjectsGDgdjs_46BattleCode_46GDBlockObjects2ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects2ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlockIObjects2ObjectsGDgdjs_46BattleCode_46GDBlockLObjects2ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects2Objects = Hashtable.newFrom({"Floor": gdjs.BattleCode.GDFloorObjects2, "Core": gdjs.BattleCode.GDCoreObjects2, "Block": gdjs.BattleCode.GDBlockObjects2, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects2, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects2, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects2, "BlockI": gdjs.BattleCode.GDBlockIObjects2, "BlockL": gdjs.BattleCode.GDBlockLObjects2, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects2});gdjs.BattleCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects3);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects3);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects3);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects3[k] = gdjs.BattleCode.GDBlockObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects3[i].getVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects3[k] = gdjs.BattleCode.GDBlock1x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects3[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects3[k] = gdjs.BattleCode.GDBlock2x1Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects3[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects3[k] = gdjs.BattleCode.GDBlock2x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockLObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects3[k] = gdjs.BattleCode.GDBlockLObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockIObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects3[k] = gdjs.BattleCode.GDBlockIObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects3[i].getVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects3[k] = gdjs.BattleCode.GDBlockCannonObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects3.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects3[i].getVariableString(gdjs.BattleCode.GDBlockObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects3[k] = gdjs.BattleCode.GDBlockObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects3[i].getVariableString(gdjs.BattleCode.GDBlock1x2Objects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects3[k] = gdjs.BattleCode.GDBlock1x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects3[i].getVariableString(gdjs.BattleCode.GDBlock2x1Objects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects3[k] = gdjs.BattleCode.GDBlock2x1Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects3[i].getVariableString(gdjs.BattleCode.GDBlock2x2Objects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects3[k] = gdjs.BattleCode.GDBlock2x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects3[i].getVariableString(gdjs.BattleCode.GDBlockLObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects3[k] = gdjs.BattleCode.GDBlockLObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects3[i].getVariableString(gdjs.BattleCode.GDBlockIObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects3[k] = gdjs.BattleCode.GDBlockIObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects3[i].getVariableString(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects3[k] = gdjs.BattleCode.GDBlockCannonObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects3.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects3 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects3 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects3 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects3 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects3 */
/* Reuse gdjs.BattleCode.GDBlockIObjects3 */
/* Reuse gdjs.BattleCode.GDBlockLObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].setX(gdjs.BattleCode.GDBlockObjects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].setX(gdjs.BattleCode.GDBlock1x2Objects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].setX(gdjs.BattleCode.GDBlock2x1Objects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].setX(gdjs.BattleCode.GDBlock2x2Objects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].setX(gdjs.BattleCode.GDBlockLObjects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].setX(gdjs.BattleCode.GDBlockIObjects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].setX(gdjs.BattleCode.GDBlockCannonObjects3[i].getX() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects2);
gdjs.copyArray(runtimeScene.getObjects("Core"), gdjs.BattleCode.GDCoreObjects2);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.BattleCode.GDFloorObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
gdjs.BattleCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects2ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlockLObjects2ObjectsGDgdjs_46BattleCode_46GDBlockIObjects2ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects2Objects, gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDFloorObjects2ObjectsGDgdjs_46BattleCode_46GDCoreObjects2ObjectsGDgdjs_46BattleCode_46GDBlockObjects2ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects2ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlockIObjects2ObjectsGDgdjs_46BattleCode_46GDBlockLObjects2ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects2Objects, false, runtimeScene, true);
}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects2[k] = gdjs.BattleCode.GDBlockObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects2[k] = gdjs.BattleCode.GDBlock1x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects2[k] = gdjs.BattleCode.GDBlock2x1Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects2[k] = gdjs.BattleCode.GDBlock2x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockLObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects2[k] = gdjs.BattleCode.GDBlockLObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockIObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects2[k] = gdjs.BattleCode.GDBlockIObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects2[k] = gdjs.BattleCode.GDBlockCannonObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects2.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects2 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects2 */
/* Reuse gdjs.BattleCode.GDBlockIObjects2 */
/* Reuse gdjs.BattleCode.GDBlockLObjects2 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects2[i].setX(gdjs.BattleCode.GDBlockObjects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects2[i].setX(gdjs.BattleCode.GDBlock1x2Objects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects2[i].setX(gdjs.BattleCode.GDBlock2x1Objects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects2[i].setX(gdjs.BattleCode.GDBlock2x2Objects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects2[i].setX(gdjs.BattleCode.GDBlockLObjects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects2[i].setX(gdjs.BattleCode.GDBlockIObjects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects2[i].setX(gdjs.BattleCode.GDBlockCannonObjects2[i].getX() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
}}

}


};gdjs.BattleCode.eventsList16 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Left");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList14(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Right");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList17 = function(runtimeScene) {

{


gdjs.BattleCode.eventsList13(runtimeScene);
}


{


gdjs.BattleCode.eventsList16(runtimeScene);
}


};gdjs.BattleCode.eventsList18 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(20), false);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList19 = function(runtimeScene) {

{

/* Reuse gdjs.BattleCode.GDBlockObjects2 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects2 */
/* Reuse gdjs.BattleCode.GDBlockIObjects2 */
/* Reuse gdjs.BattleCode.GDBlockLObjects2 */

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects2[i].getTimerElapsedTimeInSecondsOrNaN("tetris") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockObjects2[k] = gdjs.BattleCode.GDBlockObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects2[i].getTimerElapsedTimeInSecondsOrNaN("tetris") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock1x2Objects2[k] = gdjs.BattleCode.GDBlock1x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects2[i].getTimerElapsedTimeInSecondsOrNaN("tetris") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x1Objects2[k] = gdjs.BattleCode.GDBlock2x1Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects2[i].getTimerElapsedTimeInSecondsOrNaN("tetris") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x2Objects2[k] = gdjs.BattleCode.GDBlock2x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects2[i].getTimerElapsedTimeInSecondsOrNaN("tetris") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockLObjects2[k] = gdjs.BattleCode.GDBlockLObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects2[i].getTimerElapsedTimeInSecondsOrNaN("tetris") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockIObjects2[k] = gdjs.BattleCode.GDBlockIObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects2[i].getTimerElapsedTimeInSecondsOrNaN("tetris") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockCannonObjects2[k] = gdjs.BattleCode.GDBlockCannonObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects2.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects2 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects2 */
/* Reuse gdjs.BattleCode.GDBlockIObjects2 */
/* Reuse gdjs.BattleCode.GDBlockLObjects2 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects2[i].setY(gdjs.BattleCode.GDBlockObjects2[i].getY() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects2[i].setY(gdjs.BattleCode.GDBlock1x2Objects2[i].getY() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects2[i].setY(gdjs.BattleCode.GDBlock2x1Objects2[i].getY() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects2[i].setY(gdjs.BattleCode.GDBlock2x2Objects2[i].getY() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects2[i].setY(gdjs.BattleCode.GDBlockLObjects2[i].getY() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects2[i].setY(gdjs.BattleCode.GDBlockIObjects2[i].getY() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects2[i].setY(gdjs.BattleCode.GDBlockCannonObjects2[i].getY() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects2[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects2[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects2[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects2[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects2[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects2[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects2[i].resetTimer("tetris");
}
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects2ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlockLObjects2ObjectsGDgdjs_46BattleCode_46GDBlockIObjects2ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects2Objects = Hashtable.newFrom({"Block": gdjs.BattleCode.GDBlockObjects2, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects2, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects2, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects2, "BlockL": gdjs.BattleCode.GDBlockLObjects2, "BlockI": gdjs.BattleCode.GDBlockIObjects2, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects2});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDFloorObjects2ObjectsGDgdjs_46BattleCode_46GDCoreObjects2ObjectsGDgdjs_46BattleCode_46GDBlockObjects2ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects2ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlockIObjects2ObjectsGDgdjs_46BattleCode_46GDBlockLObjects2ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects2Objects = Hashtable.newFrom({"Floor": gdjs.BattleCode.GDFloorObjects2, "Core": gdjs.BattleCode.GDCoreObjects2, "Block": gdjs.BattleCode.GDBlockObjects2, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects2, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects2, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects2, "BlockI": gdjs.BattleCode.GDBlockIObjects2, "BlockL": gdjs.BattleCode.GDBlockLObjects2, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects2});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockCannonObjects4Objects = Hashtable.newFrom({"BlockCannon": gdjs.BattleCode.GDBlockCannonObjects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDCannonAimObjects4Objects = Hashtable.newFrom({"CannonAim": gdjs.BattleCode.GDCannonAimObjects4});gdjs.BattleCode.eventsList20 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects3, gdjs.BattleCode.GDBlockObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects3, gdjs.BattleCode.GDBlock1x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects3, gdjs.BattleCode.GDBlock2x1Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects3, gdjs.BattleCode.GDBlock2x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects3, gdjs.BattleCode.GDBlockIObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects3, gdjs.BattleCode.GDBlockLObjects4);

/* Reuse gdjs.BattleCode.GDSpawnObjects4 */
gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects3, gdjs.BattleCode.GDBlockCannonObjects4);

gdjs.BattleCode.GDCannonAimObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockCannonObjects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().getFromIndex(1)).setString("Player1");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDCannonAimObjects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].setZOrder(gdjs.BattleCode.GDCannonAimObjects4[i].getZOrder() + (1));
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].returnVariable(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().get("ID")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].returnVariable(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().get("Player")).setString("Player1");
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}{gdjs.evtTools.variable.valuePush(runtimeScene.getVariables().getFromIndex(13), (gdjs.RuntimeObject.getVariableNumber(((gdjs.BattleCode.GDCannonAimObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.BattleCode.GDCannonAimObjects4[0].getVariables()).get("ID"))));
}{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].enableEffect("Selected", false);
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].enableEffect("Selected", false);
}
}}

}


};gdjs.BattleCode.eventsList21 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spawn"), gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDSpawnObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDSpawnObjects4[i].getVariableString(gdjs.BattleCode.GDSpawnObjects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDSpawnObjects4[k] = gdjs.BattleCode.GDSpawnObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDSpawnObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects5Objects = Hashtable.newFrom({"Block": gdjs.BattleCode.GDBlockObjects5});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock1x2Objects5Objects = Hashtable.newFrom({"Block1x2": gdjs.BattleCode.GDBlock1x2Objects5});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x1Objects5Objects = Hashtable.newFrom({"Block2x1": gdjs.BattleCode.GDBlock2x1Objects5});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x2Objects5Objects = Hashtable.newFrom({"Block2x2": gdjs.BattleCode.GDBlock2x2Objects5});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockLObjects5Objects = Hashtable.newFrom({"BlockL": gdjs.BattleCode.GDBlockLObjects5});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockIObjects4Objects = Hashtable.newFrom({"BlockI": gdjs.BattleCode.GDBlockIObjects4});gdjs.BattleCode.eventsList22 = function(runtimeScene) {

{


{
{runtimeScene.getVariables().get("CurrentBlock").setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(7).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)))));
}{runtimeScene.getVariables().get("CurrentPlayer").setString("Player1");
}}

}


{



}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects3, gdjs.BattleCode.GDBlock1x2Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects3, gdjs.BattleCode.GDBlock2x1Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects3, gdjs.BattleCode.GDBlock2x2Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects3, gdjs.BattleCode.GDBlockCannonObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects3, gdjs.BattleCode.GDBlockIObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects3, gdjs.BattleCode.GDBlockLObjects5);

gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects4, gdjs.BattleCode.GDSpawnObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockObjects3, gdjs.BattleCode.GDBlockObjects5);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects5Objects, (( gdjs.BattleCode.GDSpawnObjects5.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects5[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects5.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects5[i].returnVariable(gdjs.BattleCode.GDBlockObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects5[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects5[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects5[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects5[i].returnVariable(gdjs.BattleCode.GDBlockLObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects5[i].returnVariable(gdjs.BattleCode.GDBlockIObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects5[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects5[i].resetTimer("tetris");
}
}{runtimeScene.getVariables().getFromIndex(19).add(1);
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block1x2";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects3, gdjs.BattleCode.GDBlockObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects3, gdjs.BattleCode.GDBlock2x1Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects3, gdjs.BattleCode.GDBlock2x2Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects3, gdjs.BattleCode.GDBlockCannonObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects3, gdjs.BattleCode.GDBlockIObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects3, gdjs.BattleCode.GDBlockLObjects5);

gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects4, gdjs.BattleCode.GDSpawnObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects3, gdjs.BattleCode.GDBlock1x2Objects5);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock1x2Objects5Objects, (( gdjs.BattleCode.GDSpawnObjects5.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects5[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects5.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects5[i].returnVariable(gdjs.BattleCode.GDBlockObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects5[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects5[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects5[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects5[i].returnVariable(gdjs.BattleCode.GDBlockLObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects5[i].returnVariable(gdjs.BattleCode.GDBlockIObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects5[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects5[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block2x1";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects3, gdjs.BattleCode.GDBlockObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects3, gdjs.BattleCode.GDBlock1x2Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects3, gdjs.BattleCode.GDBlock2x2Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects3, gdjs.BattleCode.GDBlockCannonObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects3, gdjs.BattleCode.GDBlockIObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects3, gdjs.BattleCode.GDBlockLObjects5);

gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects4, gdjs.BattleCode.GDSpawnObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects3, gdjs.BattleCode.GDBlock2x1Objects5);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x1Objects5Objects, (( gdjs.BattleCode.GDSpawnObjects5.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects5[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects5.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects5[i].returnVariable(gdjs.BattleCode.GDBlockObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects5[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects5[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects5[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects5[i].returnVariable(gdjs.BattleCode.GDBlockLObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects5[i].returnVariable(gdjs.BattleCode.GDBlockIObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects5[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects5[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block2x2";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects3, gdjs.BattleCode.GDBlockObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects3, gdjs.BattleCode.GDBlock1x2Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects3, gdjs.BattleCode.GDBlock2x1Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects3, gdjs.BattleCode.GDBlockCannonObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects3, gdjs.BattleCode.GDBlockIObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects3, gdjs.BattleCode.GDBlockLObjects5);

gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects4, gdjs.BattleCode.GDSpawnObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects3, gdjs.BattleCode.GDBlock2x2Objects5);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x2Objects5Objects, (( gdjs.BattleCode.GDSpawnObjects5.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects5[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects5.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects5[i].returnVariable(gdjs.BattleCode.GDBlockObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects5[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects5[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects5[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects5[i].returnVariable(gdjs.BattleCode.GDBlockLObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects5[i].returnVariable(gdjs.BattleCode.GDBlockIObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects5[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects5[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "BlockL";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects3, gdjs.BattleCode.GDBlockObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects3, gdjs.BattleCode.GDBlock1x2Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects3, gdjs.BattleCode.GDBlock2x1Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects3, gdjs.BattleCode.GDBlock2x2Objects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects3, gdjs.BattleCode.GDBlockCannonObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects3, gdjs.BattleCode.GDBlockIObjects5);

gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects4, gdjs.BattleCode.GDSpawnObjects5);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects3, gdjs.BattleCode.GDBlockLObjects5);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockLObjects5Objects, (( gdjs.BattleCode.GDSpawnObjects5.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects5[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects5.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects5[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects5[i].returnVariable(gdjs.BattleCode.GDBlockObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects5[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects5[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects5[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects5[i].returnVariable(gdjs.BattleCode.GDBlockLObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects5[i].returnVariable(gdjs.BattleCode.GDBlockIObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects5[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects5[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects5[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects5.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects5[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "BlockI";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects3, gdjs.BattleCode.GDBlockObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects3, gdjs.BattleCode.GDBlock1x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects3, gdjs.BattleCode.GDBlock2x1Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects3, gdjs.BattleCode.GDBlock2x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects3, gdjs.BattleCode.GDBlockCannonObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects3, gdjs.BattleCode.GDBlockLObjects4);

/* Reuse gdjs.BattleCode.GDSpawnObjects4 */
gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects3, gdjs.BattleCode.GDBlockIObjects4);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockIObjects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


};gdjs.BattleCode.eventsList23 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spawn"), gdjs.BattleCode.GDSpawnObjects4);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDSpawnObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDSpawnObjects4[i].getVariableString(gdjs.BattleCode.GDSpawnObjects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDSpawnObjects4[k] = gdjs.BattleCode.GDSpawnObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDSpawnObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList24 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("cannonIndex")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4));
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList21(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("cannonIndex")) != gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4));
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList23(runtimeScene);} //End of subevents
}

}


{


{
{runtimeScene.getVariables().getFromIndex(4).add(1);
}}

}


};gdjs.BattleCode.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.BattleCode.GDBlockObjects2, gdjs.BattleCode.GDBlockObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects2, gdjs.BattleCode.GDBlock1x2Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects2, gdjs.BattleCode.GDBlock2x1Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects2, gdjs.BattleCode.GDBlock2x2Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects2, gdjs.BattleCode.GDBlockIObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects2, gdjs.BattleCode.GDBlockLObjects3);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects3[i].getVariableString(gdjs.BattleCode.GDBlockObjects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects3[k] = gdjs.BattleCode.GDBlockObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects3[i].getVariableString(gdjs.BattleCode.GDBlock1x2Objects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects3[k] = gdjs.BattleCode.GDBlock1x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects3[i].getVariableString(gdjs.BattleCode.GDBlock2x1Objects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects3[k] = gdjs.BattleCode.GDBlock2x1Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects3[i].getVariableString(gdjs.BattleCode.GDBlock2x2Objects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects3[k] = gdjs.BattleCode.GDBlock2x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects3[i].getVariableString(gdjs.BattleCode.GDBlockLObjects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects3[k] = gdjs.BattleCode.GDBlockLObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects3[i].getVariableString(gdjs.BattleCode.GDBlockIObjects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects3[k] = gdjs.BattleCode.GDBlockIObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects3[i].getVariableString(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects3[k] = gdjs.BattleCode.GDBlockCannonObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects3.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
gdjs.BattleCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(11));
}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects = Hashtable.newFrom({"BlockCannon": gdjs.BattleCode.GDBlockCannonObjects3});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDCannonAimObjects3Objects = Hashtable.newFrom({"CannonAim": gdjs.BattleCode.GDCannonAimObjects3});gdjs.BattleCode.eventsList26 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects2, gdjs.BattleCode.GDBlockObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects2, gdjs.BattleCode.GDBlock1x2Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects2, gdjs.BattleCode.GDBlock2x1Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects2, gdjs.BattleCode.GDBlock2x2Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects2, gdjs.BattleCode.GDBlockIObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects2, gdjs.BattleCode.GDBlockLObjects3);

/* Reuse gdjs.BattleCode.GDSpawnObjects3 */
gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects3);

gdjs.BattleCode.GDCannonAimObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects, (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().getFromIndex(1)).setString("Player2");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDCannonAimObjects3Objects, (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].setZOrder(gdjs.BattleCode.GDCannonAimObjects3[i].getZOrder() + (1));
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].returnVariable(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().get("ID")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].returnVariable(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().get("Player")).setString("Player2");
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].setAnimationName("Player2");
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].resetTimer("tetris");
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].flipX(true);
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].flipX(true);
}
}{gdjs.evtTools.variable.valuePush(runtimeScene.getVariables().getFromIndex(14), (gdjs.RuntimeObject.getVariableNumber(((gdjs.BattleCode.GDCannonAimObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.BattleCode.GDCannonAimObjects3[0].getVariables()).get("ID"))));
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].enableEffect("Selected", false);
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].enableEffect("Selected", false);
}
}}

}


};gdjs.BattleCode.eventsList27 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spawn"), gdjs.BattleCode.GDSpawnObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDSpawnObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDSpawnObjects3[i].getVariableString(gdjs.BattleCode.GDSpawnObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDSpawnObjects3[k] = gdjs.BattleCode.GDSpawnObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDSpawnObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects4Objects = Hashtable.newFrom({"Block": gdjs.BattleCode.GDBlockObjects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock1x2Objects4Objects = Hashtable.newFrom({"Block1x2": gdjs.BattleCode.GDBlock1x2Objects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x1Objects4Objects = Hashtable.newFrom({"Block2x1": gdjs.BattleCode.GDBlock2x1Objects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x2Objects4Objects = Hashtable.newFrom({"Block2x2": gdjs.BattleCode.GDBlock2x2Objects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockLObjects4Objects = Hashtable.newFrom({"BlockL": gdjs.BattleCode.GDBlockLObjects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockIObjects3Objects = Hashtable.newFrom({"BlockI": gdjs.BattleCode.GDBlockIObjects3});gdjs.BattleCode.eventsList28 = function(runtimeScene) {

{


{
{runtimeScene.getVariables().get("CurrentBlock").setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(7).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(5)))));
}{runtimeScene.getVariables().get("CurrentPlayer").setString("Player2");
}}

}


{



}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects2, gdjs.BattleCode.GDBlock1x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects2, gdjs.BattleCode.GDBlock2x1Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects2, gdjs.BattleCode.GDBlock2x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects2, gdjs.BattleCode.GDBlockIObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects2, gdjs.BattleCode.GDBlockLObjects4);

gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockObjects2, gdjs.BattleCode.GDBlockObjects4);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}{runtimeScene.getVariables().getFromIndex(19).add(1);
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block1x2";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects2, gdjs.BattleCode.GDBlockObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects2, gdjs.BattleCode.GDBlock2x1Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects2, gdjs.BattleCode.GDBlock2x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects2, gdjs.BattleCode.GDBlockIObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects2, gdjs.BattleCode.GDBlockLObjects4);

gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects2, gdjs.BattleCode.GDBlock1x2Objects4);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock1x2Objects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block2x1";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects2, gdjs.BattleCode.GDBlockObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects2, gdjs.BattleCode.GDBlock1x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects2, gdjs.BattleCode.GDBlock2x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects2, gdjs.BattleCode.GDBlockIObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects2, gdjs.BattleCode.GDBlockLObjects4);

gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects2, gdjs.BattleCode.GDBlock2x1Objects4);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x1Objects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "Block2x2";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects2, gdjs.BattleCode.GDBlockObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects2, gdjs.BattleCode.GDBlock1x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects2, gdjs.BattleCode.GDBlock2x1Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects2, gdjs.BattleCode.GDBlockIObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects2, gdjs.BattleCode.GDBlockLObjects4);

gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects2, gdjs.BattleCode.GDBlock2x2Objects4);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlock2x2Objects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "BlockL";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects2, gdjs.BattleCode.GDBlockObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects2, gdjs.BattleCode.GDBlock1x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects2, gdjs.BattleCode.GDBlock2x1Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects2, gdjs.BattleCode.GDBlock2x2Objects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects2, gdjs.BattleCode.GDBlockIObjects4);

gdjs.copyArray(gdjs.BattleCode.GDSpawnObjects3, gdjs.BattleCode.GDSpawnObjects4);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects2, gdjs.BattleCode.GDBlockLObjects4);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockLObjects4Objects, (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].returnVariable(gdjs.BattleCode.GDBlockObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].returnVariable(gdjs.BattleCode.GDBlockLObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].returnVariable(gdjs.BattleCode.GDBlockIObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects4[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].resetTimer("tetris");
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentBlock")) == "BlockI";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.BattleCode.GDBlockObjects2, gdjs.BattleCode.GDBlockObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects2, gdjs.BattleCode.GDBlock1x2Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects2, gdjs.BattleCode.GDBlock2x1Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects2, gdjs.BattleCode.GDBlock2x2Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects2, gdjs.BattleCode.GDBlockLObjects3);

/* Reuse gdjs.BattleCode.GDSpawnObjects3 */
gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects2, gdjs.BattleCode.GDBlockIObjects3);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockIObjects3Objects, (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].returnVariable(gdjs.BattleCode.GDBlockObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].returnVariable(gdjs.BattleCode.GDBlockLObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].returnVariable(gdjs.BattleCode.GDBlockIObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().get("Player")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("CurrentPlayer")));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].resetTimer("tetris");
}
}}

}


};gdjs.BattleCode.eventsList29 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spawn"), gdjs.BattleCode.GDSpawnObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDSpawnObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDSpawnObjects3[i].getVariableString(gdjs.BattleCode.GDSpawnObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDSpawnObjects3[k] = gdjs.BattleCode.GDSpawnObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDSpawnObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList30 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("cannonIndex")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(5));
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList27(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("cannonIndex")) != gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(5));
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList29(runtimeScene);} //End of subevents
}

}


{


{
{runtimeScene.getVariables().getFromIndex(5).add(1);
}}

}


};gdjs.BattleCode.eventsList31 = function(runtimeScene) {

{

/* Reuse gdjs.BattleCode.GDBlockObjects2 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects2 */
/* Reuse gdjs.BattleCode.GDBlockIObjects2 */
/* Reuse gdjs.BattleCode.GDBlockLObjects2 */

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects2[i].getVariableString(gdjs.BattleCode.GDBlockObjects2[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockObjects2[k] = gdjs.BattleCode.GDBlockObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects2[i].getVariableString(gdjs.BattleCode.GDBlock1x2Objects2[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock1x2Objects2[k] = gdjs.BattleCode.GDBlock1x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects2[i].getVariableString(gdjs.BattleCode.GDBlock2x1Objects2[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x1Objects2[k] = gdjs.BattleCode.GDBlock2x1Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects2[i].getVariableString(gdjs.BattleCode.GDBlock2x2Objects2[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlock2x2Objects2[k] = gdjs.BattleCode.GDBlock2x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects2[i].getVariableString(gdjs.BattleCode.GDBlockLObjects2[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockLObjects2[k] = gdjs.BattleCode.GDBlockLObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects2[i].getVariableString(gdjs.BattleCode.GDBlockIObjects2[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockIObjects2[k] = gdjs.BattleCode.GDBlockIObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects2[i].getVariableString(gdjs.BattleCode.GDBlockCannonObjects2[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDBlockCannonObjects2[k] = gdjs.BattleCode.GDBlockCannonObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects2.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
gdjs.BattleCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(5)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(11));
}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList32 = function(runtimeScene) {

{


gdjs.BattleCode.eventsList25(runtimeScene);
}


{


gdjs.BattleCode.eventsList31(runtimeScene);
}


};gdjs.BattleCode.eventsList33 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.BattleCode.GDBlockObjects2, gdjs.BattleCode.GDBlockObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects2, gdjs.BattleCode.GDBlock1x2Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects2, gdjs.BattleCode.GDBlock2x1Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects2, gdjs.BattleCode.GDBlock2x2Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects2, gdjs.BattleCode.GDBlockIObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects2, gdjs.BattleCode.GDBlockLObjects3);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects3[i].getVariableString(gdjs.BattleCode.GDBlockObjects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockObjects3[k] = gdjs.BattleCode.GDBlockObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects3[i].getVariableString(gdjs.BattleCode.GDBlock1x2Objects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock1x2Objects3[k] = gdjs.BattleCode.GDBlock1x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects3[i].getVariableString(gdjs.BattleCode.GDBlock2x1Objects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x1Objects3[k] = gdjs.BattleCode.GDBlock2x1Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects3[i].getVariableString(gdjs.BattleCode.GDBlock2x2Objects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x2Objects3[k] = gdjs.BattleCode.GDBlock2x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects3[i].getVariableString(gdjs.BattleCode.GDBlockLObjects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockLObjects3[k] = gdjs.BattleCode.GDBlockLObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects3[i].getVariableString(gdjs.BattleCode.GDBlockIObjects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockIObjects3[k] = gdjs.BattleCode.GDBlockIObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects3[i].getVariableString(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockCannonObjects3[k] = gdjs.BattleCode.GDBlockCannonObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("turnBlocksFixedCount").add(1);
}}

}


{

gdjs.copyArray(gdjs.BattleCode.GDBlockObjects2, gdjs.BattleCode.GDBlockObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock1x2Objects2, gdjs.BattleCode.GDBlock1x2Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x1Objects2, gdjs.BattleCode.GDBlock2x1Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlock2x2Objects2, gdjs.BattleCode.GDBlock2x2Objects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockIObjects2, gdjs.BattleCode.GDBlockIObjects3);

gdjs.copyArray(gdjs.BattleCode.GDBlockLObjects2, gdjs.BattleCode.GDBlockLObjects3);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects3[i].getVariableString(gdjs.BattleCode.GDBlockObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockObjects3[k] = gdjs.BattleCode.GDBlockObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects3[i].getVariableString(gdjs.BattleCode.GDBlock1x2Objects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock1x2Objects3[k] = gdjs.BattleCode.GDBlock1x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects3[i].getVariableString(gdjs.BattleCode.GDBlock2x1Objects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x1Objects3[k] = gdjs.BattleCode.GDBlock2x1Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects3[i].getVariableString(gdjs.BattleCode.GDBlock2x2Objects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x2Objects3[k] = gdjs.BattleCode.GDBlock2x2Objects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects3[i].getVariableString(gdjs.BattleCode.GDBlockLObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockLObjects3[k] = gdjs.BattleCode.GDBlockLObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects3[i].getVariableString(gdjs.BattleCode.GDBlockIObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockIObjects3[k] = gdjs.BattleCode.GDBlockIObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects3.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects3[i].getVariableString(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockCannonObjects3[k] = gdjs.BattleCode.GDBlockCannonObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("turnBlocksFixedCount").add(1);
}}

}


{


gdjs.BattleCode.eventsList32(runtimeScene);
}


};gdjs.BattleCode.eventsList34 = function(runtimeScene) {

{

/* Reuse gdjs.BattleCode.GDBlockObjects2 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects2 */
/* Reuse gdjs.BattleCode.GDBlockIObjects2 */
/* Reuse gdjs.BattleCode.GDBlockLObjects2 */

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockObjects2[k] = gdjs.BattleCode.GDBlockObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock1x2Objects2[k] = gdjs.BattleCode.GDBlock1x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x1Objects2[k] = gdjs.BattleCode.GDBlock2x1Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x2Objects2[k] = gdjs.BattleCode.GDBlock2x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockLObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockLObjects2[k] = gdjs.BattleCode.GDBlockLObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockIObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockIObjects2[k] = gdjs.BattleCode.GDBlockIObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockCannonObjects2[k] = gdjs.BattleCode.GDBlockCannonObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects2.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects2 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects2 */
/* Reuse gdjs.BattleCode.GDBlockIObjects2 */
/* Reuse gdjs.BattleCode.GDBlockLObjects2 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects2[i].setY(gdjs.BattleCode.GDBlockObjects2[i].getY() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects2[i].setY(gdjs.BattleCode.GDBlock1x2Objects2[i].getY() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects2[i].setY(gdjs.BattleCode.GDBlock2x1Objects2[i].getY() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects2[i].setY(gdjs.BattleCode.GDBlock2x2Objects2[i].getY() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects2[i].setY(gdjs.BattleCode.GDBlockLObjects2[i].getY() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects2[i].setY(gdjs.BattleCode.GDBlockIObjects2[i].getY() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects2[i].setY(gdjs.BattleCode.GDBlockCannonObjects2[i].getY() - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1))));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects2[i].setVariableBoolean(gdjs.BattleCode.GDBlockObjects2[i].getVariables().get("Fixed"), true);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects2[i].setVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects2[i].getVariables().get("Fixed"), true);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects2[i].setVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects2[i].getVariables().get("Fixed"), true);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects2[i].setVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects2[i].getVariables().get("Fixed"), true);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects2[i].setVariableBoolean(gdjs.BattleCode.GDBlockLObjects2[i].getVariables().get("Fixed"), true);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects2[i].setVariableBoolean(gdjs.BattleCode.GDBlockIObjects2[i].getVariables().get("Fixed"), true);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects2[i].setVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects2[i].getVariables().get("Fixed"), true);
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects2[i].removeTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects2[i].removeTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects2[i].removeTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects2[i].removeTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects2[i].removeTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects2[i].removeTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects2[i].removeTimer("tetris");
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\sound\\effects\\block-fixed.wav", 2, false, 50, gdjs.random(10));
}
{ //Subevents
gdjs.BattleCode.eventsList33(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList35 = function(runtimeScene) {

};gdjs.BattleCode.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.BattleCode.GDCannonAimObjects3);

for(gdjs.BattleCode.forEachIndex4 = 0;gdjs.BattleCode.forEachIndex4 < gdjs.BattleCode.GDCannonAimObjects3.length;++gdjs.BattleCode.forEachIndex4) {
gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects4);

gdjs.BattleCode.GDCannonAimObjects4.length = 0;


gdjs.BattleCode.forEachTemporary4 = gdjs.BattleCode.GDCannonAimObjects3[gdjs.BattleCode.forEachIndex4];
gdjs.BattleCode.GDCannonAimObjects4.push(gdjs.BattleCode.forEachTemporary4);
gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().get("ID")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.BattleCode.GDBlockCannonObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.BattleCode.GDBlockCannonObjects4[0].getVariables()).getFromIndex(0))) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].setCenterPositionInScene((( gdjs.BattleCode.GDBlockCannonObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDBlockCannonObjects4[0].getCenterXInScene()),(( gdjs.BattleCode.GDBlockCannonObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDBlockCannonObjects4[0].getCenterYInScene()));
}
}}
}

}


};gdjs.BattleCode.eventsList37 = function(runtimeScene) {

{


gdjs.BattleCode.eventsList18(runtimeScene);
}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockObjects2[k] = gdjs.BattleCode.GDBlockObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock1x2Objects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock1x2Objects2[k] = gdjs.BattleCode.GDBlock1x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x1Objects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x1Objects2[k] = gdjs.BattleCode.GDBlock2x1Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects2[i].getVariableBoolean(gdjs.BattleCode.GDBlock2x2Objects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x2Objects2[k] = gdjs.BattleCode.GDBlock2x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockLObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockLObjects2[k] = gdjs.BattleCode.GDBlockLObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockIObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockIObjects2[k] = gdjs.BattleCode.GDBlockIObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects2[i].getVariableBoolean(gdjs.BattleCode.GDBlockCannonObjects2[i].getVariables().get("Fixed"), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockCannonObjects2[k] = gdjs.BattleCode.GDBlockCannonObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects2.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects2);
gdjs.copyArray(runtimeScene.getObjects("Core"), gdjs.BattleCode.GDCoreObjects2);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.BattleCode.GDFloorObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects2ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlockLObjects2ObjectsGDgdjs_46BattleCode_46GDBlockIObjects2ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects2Objects, gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDFloorObjects2ObjectsGDgdjs_46BattleCode_46GDCoreObjects2ObjectsGDgdjs_46BattleCode_46GDBlockObjects2ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects2ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlockIObjects2ObjectsGDgdjs_46BattleCode_46GDBlockLObjects2ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects2Objects, false, runtimeScene, true);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList34(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("turnBlocksFixedCount")) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(11)) * 2;
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).mul(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(21)));
}{runtimeScene.getVariables().getFromIndex(2).setString("battle");
}{runtimeScene.getVariables().getFromIndex(3).setString("start");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects1);

for(gdjs.BattleCode.forEachIndex2 = 0;gdjs.BattleCode.forEachIndex2 < gdjs.BattleCode.GDBlockCannonObjects1.length;++gdjs.BattleCode.forEachIndex2) {
gdjs.BattleCode.GDBlockCannonObjects2.length = 0;


gdjs.BattleCode.forEachTemporary2 = gdjs.BattleCode.GDBlockCannonObjects1[gdjs.BattleCode.forEachIndex2];
gdjs.BattleCode.GDBlockCannonObjects2.push(gdjs.BattleCode.forEachTemporary2);
if (true) {

{ //Subevents: 
gdjs.BattleCode.eventsList36(runtimeScene);} //Subevents end.
}
}

}


};gdjs.BattleCode.eventsList38 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects2);
gdjs.copyArray(runtimeScene.getObjects("Roof"), gdjs.BattleCode.GDRoofObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDRoofObjects2Objects, gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects2ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects2ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects2ObjectsGDgdjs_46BattleCode_46GDBlockLObjects2ObjectsGDgdjs_46BattleCode_46GDBlockIObjects2ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects2Objects, false, runtimeScene, false);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(3)) == "start";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(3)) == "main";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList37(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList39 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "build";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList40 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("TextBattleTurn"), gdjs.BattleCode.GDTextBattleTurnObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextBattleTurnDescription"), gdjs.BattleCode.GDTextBattleTurnDescriptionObjects2);
{for(var i = 0, len = gdjs.BattleCode.GDTextBattleTurnObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBattleTurnObjects2[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextBattleTurnDescriptionObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBattleTurnDescriptionObjects2[i].hide();
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "turnTransition");
}{runtimeScene.getVariables().getFromIndex(10).setString("main");
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "assets\\sound\\music\\Frantic-Gameplay_v001.mp3", 1, false, 20, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "battle");
}}

}


};gdjs.BattleCode.eventsList41 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10299292);
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.BattleCode.GDCannonAimObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextBattleTurn"), gdjs.BattleCode.GDTextBattleTurnObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextBattleTurnDescription"), gdjs.BattleCode.GDTextBattleTurnDescriptionObjects3);
{gdjs.evtTools.debuggerTools.log("Battle start", "info", "");
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].resetTimer("shoot");
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "turnTransition");
}{runtimeScene.getVariables().getFromIndex(15).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(16).setNumber(0);
}{for(var i = 0, len = gdjs.BattleCode.GDTextBattleTurnObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBattleTurnObjects3[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDTextBattleTurnDescriptionObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBattleTurnDescriptionObjects3[i].hide(false);
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "turnTransition") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1));
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects4Objects = Hashtable.newFrom({"Bullet": gdjs.BattleCode.GDBulletObjects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects4Objects = Hashtable.newFrom({"Bullet": gdjs.BattleCode.GDBulletObjects4});gdjs.BattleCode.eventsList42 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.BattleCode.GDCannonAimObjects3, gdjs.BattleCode.GDCannonAimObjects4);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getTimerElapsedTimeInSecondsOrNaN("shoot") >= (gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().getFromIndex(3))) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getVariableString(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects4 */
gdjs.BattleCode.GDBulletObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects4Objects, (( gdjs.BattleCode.GDCannonAimObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDCannonAimObjects4[0].getPointX("Shoot")), (( gdjs.BattleCode.GDCannonAimObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDCannonAimObjects4[0].getPointY("Shoot")) - 4, "");
}{for(var i = 0, len = gdjs.BattleCode.GDBulletObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBulletObjects4[i].getBehavior("Physics2").applyPolarForce((( gdjs.BattleCode.GDCannonAimObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDCannonAimObjects4[0].getAngle()), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(22)), 1, 1);
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].resetTimer("shoot");
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\sound\\effects\\shoot.wav", 2, false, 30, gdjs.random(10));
}{for(var i = 0, len = gdjs.BattleCode.GDBulletObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBulletObjects4[i].returnVariable(gdjs.BattleCode.GDBulletObjects4[i].getVariables().get("Player")).setString("Player1");
}
}}

}


{

gdjs.copyArray(gdjs.BattleCode.GDCannonAimObjects3, gdjs.BattleCode.GDCannonAimObjects4);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getTimerElapsedTimeInSecondsOrNaN("shoot") >= (gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().getFromIndex(3))) ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getVariableString(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects4 */
gdjs.BattleCode.GDBulletObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects4Objects, (( gdjs.BattleCode.GDCannonAimObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDCannonAimObjects4[0].getPointX("Shoot")) - 8, (( gdjs.BattleCode.GDCannonAimObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDCannonAimObjects4[0].getPointY("Shoot")) - 4, "");
}{for(var i = 0, len = gdjs.BattleCode.GDBulletObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBulletObjects4[i].getBehavior("Physics2").applyPolarForce((( gdjs.BattleCode.GDCannonAimObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDCannonAimObjects4[0].getAngle()) - 180, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(22)), 1, 1);
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].resetTimer("shoot");
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\sound\\effects\\shoot.wav", 2, false, 30, gdjs.random(10));
}{for(var i = 0, len = gdjs.BattleCode.GDBulletObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBulletObjects4[i].setAnimationName("Player2");
}
}{for(var i = 0, len = gdjs.BattleCode.GDBulletObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBulletObjects4[i].returnVariable(gdjs.BattleCode.GDBulletObjects4[i].getVariables().get("Player")).setString("Player2");
}
}}

}


};gdjs.BattleCode.eventsList43 = function(runtimeScene) {

{

/* Reuse gdjs.BattleCode.GDCannonAimObjects4 */

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getAngle() <= (gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().getFromIndex(0))) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects4 */
{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].setAngle((gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().getFromIndex(0))));
}
}}

}


};gdjs.BattleCode.eventsList44 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.BattleCode.GDCannonAimObjects4);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getVariableString(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().get("ID")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(13).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(15)))) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects4 */
{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].rotate(-((gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().getFromIndex(4)))), runtimeScene);
}
}
{ //Subevents
gdjs.BattleCode.eventsList43(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList45 = function(runtimeScene) {

{

/* Reuse gdjs.BattleCode.GDCannonAimObjects4 */

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getAngle() >= (gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().getFromIndex(1))) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects4 */
{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].setAngle((gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().getFromIndex(1))));
}
}}

}


};gdjs.BattleCode.eventsList46 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.BattleCode.GDCannonAimObjects4);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getVariableString(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().get("ID")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(13).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(15)))) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects4 */
{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].rotate((gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().getFromIndex(4))), runtimeScene);
}
}
{ //Subevents
gdjs.BattleCode.eventsList45(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.userFunc0x8ea330 = function(runtimeScene) {
"use strict";
if (runtimeScene.getVariables().get("SelectedCannonPlayer1").getAsNumber() < runtimeScene.getVariables().get("CannonsPlayer1").getChildrenCount()-1) {
    runtimeScene.getVariables().get("SelectedCannonPlayer1").add(1);
} else if (
    (runtimeScene.getVariables().get("CannonsPlayer1").getChildrenCount() <= 1) ||
    (runtimeScene.getVariables().get("SelectedCannonPlayer1").getAsNumber() == runtimeScene.getVariables().get("CannonsPlayer1").getChildrenCount()-1)) {
    runtimeScene.getVariables().get("SelectedCannonPlayer1").setNumber(0);
}
};
gdjs.BattleCode.eventsList47 = function(runtimeScene) {

{


gdjs.BattleCode.userFunc0x8ea330(runtimeScene);

}


};gdjs.BattleCode.userFunc0x980768 = function(runtimeScene) {
"use strict";
if (runtimeScene.getVariables().get("CannonsPlayer1").getChildrenCount() <= 1) {
    runtimeScene.getVariables().get("SelectedCannonPlayer1").setNumber(0);

} else if (runtimeScene.getVariables().get("SelectedCannonPlayer1").getAsNumber() > 0) {
    runtimeScene.getVariables().get("SelectedCannonPlayer1").sub(1);
    
} else if (runtimeScene.getVariables().get("SelectedCannonPlayer1").getAsNumber() == 0) {
    runtimeScene.getVariables().get("SelectedCannonPlayer1").setNumber(runtimeScene.getVariables().get("CannonsPlayer1").getChildrenCount()-1);
}
};
gdjs.BattleCode.eventsList48 = function(runtimeScene) {

{


gdjs.BattleCode.userFunc0x980768(runtimeScene);

}


};gdjs.BattleCode.eventsList49 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList44(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList46(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\sound\\effects\\select-block.wav", 2, false, 20, 1);
}
{ //Subevents
gdjs.BattleCode.eventsList47(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\sound\\effects\\select-block.wav", 2, false, 20, 1);
}
{ //Subevents
gdjs.BattleCode.eventsList48(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList50 = function(runtimeScene) {

{

/* Reuse gdjs.BattleCode.GDCannonAimObjects3 */

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects3[i].getAngle() >= (gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().getFromIndex(1))) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCannonAimObjects3[k] = gdjs.BattleCode.GDCannonAimObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].setAngle((gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().getFromIndex(1))));
}
}}

}


};gdjs.BattleCode.eventsList51 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.BattleCode.GDCannonAimObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects3[i].getVariableString(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects3[k] = gdjs.BattleCode.GDCannonAimObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects3.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects3[i].getVariableNumber(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().get("ID")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(14).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(16)))) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects3[k] = gdjs.BattleCode.GDCannonAimObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects3.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].rotate((gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().getFromIndex(4))), runtimeScene);
}
}
{ //Subevents
gdjs.BattleCode.eventsList50(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList52 = function(runtimeScene) {

{

/* Reuse gdjs.BattleCode.GDCannonAimObjects3 */

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects3[i].getAngle() <= (gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().getFromIndex(0))) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCannonAimObjects3[k] = gdjs.BattleCode.GDCannonAimObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].setAngle((gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().getFromIndex(0))));
}
}}

}


};gdjs.BattleCode.eventsList53 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.BattleCode.GDCannonAimObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects3[i].getVariableString(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects3[k] = gdjs.BattleCode.GDCannonAimObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects3.length = k;}if ( gdjs.BattleCode.condition0IsTrue_1.val ) {
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects3[i].getVariableNumber(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().get("ID")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(14).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(16)))) ) {
        gdjs.BattleCode.condition1IsTrue_1.val = true;
        gdjs.BattleCode.GDCannonAimObjects3[k] = gdjs.BattleCode.GDCannonAimObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects3.length = k;}}
gdjs.BattleCode.conditionTrue_1.val = true && gdjs.BattleCode.condition0IsTrue_1.val && gdjs.BattleCode.condition1IsTrue_1.val;
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].rotate(-((gdjs.RuntimeObject.getVariableNumber(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().getFromIndex(4)))), runtimeScene);
}
}
{ //Subevents
gdjs.BattleCode.eventsList52(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.userFunc0x6f44a0 = function(runtimeScene) {
"use strict";
if (runtimeScene.getVariables().get("SelectedCannonPlayer2").getAsNumber() < runtimeScene.getVariables().get("CannonsPlayer2").getChildrenCount()-1) {
    runtimeScene.getVariables().get("SelectedCannonPlayer2").add(1);
} else if (
    (runtimeScene.getVariables().get("CannonsPlayer2").getChildrenCount() <= 1) ||
    (runtimeScene.getVariables().get("SelectedCannonPlayer2").getAsNumber() == runtimeScene.getVariables().get("CannonsPlayer2").getChildrenCount()-1)) {
    runtimeScene.getVariables().get("SelectedCannonPlayer2").setNumber(0);
}
};
gdjs.BattleCode.eventsList54 = function(runtimeScene) {

{


gdjs.BattleCode.userFunc0x6f44a0(runtimeScene);

}


};gdjs.BattleCode.userFunc0x6f4a00 = function(runtimeScene) {
"use strict";
if (runtimeScene.getVariables().get("CannonsPlayer2").getChildrenCount() <= 1) {
    runtimeScene.getVariables().get("SelectedCannonPlayer2").setNumber(0);

} else if (runtimeScene.getVariables().get("SelectedCannonPlayer2").getAsNumber() > 0) {
    runtimeScene.getVariables().get("SelectedCannonPlayer2").sub(1);
    
} else if (runtimeScene.getVariables().get("SelectedCannonPlayer2").getAsNumber() == 0) {
    runtimeScene.getVariables().get("SelectedCannonPlayer2").setNumber(runtimeScene.getVariables().get("CannonsPlayer2").getChildrenCount()-1);
}
};
gdjs.BattleCode.eventsList55 = function(runtimeScene) {

{


gdjs.BattleCode.userFunc0x6f4a00(runtimeScene);

}


};gdjs.BattleCode.eventsList56 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList51(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList53(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Right");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\sound\\effects\\select-block.wav", 2, false, 20, 2);
}
{ //Subevents
gdjs.BattleCode.eventsList54(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Left");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\sound\\effects\\select-block.wav", 2, false, 20, 1);
}
{ //Subevents
gdjs.BattleCode.eventsList55(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList57 = function(runtimeScene) {

{


gdjs.BattleCode.eventsList49(runtimeScene);
}


{


gdjs.BattleCode.eventsList56(runtimeScene);
}


};gdjs.BattleCode.eventsList58 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(20), false);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList57(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.BattleCode.GDBulletObjects3});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.BattleCode.GDBulletObjects3});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticleObjects4Objects = Hashtable.newFrom({"BulletParticle": gdjs.BattleCode.GDBulletParticleObjects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticlePlayer2Objects4Objects = Hashtable.newFrom({"BulletParticlePlayer2": gdjs.BattleCode.GDBulletParticlePlayer2Objects4});gdjs.BattleCode.eventsList59 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.BattleCode.GDBulletObjects3, gdjs.BattleCode.GDBulletObjects4);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBulletObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBulletObjects4[i].getVariableString(gdjs.BattleCode.GDBulletObjects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBulletObjects4[k] = gdjs.BattleCode.GDBulletObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBulletObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBulletObjects4 */
gdjs.BattleCode.GDBulletParticleObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticleObjects4Objects, (( gdjs.BattleCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects4[0].getCenterXInScene()), (( gdjs.BattleCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects4[0].getCenterYInScene()), "Particle");
}}

}


{

gdjs.copyArray(gdjs.BattleCode.GDBulletObjects3, gdjs.BattleCode.GDBulletObjects4);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBulletObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBulletObjects4[i].getVariableString(gdjs.BattleCode.GDBulletObjects4[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBulletObjects4[k] = gdjs.BattleCode.GDBulletObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBulletObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBulletObjects4 */
gdjs.BattleCode.GDBulletParticlePlayer2Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticlePlayer2Objects4Objects, (( gdjs.BattleCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects4[0].getCenterXInScene()), (( gdjs.BattleCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects4[0].getCenterYInScene()), "Particle");
}}

}


{


{
/* Reuse gdjs.BattleCode.GDBulletObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.BattleCode.GDBulletObjects3});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects3ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlockLObjects3ObjectsGDgdjs_46BattleCode_46GDBlockIObjects3ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects = Hashtable.newFrom({"Block": gdjs.BattleCode.GDBlockObjects3, "Block1x2": gdjs.BattleCode.GDBlock1x2Objects3, "Block2x1": gdjs.BattleCode.GDBlock2x1Objects3, "Block2x2": gdjs.BattleCode.GDBlock2x2Objects3, "BlockL": gdjs.BattleCode.GDBlockLObjects3, "BlockI": gdjs.BattleCode.GDBlockIObjects3, "BlockCannon": gdjs.BattleCode.GDBlockCannonObjects3});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticleObjects4Objects = Hashtable.newFrom({"BulletParticle": gdjs.BattleCode.GDBulletParticleObjects4});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticlePlayer2Objects4Objects = Hashtable.newFrom({"BulletParticlePlayer2": gdjs.BattleCode.GDBulletParticlePlayer2Objects4});gdjs.BattleCode.eventsList60 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.BattleCode.GDBulletObjects3, gdjs.BattleCode.GDBulletObjects4);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBulletObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBulletObjects4[i].getVariableString(gdjs.BattleCode.GDBulletObjects4[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBulletObjects4[k] = gdjs.BattleCode.GDBulletObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBulletObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBulletObjects4 */
gdjs.BattleCode.GDBulletParticleObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticleObjects4Objects, (( gdjs.BattleCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects4[0].getCenterXInScene()), (( gdjs.BattleCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects4[0].getCenterYInScene()), "Particle");
}}

}


{

gdjs.copyArray(gdjs.BattleCode.GDBulletObjects3, gdjs.BattleCode.GDBulletObjects4);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBulletObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBulletObjects4[i].getVariableString(gdjs.BattleCode.GDBulletObjects4[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBulletObjects4[k] = gdjs.BattleCode.GDBulletObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBulletObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBulletObjects4 */
gdjs.BattleCode.GDBulletParticlePlayer2Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticlePlayer2Objects4Objects, (( gdjs.BattleCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects4[0].getCenterXInScene()), (( gdjs.BattleCode.GDBulletObjects4.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects4[0].getCenterYInScene()), "Particle");
}}

}


{


{
/* Reuse gdjs.BattleCode.GDBulletObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.BattleCode.GDBulletObjects2});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDCoreObjects2Objects = Hashtable.newFrom({"Core": gdjs.BattleCode.GDCoreObjects2});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticleObjects3Objects = Hashtable.newFrom({"BulletParticle": gdjs.BattleCode.GDBulletParticleObjects3});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticlePlayer2Objects3Objects = Hashtable.newFrom({"BulletParticlePlayer2": gdjs.BattleCode.GDBulletParticlePlayer2Objects3});gdjs.BattleCode.eventsList61 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.BattleCode.GDBulletObjects2, gdjs.BattleCode.GDBulletObjects3);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBulletObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBulletObjects3[i].getVariableString(gdjs.BattleCode.GDBulletObjects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBulletObjects3[k] = gdjs.BattleCode.GDBulletObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBulletObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBulletObjects3 */
gdjs.BattleCode.GDBulletParticleObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticleObjects3Objects, (( gdjs.BattleCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects3[0].getCenterXInScene()), (( gdjs.BattleCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects3[0].getCenterYInScene()), "Particle");
}}

}


{

gdjs.copyArray(gdjs.BattleCode.GDBulletObjects2, gdjs.BattleCode.GDBulletObjects3);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBulletObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBulletObjects3[i].getVariableString(gdjs.BattleCode.GDBulletObjects3[i].getVariables().get("Player")) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBulletObjects3[k] = gdjs.BattleCode.GDBulletObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBulletObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBulletObjects3 */
gdjs.BattleCode.GDBulletParticlePlayer2Objects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletParticlePlayer2Objects3Objects, (( gdjs.BattleCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects3[0].getCenterXInScene()), (( gdjs.BattleCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDBulletObjects3[0].getCenterYInScene()), "Particle");
}}

}


{


{
gdjs.copyArray(gdjs.BattleCode.GDBulletObjects2, gdjs.BattleCode.GDBulletObjects3);

{for(var i = 0, len = gdjs.BattleCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

/* Reuse gdjs.BattleCode.GDCoreObjects2 */

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCoreObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCoreObjects2[i].getVariableBoolean(gdjs.BattleCode.GDCoreObjects2[i].getVariables().getFromIndex(2), false) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCoreObjects2[k] = gdjs.BattleCode.GDCoreObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDCoreObjects2.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCoreObjects2 */
{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects2[i].returnVariable(gdjs.BattleCode.GDCoreObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\sound\\effects\\core-damage.wav", 2, false, 50, 1);
}{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects2[i].resetTimer("invulnerableCooldown");
}
}{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects2[i].setVariableBoolean(gdjs.BattleCode.GDCoreObjects2[i].getVariables().getFromIndex(2), true);
}
}}

}


};gdjs.BattleCode.eventsList62 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.BattleCode.GDBulletObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects3Objects, gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects3Objects, false, runtimeScene, false);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\sound\\effects\\bullet-hit.wav", 2, false, gdjs.random(10), 1);
}
{ //Subevents
gdjs.BattleCode.eventsList59(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects3);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects3);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects3);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects3);
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.BattleCode.GDBulletObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects3Objects, gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockObjects3ObjectsGDgdjs_46BattleCode_46GDBlock1x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x1Objects3ObjectsGDgdjs_46BattleCode_46GDBlock2x2Objects3ObjectsGDgdjs_46BattleCode_46GDBlockLObjects3ObjectsGDgdjs_46BattleCode_46GDBlockIObjects3ObjectsGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects, false, runtimeScene, false);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockObjects3 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects3 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects3 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects3 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects3 */
/* Reuse gdjs.BattleCode.GDBlockIObjects3 */
/* Reuse gdjs.BattleCode.GDBlockLObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].returnVariable(gdjs.BattleCode.GDBlockObjects3[i].getVariables().get("Health")).sub(1);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].returnVariable(gdjs.BattleCode.GDBlock1x2Objects3[i].getVariables().get("Health")).sub(1);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].returnVariable(gdjs.BattleCode.GDBlock2x1Objects3[i].getVariables().get("Health")).sub(1);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].returnVariable(gdjs.BattleCode.GDBlock2x2Objects3[i].getVariables().get("Health")).sub(1);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].returnVariable(gdjs.BattleCode.GDBlockLObjects3[i].getVariables().get("Health")).sub(1);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].returnVariable(gdjs.BattleCode.GDBlockIObjects3[i].getVariables().get("Health")).sub(1);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().get("Health")).sub(1);
}
}
{ //Subevents
gdjs.BattleCode.eventsList60(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.BattleCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Core"), gdjs.BattleCode.GDCoreObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBulletObjects2Objects, gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDCoreObjects2Objects, false, runtimeScene, false);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList61(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList63 = function(runtimeScene) {

};gdjs.BattleCode.userFunc0x96e6f8 = function(runtimeScene) {
"use strict";
if (runtimeScene.getVariables().get('indexToRemove').getAsNumber() > -1) {
    runtimeScene.getVariables().get('CannonsPlayer1').getAllChildrenArray().splice(runtimeScene.getVariables().get('indexToRemove').getAsNumber(), 1);

    if (runtimeScene.getVariables().get('SelectedCannonPlayer1').getAsNumber() == runtimeScene.getVariables().get('indexToRemove').getAsNumber()) {
        runtimeScene.getVariables().get('SelectedCannonPlayer1').setNumber(0)
    }

    runtimeScene.getVariables().get('indexToRemove').setNumber(-1);
}
};
gdjs.BattleCode.eventsList64 = function(runtimeScene) {

};gdjs.BattleCode.userFunc0x99e7c8 = function(runtimeScene) {
"use strict";
if (runtimeScene.getVariables().get('indexToRemove').getAsNumber() > -1) {
    runtimeScene.getVariables().get('CannonsPlayer2').getAllChildrenArray().splice(runtimeScene.getVariables().get('indexToRemove').getAsNumber(), 1);

    if (runtimeScene.getVariables().get('SelectedCannonPlayer2').getAsNumber() == runtimeScene.getVariables().get('indexToRemove').getAsNumber()) {
        runtimeScene.getVariables().get('SelectedCannonPlayer2').setNumber(0)
    }

    runtimeScene.getVariables().get('indexToRemove').setNumber(-1);
}
};
gdjs.BattleCode.eventsList65 = function(runtimeScene) {

{


{
{gdjs.VariablesContainer.badVariable.setNumber(-(1));
}}

}


{


const keyIteratorReference8 = runtimeScene.getVariables().get("index");
const valueIteratorReference8 = runtimeScene.getVariables().get("cannonId");
const iterableReference8 = runtimeScene.getVariables().getFromIndex(13);
if(!iterableReference8.isPrimitive()) {
for(
    const iteratorKey8 in 
    iterableReference8.getType() === "structure"
      ? iterableReference8.getAllChildren()
      : iterableReference8.getType() === "array"
        ? iterableReference8.getAllChildrenArray()
        : []
) {
    if(iterableReference8.getType() === "structure")
        keyIteratorReference8.setString(iteratorKey8);
    else if(iterableReference8.getType() === "array")
        keyIteratorReference8.setNumber(iteratorKey8);
    const structureChildVariable8 = iterableReference8.getChild(iteratorKey8)
    valueIteratorReference8.castTo(structureChildVariable8.getType())
    if(structureChildVariable8.isPrimitive()) {
        valueIteratorReference8.setValue(structureChildVariable8.getValue());
    } else if (structureChildVariable8.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference8.replaceChildren(structureChildVariable8.getAllChildren());
    } else if (structureChildVariable8.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference8.replaceChildrenArray(structureChildVariable8.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects6, gdjs.BattleCode.GDBlockCannonObjects8);

gdjs.copyArray(gdjs.BattleCode.GDCannonAimObjects6, gdjs.BattleCode.GDCannonAimObjects8);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("cannonId")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.BattleCode.GDCannonAimObjects8.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.BattleCode.GDCannonAimObjects8[0].getVariables()).get("ID")));
}if (gdjs.BattleCode.condition0IsTrue_0.val)
{
{runtimeScene.getVariables().get("indexToRemove").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("index")));
}{gdjs.evtTools.debuggerTools.log("Cannon (" + (gdjs.RuntimeObject.getVariableString(((gdjs.BattleCode.GDBlockCannonObjects8.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.BattleCode.GDBlockCannonObjects8[0].getVariables()).getFromIndex(0))) + ") Index: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("indexToRemove")), "", "");
}}
}
}

}


{



}


{


gdjs.BattleCode.userFunc0x96e6f8(runtimeScene);

}


{


const keyIteratorReference8 = runtimeScene.getVariables().get("index");
const valueIteratorReference8 = runtimeScene.getVariables().get("cannonId");
const iterableReference8 = runtimeScene.getVariables().getFromIndex(14);
if(!iterableReference8.isPrimitive()) {
for(
    const iteratorKey8 in 
    iterableReference8.getType() === "structure"
      ? iterableReference8.getAllChildren()
      : iterableReference8.getType() === "array"
        ? iterableReference8.getAllChildrenArray()
        : []
) {
    if(iterableReference8.getType() === "structure")
        keyIteratorReference8.setString(iteratorKey8);
    else if(iterableReference8.getType() === "array")
        keyIteratorReference8.setNumber(iteratorKey8);
    const structureChildVariable8 = iterableReference8.getChild(iteratorKey8)
    valueIteratorReference8.castTo(structureChildVariable8.getType())
    if(structureChildVariable8.isPrimitive()) {
        valueIteratorReference8.setValue(structureChildVariable8.getValue());
    } else if (structureChildVariable8.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference8.replaceChildren(structureChildVariable8.getAllChildren());
    } else if (structureChildVariable8.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference8.replaceChildrenArray(structureChildVariable8.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(gdjs.BattleCode.GDCannonAimObjects6, gdjs.BattleCode.GDCannonAimObjects8);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("cannonId")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.BattleCode.GDCannonAimObjects8.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.BattleCode.GDCannonAimObjects8[0].getVariables()).get("ID")));
}if (gdjs.BattleCode.condition0IsTrue_0.val)
{
{runtimeScene.getVariables().get("indexToRemove").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("index")));
}{runtimeScene.getVariables().getFromIndex(16).setNumber(0);
}}
}
}

}


{



}


{


gdjs.BattleCode.userFunc0x99e7c8(runtimeScene);

}


{


{
gdjs.copyArray(gdjs.BattleCode.GDCannonAimObjects6, gdjs.BattleCode.GDCannonAimObjects7);

{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects7.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects7[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.BattleCode.eventsList66 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.BattleCode.GDCannonAimObjects5);

for(gdjs.BattleCode.forEachIndex6 = 0;gdjs.BattleCode.forEachIndex6 < gdjs.BattleCode.GDCannonAimObjects5.length;++gdjs.BattleCode.forEachIndex6) {
gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects4, gdjs.BattleCode.GDBlockCannonObjects6);

gdjs.BattleCode.GDCannonAimObjects6.length = 0;


gdjs.BattleCode.forEachTemporary6 = gdjs.BattleCode.GDCannonAimObjects5[gdjs.BattleCode.forEachIndex6];
gdjs.BattleCode.GDCannonAimObjects6.push(gdjs.BattleCode.forEachTemporary6);
gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects6.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects6[i].getVariableNumber(gdjs.BattleCode.GDCannonAimObjects6[i].getVariables().get("ID")) == (gdjs.RuntimeObject.getVariableNumber(((gdjs.BattleCode.GDBlockCannonObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.BattleCode.GDBlockCannonObjects6[0].getVariables()).getFromIndex(0))) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCannonAimObjects6[k] = gdjs.BattleCode.GDCannonAimObjects6[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects6.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.BattleCode.eventsList65(runtimeScene);} //Subevents end.
}
}

}


};gdjs.BattleCode.eventsList67 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.BattleCode.GDBlockCannonObjects2, gdjs.BattleCode.GDBlockCannonObjects3);


for(gdjs.BattleCode.forEachIndex4 = 0;gdjs.BattleCode.forEachIndex4 < gdjs.BattleCode.GDBlockCannonObjects3.length;++gdjs.BattleCode.forEachIndex4) {
gdjs.BattleCode.GDBlockCannonObjects4.length = 0;


gdjs.BattleCode.forEachTemporary4 = gdjs.BattleCode.GDBlockCannonObjects3[gdjs.BattleCode.forEachIndex4];
gdjs.BattleCode.GDBlockCannonObjects4.push(gdjs.BattleCode.forEachTemporary4);
gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects4[i].getVariableNumber(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().getFromIndex(3)) <= 0 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockCannonObjects4[k] = gdjs.BattleCode.GDBlockCannonObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.BattleCode.eventsList66(runtimeScene);} //Subevents end.
}
}

}


{


{
/* Reuse gdjs.BattleCode.GDBlockObjects2 */
/* Reuse gdjs.BattleCode.GDBlock1x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x1Objects2 */
/* Reuse gdjs.BattleCode.GDBlock2x2Objects2 */
/* Reuse gdjs.BattleCode.GDBlockCannonObjects2 */
/* Reuse gdjs.BattleCode.GDBlockIObjects2 */
/* Reuse gdjs.BattleCode.GDBlockLObjects2 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\sound\\effects\\block-break.wav", 2, false, 30, 1);
}}

}


};gdjs.BattleCode.eventsList68 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.BattleCode.GDCoreObjects2, gdjs.BattleCode.GDCoreObjects3);


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCoreObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCoreObjects3[i].getVariableString(gdjs.BattleCode.GDCoreObjects3[i].getVariables().getFromIndex(1)) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCoreObjects3[k] = gdjs.BattleCode.GDCoreObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDCoreObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(17).setString("Player 2");
}}

}


{

/* Reuse gdjs.BattleCode.GDCoreObjects2 */

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCoreObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCoreObjects2[i].getVariableString(gdjs.BattleCode.GDCoreObjects2[i].getVariables().getFromIndex(1)) == "Player2" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCoreObjects2[k] = gdjs.BattleCode.GDCoreObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDCoreObjects2.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(17).setString("Player 1");
}}

}


};gdjs.BattleCode.eventsList69 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects4);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects4[i].getVariableNumber(gdjs.BattleCode.GDBlockCannonObjects4[i].getVariables().getFromIndex(0)) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("cannonId")) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockCannonObjects4[k] = gdjs.BattleCode.GDBlockCannonObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockCannonObjects4 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects4[i].enableEffect("Selected", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.BattleCode.GDCannonAimObjects4);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects4.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects4[i].getVariableNumber(gdjs.BattleCode.GDCannonAimObjects4[i].getVariables().get("ID")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("cannonId")) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCannonAimObjects4[k] = gdjs.BattleCode.GDCannonAimObjects4[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects4.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects4 */
{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects4[i].enableEffect("Selected", true);
}
}}

}


};gdjs.BattleCode.eventsList70 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects3[i].getVariableNumber(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().getFromIndex(0)) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("cannonId")) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockCannonObjects3[k] = gdjs.BattleCode.GDBlockCannonObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDBlockCannonObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].enableEffect("Selected", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.BattleCode.GDCannonAimObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCannonAimObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCannonAimObjects3[i].getVariableNumber(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().get("ID")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("cannonId")) ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCannonAimObjects3[k] = gdjs.BattleCode.GDCannonAimObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDCannonAimObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCannonAimObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].enableEffect("Selected", true);
}
}}

}


};gdjs.BattleCode.eventsList71 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("TextBattleTimer"), gdjs.BattleCode.GDTextBattleTimerObjects2);
{for(var i = 0, len = gdjs.BattleCode.GDTextBattleTimerObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBattleTimerObjects2[i].setString(gdjs.evtTools.common.toString(Math.round(Math.abs(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "battle") - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(18))))));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.BattleCode.GDCannonAimObjects2);

for(gdjs.BattleCode.forEachIndex3 = 0;gdjs.BattleCode.forEachIndex3 < gdjs.BattleCode.GDCannonAimObjects2.length;++gdjs.BattleCode.forEachIndex3) {
gdjs.BattleCode.GDCannonAimObjects3.length = 0;


gdjs.BattleCode.forEachTemporary3 = gdjs.BattleCode.GDCannonAimObjects2[gdjs.BattleCode.forEachIndex3];
gdjs.BattleCode.GDCannonAimObjects3.push(gdjs.BattleCode.forEachTemporary3);
if (true) {

{ //Subevents: 
gdjs.BattleCode.eventsList42(runtimeScene);} //Subevents end.
}
}

}


{


gdjs.BattleCode.eventsList58(runtimeScene);
}


{


gdjs.BattleCode.eventsList62(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects2);
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockObjects2[i].getVariableNumber(gdjs.BattleCode.GDBlockObjects2[i].getVariables().get("Health")) <= 0 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockObjects2[k] = gdjs.BattleCode.GDBlockObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock1x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock1x2Objects2[i].getVariableNumber(gdjs.BattleCode.GDBlock1x2Objects2[i].getVariables().get("Health")) <= 0 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock1x2Objects2[k] = gdjs.BattleCode.GDBlock1x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock1x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x1Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x1Objects2[i].getVariableNumber(gdjs.BattleCode.GDBlock2x1Objects2[i].getVariables().get("Health")) <= 0 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x1Objects2[k] = gdjs.BattleCode.GDBlock2x1Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlock2x2Objects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlock2x2Objects2[i].getVariableNumber(gdjs.BattleCode.GDBlock2x2Objects2[i].getVariables().get("Health")) <= 0 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlock2x2Objects2[k] = gdjs.BattleCode.GDBlock2x2Objects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlock2x2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockLObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockLObjects2[i].getVariableNumber(gdjs.BattleCode.GDBlockLObjects2[i].getVariables().get("Health")) <= 0 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockLObjects2[k] = gdjs.BattleCode.GDBlockLObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockLObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockIObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockIObjects2[i].getVariableNumber(gdjs.BattleCode.GDBlockIObjects2[i].getVariables().get("Health")) <= 0 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockIObjects2[k] = gdjs.BattleCode.GDBlockIObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockIObjects2.length = k;for(var i = 0, k = 0, l = gdjs.BattleCode.GDBlockCannonObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDBlockCannonObjects2[i].getVariableNumber(gdjs.BattleCode.GDBlockCannonObjects2[i].getVariables().get("Health")) <= 0 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDBlockCannonObjects2[k] = gdjs.BattleCode.GDBlockCannonObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDBlockCannonObjects2.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList67(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Core"), gdjs.BattleCode.GDCoreObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDCoreObjects2.length;i<l;++i) {
    if ( gdjs.BattleCode.GDCoreObjects2[i].getVariableNumber(gdjs.BattleCode.GDCoreObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDCoreObjects2[k] = gdjs.BattleCode.GDCoreObjects2[i];
        ++k;
    }
}
gdjs.BattleCode.GDCoreObjects2.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDCoreObjects2 */
{for(var i = 0, len = gdjs.BattleCode.GDCoreObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDCoreObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.debuggerTools.log("Game Over", "", "");
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "battle");
}{runtimeScene.getVariables().getFromIndex(2).setString("gameOver");
}
{ //Subevents
gdjs.BattleCode.eventsList68(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "battle") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(18));
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(2).setString("build");
}{runtimeScene.getVariables().getFromIndex(10).setString("start");
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("BlockCannon"), gdjs.BattleCode.GDBlockCannonObjects2);
gdjs.copyArray(runtimeScene.getObjects("CannonAim"), gdjs.BattleCode.GDCannonAimObjects2);
{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects2[i].enableEffect("Selected", false);
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects2[i].enableEffect("Selected", false);
}
}}

}


{


const keyIteratorReference3 = runtimeScene.getVariables().get("index");
const valueIteratorReference3 = runtimeScene.getVariables().get("cannonId");
const iterableReference3 = runtimeScene.getVariables().getFromIndex(13);
if(!iterableReference3.isPrimitive()) {
for(
    const iteratorKey3 in 
    iterableReference3.getType() === "structure"
      ? iterableReference3.getAllChildren()
      : iterableReference3.getType() === "array"
        ? iterableReference3.getAllChildrenArray()
        : []
) {
    if(iterableReference3.getType() === "structure")
        keyIteratorReference3.setString(iteratorKey3);
    else if(iterableReference3.getType() === "array")
        keyIteratorReference3.setNumber(iteratorKey3);
    const structureChildVariable3 = iterableReference3.getChild(iteratorKey3)
    valueIteratorReference3.castTo(structureChildVariable3.getType())
    if(structureChildVariable3.isPrimitive()) {
        valueIteratorReference3.setValue(structureChildVariable3.getValue());
    } else if (structureChildVariable3.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference3.replaceChildren(structureChildVariable3.getAllChildren());
    } else if (structureChildVariable3.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference3.replaceChildrenArray(structureChildVariable3.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("index")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(15));
}if (gdjs.BattleCode.condition0IsTrue_0.val)
{

{ //Subevents: 
gdjs.BattleCode.eventsList69(runtimeScene);} //Subevents end.
}
}
}

}


{


const keyIteratorReference2 = runtimeScene.getVariables().get("index");
const valueIteratorReference2 = runtimeScene.getVariables().get("cannonId");
const iterableReference2 = runtimeScene.getVariables().getFromIndex(14);
if(!iterableReference2.isPrimitive()) {
for(
    const iteratorKey2 in 
    iterableReference2.getType() === "structure"
      ? iterableReference2.getAllChildren()
      : iterableReference2.getType() === "array"
        ? iterableReference2.getAllChildrenArray()
        : []
) {
    if(iterableReference2.getType() === "structure")
        keyIteratorReference2.setString(iteratorKey2);
    else if(iterableReference2.getType() === "array")
        keyIteratorReference2.setNumber(iteratorKey2);
    const structureChildVariable2 = iterableReference2.getChild(iteratorKey2)
    valueIteratorReference2.castTo(structureChildVariable2.getType())
    if(structureChildVariable2.isPrimitive()) {
        valueIteratorReference2.setValue(structureChildVariable2.getValue());
    } else if (structureChildVariable2.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference2.replaceChildren(structureChildVariable2.getAllChildren());
    } else if (structureChildVariable2.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference2.replaceChildrenArray(structureChildVariable2.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("index")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(16));
}if (gdjs.BattleCode.condition0IsTrue_0.val)
{

{ //Subevents: 
gdjs.BattleCode.eventsList70(runtimeScene);} //Subevents end.
}
}
}

}


};gdjs.BattleCode.eventsList72 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(10)) == "start";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList41(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(10)) == "main";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList71(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList73 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "battle";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList72(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDButtonPlayAgainObjects2Objects = Hashtable.newFrom({"ButtonPlayAgain": gdjs.BattleCode.GDButtonPlayAgainObjects2});gdjs.BattleCode.eventsList74 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Battle", true);
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDButtonPlayAgainObjects1Objects = Hashtable.newFrom({"ButtonPlayAgain": gdjs.BattleCode.GDButtonPlayAgainObjects1});gdjs.BattleCode.eventsList75 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10344212);
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ButtonPlay"), gdjs.BattleCode.GDButtonPlayObjects2);
gdjs.copyArray(runtimeScene.getObjects("ButtonPlayAgain"), gdjs.BattleCode.GDButtonPlayAgainObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextBattleTimer"), gdjs.BattleCode.GDTextBattleTimerObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextGameOver"), gdjs.BattleCode.GDTextGameOverObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextGameOverWinner"), gdjs.BattleCode.GDTextGameOverWinnerObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextPlayerAgain"), gdjs.BattleCode.GDTextPlayerAgainObjects2);
{for(var i = 0, len = gdjs.BattleCode.GDTextGameOverObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextGameOverObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDTextGameOverWinnerObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextGameOverWinnerObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDButtonPlayObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDButtonPlayObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDTextPlayerAgainObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextPlayerAgainObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDButtonPlayAgainObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDButtonPlayAgainObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.BattleCode.GDTextBattleTimerObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextBattleTimerObjects2[i].setString("");
}
}{for(var i = 0, len = gdjs.BattleCode.GDTextGameOverWinnerObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextGameOverWinnerObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(17)) + " Won!");
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets\\sound\\effects\\game-over.wav", 2, false, 70, 1);
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "assets\\sound\\music\\Blissful-Trance.mp3", 1, false, 20, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ButtonPlayAgain"), gdjs.BattleCode.GDButtonPlayAgainObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDButtonPlayAgainObjects2Objects, runtimeScene, true, false);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDButtonPlayAgainObjects2 */
{for(var i = 0, len = gdjs.BattleCode.GDButtonPlayAgainObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDButtonPlayAgainObjects2[i].setAnimation(1);
}
}
{ //Subevents
gdjs.BattleCode.eventsList74(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ButtonPlayAgain"), gdjs.BattleCode.GDButtonPlayAgainObjects1);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDButtonPlayAgainObjects1Objects, runtimeScene, true, true);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDButtonPlayAgainObjects1 */
{for(var i = 0, len = gdjs.BattleCode.GDButtonPlayAgainObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDButtonPlayAgainObjects1[i].setAnimation(0);
}
}}

}


};gdjs.BattleCode.eventsList76 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(2)) == "gameOver";
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList75(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDDarkOverlayObjects2Objects = Hashtable.newFrom({"DarkOverlay": gdjs.BattleCode.GDDarkOverlayObjects2});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDTextContinueObjects3Objects = Hashtable.newFrom({"TextContinue": gdjs.BattleCode.GDTextContinueObjects3});gdjs.BattleCode.eventsList77 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getVariables().getFromIndex(20));
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDTextExitObjects3Objects = Hashtable.newFrom({"TextExit": gdjs.BattleCode.GDTextExitObjects3});gdjs.BattleCode.eventsList78 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDTextContinueObjects3Objects = Hashtable.newFrom({"TextContinue": gdjs.BattleCode.GDTextContinueObjects3});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDTextExitObjects2Objects = Hashtable.newFrom({"TextExit": gdjs.BattleCode.GDTextExitObjects2});gdjs.BattleCode.eventsList79 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("TextContinue"), gdjs.BattleCode.GDTextContinueObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDTextContinueObjects3Objects, runtimeScene, true, false);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDTextContinueObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDTextContinueObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDTextContinueObjects3[i].setColor("238;225;176");
}
}
{ //Subevents
gdjs.BattleCode.eventsList77(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TextExit"), gdjs.BattleCode.GDTextExitObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDTextExitObjects3Objects, runtimeScene, true, false);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDTextExitObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDTextExitObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDTextExitObjects3[i].setColor("238;225;176");
}
}
{ //Subevents
gdjs.BattleCode.eventsList78(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TextContinue"), gdjs.BattleCode.GDTextContinueObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDTextContinueObjects3Objects, runtimeScene, true, true);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDTextContinueObjects3 */
{for(var i = 0, len = gdjs.BattleCode.GDTextContinueObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDTextContinueObjects3[i].setColor("228;228;228");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("TextExit"), gdjs.BattleCode.GDTextExitObjects2);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDTextExitObjects2Objects, runtimeScene, true, true);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
/* Reuse gdjs.BattleCode.GDTextExitObjects2 */
{for(var i = 0, len = gdjs.BattleCode.GDTextExitObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextExitObjects2[i].setColor("228;228;228");
}
}}

}


};gdjs.BattleCode.eventsList80 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("DarkOverlay"), gdjs.BattleCode.GDDarkOverlayObjects2);
{for(var i = 0, len = gdjs.BattleCode.GDDarkOverlayObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDDarkOverlayObjects2[i].setHeight(gdjs.evtTools.window.getWindowInnerHeight());
}
}{for(var i = 0, len = gdjs.BattleCode.GDDarkOverlayObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDDarkOverlayObjects2[i].setWidth(gdjs.evtTools.window.getWindowInnerWidth());
}
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition0IsTrue_0;
gdjs.BattleCode.condition0IsTrue_1.val = false;
gdjs.BattleCode.condition1IsTrue_1.val = false;
{
gdjs.BattleCode.condition0IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Escape");
if( gdjs.BattleCode.condition0IsTrue_1.val ) {
    gdjs.BattleCode.conditionTrue_1.val = true;
}
}
{
gdjs.BattleCode.condition1IsTrue_1.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if( gdjs.BattleCode.condition1IsTrue_1.val ) {
    gdjs.BattleCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getVariables().getFromIndex(20));
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
gdjs.BattleCode.condition1IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(20), true);
}if ( gdjs.BattleCode.condition0IsTrue_0.val ) {
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition1IsTrue_0;
gdjs.BattleCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10350476);
}
}}
if (gdjs.BattleCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.BattleCode.GDAObjects2);
gdjs.copyArray(runtimeScene.getObjects("Aim"), gdjs.BattleCode.GDAimObjects2);
gdjs.copyArray(runtimeScene.getObjects("Arrow"), gdjs.BattleCode.GDArrowObjects2);
gdjs.copyArray(runtimeScene.getObjects("D"), gdjs.BattleCode.GDDObjects2);
gdjs.copyArray(runtimeScene.getObjects("Key"), gdjs.BattleCode.GDKeyObjects2);
gdjs.copyArray(runtimeScene.getObjects("S"), gdjs.BattleCode.GDSObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextContinue"), gdjs.BattleCode.GDTextContinueObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextExit"), gdjs.BattleCode.GDTextExitObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextMoveBlocks"), gdjs.BattleCode.GDTextMoveBlocksObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextPauseTitle"), gdjs.BattleCode.GDTextPauseTitleObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextPlayer1Controls"), gdjs.BattleCode.GDTextPlayer1ControlsObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextPlayer2Controls"), gdjs.BattleCode.GDTextPlayer2ControlsObjects2);
gdjs.copyArray(runtimeScene.getObjects("W"), gdjs.BattleCode.GDWObjects2);
gdjs.BattleCode.GDDarkOverlayObjects2.length = 0;

{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDDarkOverlayObjects2Objects, 0, 0, "Pause");
}{for(var i = 0, len = gdjs.BattleCode.GDDarkOverlayObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDDarkOverlayObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.BattleCode.GDDarkOverlayObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDDarkOverlayObjects2[i].setOpacity(150);
}
}{for(var i = 0, len = gdjs.BattleCode.GDTextPauseTitleObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextPauseTitleObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDTextContinueObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextContinueObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDTextExitObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextExitObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDAObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDAObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDArrowObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDArrowObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDWObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDWObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDSObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDSObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDDObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDDObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDKeyObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDKeyObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDTextPlayer1ControlsObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextPlayer1ControlsObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDTextPlayer2ControlsObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextPlayer2ControlsObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDTextMoveBlocksObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDTextMoveBlocksObjects2[i].hide(false);
}
for(var i = 0, len = gdjs.BattleCode.GDAimObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDAimObjects2[i].hide(false);
}
}{gdjs.evtTools.sound.pauseMusicOnChannel(runtimeScene, 1);
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "assets\\sound\\music\\the-executive-lounge-dan-barton-main-version-01-00-8850.mp3", 2, true, 5, 1);
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(20), true);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList79(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
gdjs.BattleCode.condition1IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(20), false);
}if ( gdjs.BattleCode.condition0IsTrue_0.val ) {
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition1IsTrue_0;
gdjs.BattleCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10357444);
}
}}
if (gdjs.BattleCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("A"), gdjs.BattleCode.GDAObjects1);
gdjs.copyArray(runtimeScene.getObjects("Aim"), gdjs.BattleCode.GDAimObjects1);
gdjs.copyArray(runtimeScene.getObjects("Arrow"), gdjs.BattleCode.GDArrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("D"), gdjs.BattleCode.GDDObjects1);
gdjs.copyArray(runtimeScene.getObjects("DarkOverlay"), gdjs.BattleCode.GDDarkOverlayObjects1);
gdjs.copyArray(runtimeScene.getObjects("Key"), gdjs.BattleCode.GDKeyObjects1);
gdjs.copyArray(runtimeScene.getObjects("S"), gdjs.BattleCode.GDSObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextContinue"), gdjs.BattleCode.GDTextContinueObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextExit"), gdjs.BattleCode.GDTextExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextMoveBlocks"), gdjs.BattleCode.GDTextMoveBlocksObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextPauseTitle"), gdjs.BattleCode.GDTextPauseTitleObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextPlayer1Controls"), gdjs.BattleCode.GDTextPlayer1ControlsObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextPlayer2Controls"), gdjs.BattleCode.GDTextPlayer2ControlsObjects1);
gdjs.copyArray(runtimeScene.getObjects("W"), gdjs.BattleCode.GDWObjects1);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}{for(var i = 0, len = gdjs.BattleCode.GDTextPauseTitleObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextPauseTitleObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextContinueObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextContinueObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextExitObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextExitObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDAObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDAObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDArrowObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDArrowObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDWObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDWObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDSObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDSObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDDObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDDObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDKeyObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDKeyObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextPlayer1ControlsObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextPlayer1ControlsObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextPlayer2ControlsObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextPlayer2ControlsObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDTextMoveBlocksObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDTextMoveBlocksObjects1[i].hide();
}
for(var i = 0, len = gdjs.BattleCode.GDAimObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDAimObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.BattleCode.GDDarkOverlayObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDDarkOverlayObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 2);
}{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}}

}


};gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects = Hashtable.newFrom({"BlockCannon": gdjs.BattleCode.GDBlockCannonObjects3});gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDCannonAimObjects3Objects = Hashtable.newFrom({"CannonAim": gdjs.BattleCode.GDCannonAimObjects3});gdjs.BattleCode.eventsList81 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Block"), gdjs.BattleCode.GDBlockObjects3);
gdjs.copyArray(runtimeScene.getObjects("Block1x2"), gdjs.BattleCode.GDBlock1x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x1"), gdjs.BattleCode.GDBlock2x1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Block2x2"), gdjs.BattleCode.GDBlock2x2Objects3);
gdjs.copyArray(runtimeScene.getObjects("BlockI"), gdjs.BattleCode.GDBlockIObjects3);
gdjs.copyArray(runtimeScene.getObjects("BlockL"), gdjs.BattleCode.GDBlockLObjects3);
/* Reuse gdjs.BattleCode.GDSpawnObjects3 */
gdjs.BattleCode.GDBlockCannonObjects3.length = 0;

gdjs.BattleCode.GDCannonAimObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDBlockCannonObjects3Objects, (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].returnVariable(gdjs.BattleCode.GDBlockCannonObjects3[i].getVariables().getFromIndex(1)).setString("Player1");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.BattleCode.mapOfGDgdjs_46BattleCode_46GDCannonAimObjects3Objects, (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointX("")), (( gdjs.BattleCode.GDSpawnObjects3.length === 0 ) ? 0 :gdjs.BattleCode.GDSpawnObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].setZOrder(gdjs.BattleCode.GDCannonAimObjects3[i].getZOrder() + (1));
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].returnVariable(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().get("ID")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].returnVariable(gdjs.BattleCode.GDCannonAimObjects3[i].getVariables().get("Player")).setString("Player1");
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.BattleCode.GDBlockObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock1x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock1x2Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x1Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x1Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlock2x2Objects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlock2x2Objects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockLObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockLObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockIObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockIObjects3[i].resetTimer("tetris");
}
for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].resetTimer("tetris");
}
}{gdjs.evtTools.variable.valuePush(runtimeScene.getVariables().getFromIndex(13), (gdjs.RuntimeObject.getVariableNumber(((gdjs.BattleCode.GDCannonAimObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.BattleCode.GDCannonAimObjects3[0].getVariables()).get("ID"))));
}{for(var i = 0, len = gdjs.BattleCode.GDBlockCannonObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDBlockCannonObjects3[i].enableEffect("Selected", false);
}
}{for(var i = 0, len = gdjs.BattleCode.GDCannonAimObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDCannonAimObjects3[i].enableEffect("Selected", false);
}
}}

}


};gdjs.BattleCode.eventsList82 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spawn"), gdjs.BattleCode.GDSpawnObjects3);

gdjs.BattleCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.BattleCode.GDSpawnObjects3.length;i<l;++i) {
    if ( gdjs.BattleCode.GDSpawnObjects3[i].getVariableString(gdjs.BattleCode.GDSpawnObjects3[i].getVariables().get("Player")) == "Player1" ) {
        gdjs.BattleCode.condition0IsTrue_0.val = true;
        gdjs.BattleCode.GDSpawnObjects3[k] = gdjs.BattleCode.GDSpawnObjects3[i];
        ++k;
    }
}
gdjs.BattleCode.GDSpawnObjects3.length = k;}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList81(runtimeScene);} //End of subevents
}

}


};gdjs.BattleCode.eventsList83 = function(runtimeScene) {

};gdjs.BattleCode.eventsList84 = function(runtimeScene) {

};gdjs.BattleCode.eventsList85 = function(runtimeScene) {

};gdjs.BattleCode.eventsList86 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "r");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Battle", false);
}}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "c");
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList82(runtimeScene);} //End of subevents
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.BattleCode.GDDebugObjects3);
{for(var i = 0, len = gdjs.BattleCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDDebugObjects3[i].setString("");
}
}{for(var i = 0, len = gdjs.BattleCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDDebugObjects3[i].setString(gdjs.BattleCode.GDDebugObjects3[i].getString() + ("Player1" + gdjs.evtTools.string.newLine() + "Cannons: ["));
}
}}

}


{


const keyIteratorReference4 = runtimeScene.getVariables().get("index");
const valueIteratorReference4 = runtimeScene.getVariables().get("cannonId");
const iterableReference4 = runtimeScene.getVariables().getFromIndex(13);
if(!iterableReference4.isPrimitive()) {
for(
    const iteratorKey4 in 
    iterableReference4.getType() === "structure"
      ? iterableReference4.getAllChildren()
      : iterableReference4.getType() === "array"
        ? iterableReference4.getAllChildrenArray()
        : []
) {
    if(iterableReference4.getType() === "structure")
        keyIteratorReference4.setString(iteratorKey4);
    else if(iterableReference4.getType() === "array")
        keyIteratorReference4.setNumber(iteratorKey4);
    const structureChildVariable4 = iterableReference4.getChild(iteratorKey4)
    valueIteratorReference4.castTo(structureChildVariable4.getType())
    if(structureChildVariable4.isPrimitive()) {
        valueIteratorReference4.setValue(structureChildVariable4.getValue());
    } else if (structureChildVariable4.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference4.replaceChildren(structureChildVariable4.getAllChildren());
    } else if (structureChildVariable4.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference4.replaceChildrenArray(structureChildVariable4.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.BattleCode.GDDebugObjects4);

if (true)
{
{for(var i = 0, len = gdjs.BattleCode.GDDebugObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDDebugObjects4[i].setString(gdjs.BattleCode.GDDebugObjects4[i].getString() + (gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("cannonId")) + ","));
}
}}
}
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.BattleCode.GDDebugObjects3);
{for(var i = 0, len = gdjs.BattleCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDDebugObjects3[i].setString(gdjs.BattleCode.GDDebugObjects3[i].getString() + ("]" + gdjs.evtTools.string.newLine() + "Selected: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(15)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine()));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.BattleCode.GDDebugObjects3);
{for(var i = 0, len = gdjs.BattleCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDDebugObjects3[i].setString(gdjs.BattleCode.GDDebugObjects3[i].getString() + ("Player2" + gdjs.evtTools.string.newLine() + "Cannons: ["));
}
}}

}


{


const keyIteratorReference4 = runtimeScene.getVariables().get("index");
const valueIteratorReference4 = runtimeScene.getVariables().get("cannonId");
const iterableReference4 = runtimeScene.getVariables().getFromIndex(14);
if(!iterableReference4.isPrimitive()) {
for(
    const iteratorKey4 in 
    iterableReference4.getType() === "structure"
      ? iterableReference4.getAllChildren()
      : iterableReference4.getType() === "array"
        ? iterableReference4.getAllChildrenArray()
        : []
) {
    if(iterableReference4.getType() === "structure")
        keyIteratorReference4.setString(iteratorKey4);
    else if(iterableReference4.getType() === "array")
        keyIteratorReference4.setNumber(iteratorKey4);
    const structureChildVariable4 = iterableReference4.getChild(iteratorKey4)
    valueIteratorReference4.castTo(structureChildVariable4.getType())
    if(structureChildVariable4.isPrimitive()) {
        valueIteratorReference4.setValue(structureChildVariable4.getValue());
    } else if (structureChildVariable4.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference4.replaceChildren(structureChildVariable4.getAllChildren());
    } else if (structureChildVariable4.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference4.replaceChildrenArray(structureChildVariable4.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.BattleCode.GDDebugObjects4);

if (true)
{
{for(var i = 0, len = gdjs.BattleCode.GDDebugObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDDebugObjects4[i].setString(gdjs.BattleCode.GDDebugObjects4[i].getString() + (gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("cannonId")) + ","));
}
}}
}
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.BattleCode.GDDebugObjects3);
{for(var i = 0, len = gdjs.BattleCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.BattleCode.GDDebugObjects3[i].setString(gdjs.BattleCode.GDDebugObjects3[i].getString() + ("]" + gdjs.evtTools.string.newLine() + "Selected: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(16)) + gdjs.evtTools.string.newLine() + gdjs.evtTools.string.newLine() + "Turn Blocks: ["));
}
}}

}


{


const keyIteratorReference4 = runtimeScene.getVariables().get("index");
const valueIteratorReference4 = runtimeScene.getVariables().get("turnBlock");
const iterableReference4 = runtimeScene.getVariables().getFromIndex(7);
if(!iterableReference4.isPrimitive()) {
for(
    const iteratorKey4 in 
    iterableReference4.getType() === "structure"
      ? iterableReference4.getAllChildren()
      : iterableReference4.getType() === "array"
        ? iterableReference4.getAllChildrenArray()
        : []
) {
    if(iterableReference4.getType() === "structure")
        keyIteratorReference4.setString(iteratorKey4);
    else if(iterableReference4.getType() === "array")
        keyIteratorReference4.setNumber(iteratorKey4);
    const structureChildVariable4 = iterableReference4.getChild(iteratorKey4)
    valueIteratorReference4.castTo(structureChildVariable4.getType())
    if(structureChildVariable4.isPrimitive()) {
        valueIteratorReference4.setValue(structureChildVariable4.getValue());
    } else if (structureChildVariable4.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference4.replaceChildren(structureChildVariable4.getAllChildren());
    } else if (structureChildVariable4.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference4.replaceChildrenArray(structureChildVariable4.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.BattleCode.GDDebugObjects4);

if (true)
{
{for(var i = 0, len = gdjs.BattleCode.GDDebugObjects4.length ;i < len;++i) {
    gdjs.BattleCode.GDDebugObjects4[i].setString(gdjs.BattleCode.GDDebugObjects4[i].getString() + (gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("turnBlock")) + ","));
}
}}
}
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.BattleCode.GDDebugObjects2);
{for(var i = 0, len = gdjs.BattleCode.GDDebugObjects2.length ;i < len;++i) {
    gdjs.BattleCode.GDDebugObjects2[i].setString(gdjs.BattleCode.GDDebugObjects2[i].getString() + ("]"));
}
}}

}


};gdjs.BattleCode.eventsList87 = function(runtimeScene) {

{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BattleCode.eventsList86(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
gdjs.BattleCode.condition1IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}if ( gdjs.BattleCode.condition0IsTrue_0.val ) {
{
{gdjs.BattleCode.conditionTrue_1 = gdjs.BattleCode.condition1IsTrue_0;
gdjs.BattleCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10365892);
}
}}
if (gdjs.BattleCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.BattleCode.GDDebugObjects1);
{for(var i = 0, len = gdjs.BattleCode.GDDebugObjects1.length ;i < len;++i) {
    gdjs.BattleCode.GDDebugObjects1[i].hide();
}
}}

}


};gdjs.BattleCode.eventsList88 = function(runtimeScene) {

{



}


{


gdjs.BattleCode.condition0IsTrue_0.val = false;
{
gdjs.BattleCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.BattleCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Lights", 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "UI_BuildTurn", 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "UI_BattleTurn", 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "UI_GameOver", 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "UI_GameOver", 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "UI_Pause", 0, 0);
}
{ //Subevents
gdjs.BattleCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.BattleCode.eventsList2(runtimeScene);
}


{


gdjs.BattleCode.eventsList39(runtimeScene);
}


{


gdjs.BattleCode.eventsList73(runtimeScene);
}


{


gdjs.BattleCode.eventsList76(runtimeScene);
}


{


gdjs.BattleCode.eventsList80(runtimeScene);
}


{


gdjs.BattleCode.eventsList87(runtimeScene);
}


};

gdjs.BattleCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.BattleCode.GDBulletObjects1.length = 0;
gdjs.BattleCode.GDBulletObjects2.length = 0;
gdjs.BattleCode.GDBulletObjects3.length = 0;
gdjs.BattleCode.GDBulletObjects4.length = 0;
gdjs.BattleCode.GDBulletObjects5.length = 0;
gdjs.BattleCode.GDBulletObjects6.length = 0;
gdjs.BattleCode.GDBulletObjects7.length = 0;
gdjs.BattleCode.GDBulletObjects8.length = 0;
gdjs.BattleCode.GDBlockCannonObjects1.length = 0;
gdjs.BattleCode.GDBlockCannonObjects2.length = 0;
gdjs.BattleCode.GDBlockCannonObjects3.length = 0;
gdjs.BattleCode.GDBlockCannonObjects4.length = 0;
gdjs.BattleCode.GDBlockCannonObjects5.length = 0;
gdjs.BattleCode.GDBlockCannonObjects6.length = 0;
gdjs.BattleCode.GDBlockCannonObjects7.length = 0;
gdjs.BattleCode.GDBlockCannonObjects8.length = 0;
gdjs.BattleCode.GDCannonAimObjects1.length = 0;
gdjs.BattleCode.GDCannonAimObjects2.length = 0;
gdjs.BattleCode.GDCannonAimObjects3.length = 0;
gdjs.BattleCode.GDCannonAimObjects4.length = 0;
gdjs.BattleCode.GDCannonAimObjects5.length = 0;
gdjs.BattleCode.GDCannonAimObjects6.length = 0;
gdjs.BattleCode.GDCannonAimObjects7.length = 0;
gdjs.BattleCode.GDCannonAimObjects8.length = 0;
gdjs.BattleCode.GDtileBackgroungObjects1.length = 0;
gdjs.BattleCode.GDtileBackgroungObjects2.length = 0;
gdjs.BattleCode.GDtileBackgroungObjects3.length = 0;
gdjs.BattleCode.GDtileBackgroungObjects4.length = 0;
gdjs.BattleCode.GDtileBackgroungObjects5.length = 0;
gdjs.BattleCode.GDtileBackgroungObjects6.length = 0;
gdjs.BattleCode.GDtileBackgroungObjects7.length = 0;
gdjs.BattleCode.GDtileBackgroungObjects8.length = 0;
gdjs.BattleCode.GDGlobalLightObjects1.length = 0;
gdjs.BattleCode.GDGlobalLightObjects2.length = 0;
gdjs.BattleCode.GDGlobalLightObjects3.length = 0;
gdjs.BattleCode.GDGlobalLightObjects4.length = 0;
gdjs.BattleCode.GDGlobalLightObjects5.length = 0;
gdjs.BattleCode.GDGlobalLightObjects6.length = 0;
gdjs.BattleCode.GDGlobalLightObjects7.length = 0;
gdjs.BattleCode.GDGlobalLightObjects8.length = 0;
gdjs.BattleCode.GDCoreLightPlayer2Objects1.length = 0;
gdjs.BattleCode.GDCoreLightPlayer2Objects2.length = 0;
gdjs.BattleCode.GDCoreLightPlayer2Objects3.length = 0;
gdjs.BattleCode.GDCoreLightPlayer2Objects4.length = 0;
gdjs.BattleCode.GDCoreLightPlayer2Objects5.length = 0;
gdjs.BattleCode.GDCoreLightPlayer2Objects6.length = 0;
gdjs.BattleCode.GDCoreLightPlayer2Objects7.length = 0;
gdjs.BattleCode.GDCoreLightPlayer2Objects8.length = 0;
gdjs.BattleCode.GDCoreLightPlayer1Objects1.length = 0;
gdjs.BattleCode.GDCoreLightPlayer1Objects2.length = 0;
gdjs.BattleCode.GDCoreLightPlayer1Objects3.length = 0;
gdjs.BattleCode.GDCoreLightPlayer1Objects4.length = 0;
gdjs.BattleCode.GDCoreLightPlayer1Objects5.length = 0;
gdjs.BattleCode.GDCoreLightPlayer1Objects6.length = 0;
gdjs.BattleCode.GDCoreLightPlayer1Objects7.length = 0;
gdjs.BattleCode.GDCoreLightPlayer1Objects8.length = 0;
gdjs.BattleCode.GDBlockObjects1.length = 0;
gdjs.BattleCode.GDBlockObjects2.length = 0;
gdjs.BattleCode.GDBlockObjects3.length = 0;
gdjs.BattleCode.GDBlockObjects4.length = 0;
gdjs.BattleCode.GDBlockObjects5.length = 0;
gdjs.BattleCode.GDBlockObjects6.length = 0;
gdjs.BattleCode.GDBlockObjects7.length = 0;
gdjs.BattleCode.GDBlockObjects8.length = 0;
gdjs.BattleCode.GDFloorObjects1.length = 0;
gdjs.BattleCode.GDFloorObjects2.length = 0;
gdjs.BattleCode.GDFloorObjects3.length = 0;
gdjs.BattleCode.GDFloorObjects4.length = 0;
gdjs.BattleCode.GDFloorObjects5.length = 0;
gdjs.BattleCode.GDFloorObjects6.length = 0;
gdjs.BattleCode.GDFloorObjects7.length = 0;
gdjs.BattleCode.GDFloorObjects8.length = 0;
gdjs.BattleCode.GDCoreObjects1.length = 0;
gdjs.BattleCode.GDCoreObjects2.length = 0;
gdjs.BattleCode.GDCoreObjects3.length = 0;
gdjs.BattleCode.GDCoreObjects4.length = 0;
gdjs.BattleCode.GDCoreObjects5.length = 0;
gdjs.BattleCode.GDCoreObjects6.length = 0;
gdjs.BattleCode.GDCoreObjects7.length = 0;
gdjs.BattleCode.GDCoreObjects8.length = 0;
gdjs.BattleCode.GDBackground2Objects1.length = 0;
gdjs.BattleCode.GDBackground2Objects2.length = 0;
gdjs.BattleCode.GDBackground2Objects3.length = 0;
gdjs.BattleCode.GDBackground2Objects4.length = 0;
gdjs.BattleCode.GDBackground2Objects5.length = 0;
gdjs.BattleCode.GDBackground2Objects6.length = 0;
gdjs.BattleCode.GDBackground2Objects7.length = 0;
gdjs.BattleCode.GDBackground2Objects8.length = 0;
gdjs.BattleCode.GDSpawnObjects1.length = 0;
gdjs.BattleCode.GDSpawnObjects2.length = 0;
gdjs.BattleCode.GDSpawnObjects3.length = 0;
gdjs.BattleCode.GDSpawnObjects4.length = 0;
gdjs.BattleCode.GDSpawnObjects5.length = 0;
gdjs.BattleCode.GDSpawnObjects6.length = 0;
gdjs.BattleCode.GDSpawnObjects7.length = 0;
gdjs.BattleCode.GDSpawnObjects8.length = 0;
gdjs.BattleCode.GDBlock1x2Objects1.length = 0;
gdjs.BattleCode.GDBlock1x2Objects2.length = 0;
gdjs.BattleCode.GDBlock1x2Objects3.length = 0;
gdjs.BattleCode.GDBlock1x2Objects4.length = 0;
gdjs.BattleCode.GDBlock1x2Objects5.length = 0;
gdjs.BattleCode.GDBlock1x2Objects6.length = 0;
gdjs.BattleCode.GDBlock1x2Objects7.length = 0;
gdjs.BattleCode.GDBlock1x2Objects8.length = 0;
gdjs.BattleCode.GDBlock2x1Objects1.length = 0;
gdjs.BattleCode.GDBlock2x1Objects2.length = 0;
gdjs.BattleCode.GDBlock2x1Objects3.length = 0;
gdjs.BattleCode.GDBlock2x1Objects4.length = 0;
gdjs.BattleCode.GDBlock2x1Objects5.length = 0;
gdjs.BattleCode.GDBlock2x1Objects6.length = 0;
gdjs.BattleCode.GDBlock2x1Objects7.length = 0;
gdjs.BattleCode.GDBlock2x1Objects8.length = 0;
gdjs.BattleCode.GDBlock2x2Objects1.length = 0;
gdjs.BattleCode.GDBlock2x2Objects2.length = 0;
gdjs.BattleCode.GDBlock2x2Objects3.length = 0;
gdjs.BattleCode.GDBlock2x2Objects4.length = 0;
gdjs.BattleCode.GDBlock2x2Objects5.length = 0;
gdjs.BattleCode.GDBlock2x2Objects6.length = 0;
gdjs.BattleCode.GDBlock2x2Objects7.length = 0;
gdjs.BattleCode.GDBlock2x2Objects8.length = 0;
gdjs.BattleCode.GDBlockLObjects1.length = 0;
gdjs.BattleCode.GDBlockLObjects2.length = 0;
gdjs.BattleCode.GDBlockLObjects3.length = 0;
gdjs.BattleCode.GDBlockLObjects4.length = 0;
gdjs.BattleCode.GDBlockLObjects5.length = 0;
gdjs.BattleCode.GDBlockLObjects6.length = 0;
gdjs.BattleCode.GDBlockLObjects7.length = 0;
gdjs.BattleCode.GDBlockLObjects8.length = 0;
gdjs.BattleCode.GDBlockIObjects1.length = 0;
gdjs.BattleCode.GDBlockIObjects2.length = 0;
gdjs.BattleCode.GDBlockIObjects3.length = 0;
gdjs.BattleCode.GDBlockIObjects4.length = 0;
gdjs.BattleCode.GDBlockIObjects5.length = 0;
gdjs.BattleCode.GDBlockIObjects6.length = 0;
gdjs.BattleCode.GDBlockIObjects7.length = 0;
gdjs.BattleCode.GDBlockIObjects8.length = 0;
gdjs.BattleCode.GDDebugObjects1.length = 0;
gdjs.BattleCode.GDDebugObjects2.length = 0;
gdjs.BattleCode.GDDebugObjects3.length = 0;
gdjs.BattleCode.GDDebugObjects4.length = 0;
gdjs.BattleCode.GDDebugObjects5.length = 0;
gdjs.BattleCode.GDDebugObjects6.length = 0;
gdjs.BattleCode.GDDebugObjects7.length = 0;
gdjs.BattleCode.GDDebugObjects8.length = 0;
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects1.length = 0;
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects2.length = 0;
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects3.length = 0;
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects4.length = 0;
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects5.length = 0;
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects6.length = 0;
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects7.length = 0;
gdjs.BattleCode.GDTextBattleTurnDescriptionObjects8.length = 0;
gdjs.BattleCode.GDTextGameOverWinnerObjects1.length = 0;
gdjs.BattleCode.GDTextGameOverWinnerObjects2.length = 0;
gdjs.BattleCode.GDTextGameOverWinnerObjects3.length = 0;
gdjs.BattleCode.GDTextGameOverWinnerObjects4.length = 0;
gdjs.BattleCode.GDTextGameOverWinnerObjects5.length = 0;
gdjs.BattleCode.GDTextGameOverWinnerObjects6.length = 0;
gdjs.BattleCode.GDTextGameOverWinnerObjects7.length = 0;
gdjs.BattleCode.GDTextGameOverWinnerObjects8.length = 0;
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects1.length = 0;
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects2.length = 0;
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects3.length = 0;
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects4.length = 0;
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects5.length = 0;
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects6.length = 0;
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects7.length = 0;
gdjs.BattleCode.GDTextBuildTurnDescriptionObjects8.length = 0;
gdjs.BattleCode.GDTextBattleTurnObjects1.length = 0;
gdjs.BattleCode.GDTextBattleTurnObjects2.length = 0;
gdjs.BattleCode.GDTextBattleTurnObjects3.length = 0;
gdjs.BattleCode.GDTextBattleTurnObjects4.length = 0;
gdjs.BattleCode.GDTextBattleTurnObjects5.length = 0;
gdjs.BattleCode.GDTextBattleTurnObjects6.length = 0;
gdjs.BattleCode.GDTextBattleTurnObjects7.length = 0;
gdjs.BattleCode.GDTextBattleTurnObjects8.length = 0;
gdjs.BattleCode.GDTextGameOverObjects1.length = 0;
gdjs.BattleCode.GDTextGameOverObjects2.length = 0;
gdjs.BattleCode.GDTextGameOverObjects3.length = 0;
gdjs.BattleCode.GDTextGameOverObjects4.length = 0;
gdjs.BattleCode.GDTextGameOverObjects5.length = 0;
gdjs.BattleCode.GDTextGameOverObjects6.length = 0;
gdjs.BattleCode.GDTextGameOverObjects7.length = 0;
gdjs.BattleCode.GDTextGameOverObjects8.length = 0;
gdjs.BattleCode.GDTextBuildTurnObjects1.length = 0;
gdjs.BattleCode.GDTextBuildTurnObjects2.length = 0;
gdjs.BattleCode.GDTextBuildTurnObjects3.length = 0;
gdjs.BattleCode.GDTextBuildTurnObjects4.length = 0;
gdjs.BattleCode.GDTextBuildTurnObjects5.length = 0;
gdjs.BattleCode.GDTextBuildTurnObjects6.length = 0;
gdjs.BattleCode.GDTextBuildTurnObjects7.length = 0;
gdjs.BattleCode.GDTextBuildTurnObjects8.length = 0;
gdjs.BattleCode.GDButtonPlayObjects1.length = 0;
gdjs.BattleCode.GDButtonPlayObjects2.length = 0;
gdjs.BattleCode.GDButtonPlayObjects3.length = 0;
gdjs.BattleCode.GDButtonPlayObjects4.length = 0;
gdjs.BattleCode.GDButtonPlayObjects5.length = 0;
gdjs.BattleCode.GDButtonPlayObjects6.length = 0;
gdjs.BattleCode.GDButtonPlayObjects7.length = 0;
gdjs.BattleCode.GDButtonPlayObjects8.length = 0;
gdjs.BattleCode.GDTextPlayerAgainObjects1.length = 0;
gdjs.BattleCode.GDTextPlayerAgainObjects2.length = 0;
gdjs.BattleCode.GDTextPlayerAgainObjects3.length = 0;
gdjs.BattleCode.GDTextPlayerAgainObjects4.length = 0;
gdjs.BattleCode.GDTextPlayerAgainObjects5.length = 0;
gdjs.BattleCode.GDTextPlayerAgainObjects6.length = 0;
gdjs.BattleCode.GDTextPlayerAgainObjects7.length = 0;
gdjs.BattleCode.GDTextPlayerAgainObjects8.length = 0;
gdjs.BattleCode.GDBulletParticlePlayer2Objects1.length = 0;
gdjs.BattleCode.GDBulletParticlePlayer2Objects2.length = 0;
gdjs.BattleCode.GDBulletParticlePlayer2Objects3.length = 0;
gdjs.BattleCode.GDBulletParticlePlayer2Objects4.length = 0;
gdjs.BattleCode.GDBulletParticlePlayer2Objects5.length = 0;
gdjs.BattleCode.GDBulletParticlePlayer2Objects6.length = 0;
gdjs.BattleCode.GDBulletParticlePlayer2Objects7.length = 0;
gdjs.BattleCode.GDBulletParticlePlayer2Objects8.length = 0;
gdjs.BattleCode.GDBulletParticleObjects1.length = 0;
gdjs.BattleCode.GDBulletParticleObjects2.length = 0;
gdjs.BattleCode.GDBulletParticleObjects3.length = 0;
gdjs.BattleCode.GDBulletParticleObjects4.length = 0;
gdjs.BattleCode.GDBulletParticleObjects5.length = 0;
gdjs.BattleCode.GDBulletParticleObjects6.length = 0;
gdjs.BattleCode.GDBulletParticleObjects7.length = 0;
gdjs.BattleCode.GDBulletParticleObjects8.length = 0;
gdjs.BattleCode.GDRoofObjects1.length = 0;
gdjs.BattleCode.GDRoofObjects2.length = 0;
gdjs.BattleCode.GDRoofObjects3.length = 0;
gdjs.BattleCode.GDRoofObjects4.length = 0;
gdjs.BattleCode.GDRoofObjects5.length = 0;
gdjs.BattleCode.GDRoofObjects6.length = 0;
gdjs.BattleCode.GDRoofObjects7.length = 0;
gdjs.BattleCode.GDRoofObjects8.length = 0;
gdjs.BattleCode.GDTextBattleTimerObjects1.length = 0;
gdjs.BattleCode.GDTextBattleTimerObjects2.length = 0;
gdjs.BattleCode.GDTextBattleTimerObjects3.length = 0;
gdjs.BattleCode.GDTextBattleTimerObjects4.length = 0;
gdjs.BattleCode.GDTextBattleTimerObjects5.length = 0;
gdjs.BattleCode.GDTextBattleTimerObjects6.length = 0;
gdjs.BattleCode.GDTextBattleTimerObjects7.length = 0;
gdjs.BattleCode.GDTextBattleTimerObjects8.length = 0;
gdjs.BattleCode.GDTesteObjects1.length = 0;
gdjs.BattleCode.GDTesteObjects2.length = 0;
gdjs.BattleCode.GDTesteObjects3.length = 0;
gdjs.BattleCode.GDTesteObjects4.length = 0;
gdjs.BattleCode.GDTesteObjects5.length = 0;
gdjs.BattleCode.GDTesteObjects6.length = 0;
gdjs.BattleCode.GDTesteObjects7.length = 0;
gdjs.BattleCode.GDTesteObjects8.length = 0;
gdjs.BattleCode.GDDarkOverlayObjects1.length = 0;
gdjs.BattleCode.GDDarkOverlayObjects2.length = 0;
gdjs.BattleCode.GDDarkOverlayObjects3.length = 0;
gdjs.BattleCode.GDDarkOverlayObjects4.length = 0;
gdjs.BattleCode.GDDarkOverlayObjects5.length = 0;
gdjs.BattleCode.GDDarkOverlayObjects6.length = 0;
gdjs.BattleCode.GDDarkOverlayObjects7.length = 0;
gdjs.BattleCode.GDDarkOverlayObjects8.length = 0;
gdjs.BattleCode.GDTextExitObjects1.length = 0;
gdjs.BattleCode.GDTextExitObjects2.length = 0;
gdjs.BattleCode.GDTextExitObjects3.length = 0;
gdjs.BattleCode.GDTextExitObjects4.length = 0;
gdjs.BattleCode.GDTextExitObjects5.length = 0;
gdjs.BattleCode.GDTextExitObjects6.length = 0;
gdjs.BattleCode.GDTextExitObjects7.length = 0;
gdjs.BattleCode.GDTextExitObjects8.length = 0;
gdjs.BattleCode.GDTextContinueObjects1.length = 0;
gdjs.BattleCode.GDTextContinueObjects2.length = 0;
gdjs.BattleCode.GDTextContinueObjects3.length = 0;
gdjs.BattleCode.GDTextContinueObjects4.length = 0;
gdjs.BattleCode.GDTextContinueObjects5.length = 0;
gdjs.BattleCode.GDTextContinueObjects6.length = 0;
gdjs.BattleCode.GDTextContinueObjects7.length = 0;
gdjs.BattleCode.GDTextContinueObjects8.length = 0;
gdjs.BattleCode.GDTextPauseTitleObjects1.length = 0;
gdjs.BattleCode.GDTextPauseTitleObjects2.length = 0;
gdjs.BattleCode.GDTextPauseTitleObjects3.length = 0;
gdjs.BattleCode.GDTextPauseTitleObjects4.length = 0;
gdjs.BattleCode.GDTextPauseTitleObjects5.length = 0;
gdjs.BattleCode.GDTextPauseTitleObjects6.length = 0;
gdjs.BattleCode.GDTextPauseTitleObjects7.length = 0;
gdjs.BattleCode.GDTextPauseTitleObjects8.length = 0;
gdjs.BattleCode.GDNewObjectObjects1.length = 0;
gdjs.BattleCode.GDNewObjectObjects2.length = 0;
gdjs.BattleCode.GDNewObjectObjects3.length = 0;
gdjs.BattleCode.GDNewObjectObjects4.length = 0;
gdjs.BattleCode.GDNewObjectObjects5.length = 0;
gdjs.BattleCode.GDNewObjectObjects6.length = 0;
gdjs.BattleCode.GDNewObjectObjects7.length = 0;
gdjs.BattleCode.GDNewObjectObjects8.length = 0;
gdjs.BattleCode.GDTextPlayer2ControlsObjects1.length = 0;
gdjs.BattleCode.GDTextPlayer2ControlsObjects2.length = 0;
gdjs.BattleCode.GDTextPlayer2ControlsObjects3.length = 0;
gdjs.BattleCode.GDTextPlayer2ControlsObjects4.length = 0;
gdjs.BattleCode.GDTextPlayer2ControlsObjects5.length = 0;
gdjs.BattleCode.GDTextPlayer2ControlsObjects6.length = 0;
gdjs.BattleCode.GDTextPlayer2ControlsObjects7.length = 0;
gdjs.BattleCode.GDTextPlayer2ControlsObjects8.length = 0;
gdjs.BattleCode.GDTextPlayer1ControlsObjects1.length = 0;
gdjs.BattleCode.GDTextPlayer1ControlsObjects2.length = 0;
gdjs.BattleCode.GDTextPlayer1ControlsObjects3.length = 0;
gdjs.BattleCode.GDTextPlayer1ControlsObjects4.length = 0;
gdjs.BattleCode.GDTextPlayer1ControlsObjects5.length = 0;
gdjs.BattleCode.GDTextPlayer1ControlsObjects6.length = 0;
gdjs.BattleCode.GDTextPlayer1ControlsObjects7.length = 0;
gdjs.BattleCode.GDTextPlayer1ControlsObjects8.length = 0;
gdjs.BattleCode.GDWObjects1.length = 0;
gdjs.BattleCode.GDWObjects2.length = 0;
gdjs.BattleCode.GDWObjects3.length = 0;
gdjs.BattleCode.GDWObjects4.length = 0;
gdjs.BattleCode.GDWObjects5.length = 0;
gdjs.BattleCode.GDWObjects6.length = 0;
gdjs.BattleCode.GDWObjects7.length = 0;
gdjs.BattleCode.GDWObjects8.length = 0;
gdjs.BattleCode.GDSObjects1.length = 0;
gdjs.BattleCode.GDSObjects2.length = 0;
gdjs.BattleCode.GDSObjects3.length = 0;
gdjs.BattleCode.GDSObjects4.length = 0;
gdjs.BattleCode.GDSObjects5.length = 0;
gdjs.BattleCode.GDSObjects6.length = 0;
gdjs.BattleCode.GDSObjects7.length = 0;
gdjs.BattleCode.GDSObjects8.length = 0;
gdjs.BattleCode.GDAObjects1.length = 0;
gdjs.BattleCode.GDAObjects2.length = 0;
gdjs.BattleCode.GDAObjects3.length = 0;
gdjs.BattleCode.GDAObjects4.length = 0;
gdjs.BattleCode.GDAObjects5.length = 0;
gdjs.BattleCode.GDAObjects6.length = 0;
gdjs.BattleCode.GDAObjects7.length = 0;
gdjs.BattleCode.GDAObjects8.length = 0;
gdjs.BattleCode.GDDObjects1.length = 0;
gdjs.BattleCode.GDDObjects2.length = 0;
gdjs.BattleCode.GDDObjects3.length = 0;
gdjs.BattleCode.GDDObjects4.length = 0;
gdjs.BattleCode.GDDObjects5.length = 0;
gdjs.BattleCode.GDDObjects6.length = 0;
gdjs.BattleCode.GDDObjects7.length = 0;
gdjs.BattleCode.GDDObjects8.length = 0;
gdjs.BattleCode.GDArrowObjects1.length = 0;
gdjs.BattleCode.GDArrowObjects2.length = 0;
gdjs.BattleCode.GDArrowObjects3.length = 0;
gdjs.BattleCode.GDArrowObjects4.length = 0;
gdjs.BattleCode.GDArrowObjects5.length = 0;
gdjs.BattleCode.GDArrowObjects6.length = 0;
gdjs.BattleCode.GDArrowObjects7.length = 0;
gdjs.BattleCode.GDArrowObjects8.length = 0;
gdjs.BattleCode.GDTextMoveBlocksObjects1.length = 0;
gdjs.BattleCode.GDTextMoveBlocksObjects2.length = 0;
gdjs.BattleCode.GDTextMoveBlocksObjects3.length = 0;
gdjs.BattleCode.GDTextMoveBlocksObjects4.length = 0;
gdjs.BattleCode.GDTextMoveBlocksObjects5.length = 0;
gdjs.BattleCode.GDTextMoveBlocksObjects6.length = 0;
gdjs.BattleCode.GDTextMoveBlocksObjects7.length = 0;
gdjs.BattleCode.GDTextMoveBlocksObjects8.length = 0;
gdjs.BattleCode.GDAimObjects1.length = 0;
gdjs.BattleCode.GDAimObjects2.length = 0;
gdjs.BattleCode.GDAimObjects3.length = 0;
gdjs.BattleCode.GDAimObjects4.length = 0;
gdjs.BattleCode.GDAimObjects5.length = 0;
gdjs.BattleCode.GDAimObjects6.length = 0;
gdjs.BattleCode.GDAimObjects7.length = 0;
gdjs.BattleCode.GDAimObjects8.length = 0;
gdjs.BattleCode.GDKeyObjects1.length = 0;
gdjs.BattleCode.GDKeyObjects2.length = 0;
gdjs.BattleCode.GDKeyObjects3.length = 0;
gdjs.BattleCode.GDKeyObjects4.length = 0;
gdjs.BattleCode.GDKeyObjects5.length = 0;
gdjs.BattleCode.GDKeyObjects6.length = 0;
gdjs.BattleCode.GDKeyObjects7.length = 0;
gdjs.BattleCode.GDKeyObjects8.length = 0;
gdjs.BattleCode.GDBlockAreaBorderLeftObjects1.length = 0;
gdjs.BattleCode.GDBlockAreaBorderLeftObjects2.length = 0;
gdjs.BattleCode.GDBlockAreaBorderLeftObjects3.length = 0;
gdjs.BattleCode.GDBlockAreaBorderLeftObjects4.length = 0;
gdjs.BattleCode.GDBlockAreaBorderLeftObjects5.length = 0;
gdjs.BattleCode.GDBlockAreaBorderLeftObjects6.length = 0;
gdjs.BattleCode.GDBlockAreaBorderLeftObjects7.length = 0;
gdjs.BattleCode.GDBlockAreaBorderLeftObjects8.length = 0;
gdjs.BattleCode.GDButtonPlayAgainObjects1.length = 0;
gdjs.BattleCode.GDButtonPlayAgainObjects2.length = 0;
gdjs.BattleCode.GDButtonPlayAgainObjects3.length = 0;
gdjs.BattleCode.GDButtonPlayAgainObjects4.length = 0;
gdjs.BattleCode.GDButtonPlayAgainObjects5.length = 0;
gdjs.BattleCode.GDButtonPlayAgainObjects6.length = 0;
gdjs.BattleCode.GDButtonPlayAgainObjects7.length = 0;
gdjs.BattleCode.GDButtonPlayAgainObjects8.length = 0;

gdjs.BattleCode.eventsList88(runtimeScene);
return;

}

gdjs['BattleCode'] = gdjs.BattleCode;
