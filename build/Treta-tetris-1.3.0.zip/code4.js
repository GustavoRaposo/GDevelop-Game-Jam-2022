gdjs.CreditsCode = {};
gdjs.CreditsCode.GDBulletObjects1= [];
gdjs.CreditsCode.GDBulletObjects2= [];
gdjs.CreditsCode.GDBlockCannonObjects1= [];
gdjs.CreditsCode.GDBlockCannonObjects2= [];
gdjs.CreditsCode.GDCannonAimObjects1= [];
gdjs.CreditsCode.GDCannonAimObjects2= [];
gdjs.CreditsCode.GDtileBackgroungObjects1= [];
gdjs.CreditsCode.GDtileBackgroungObjects2= [];
gdjs.CreditsCode.GDGlobalLightObjects1= [];
gdjs.CreditsCode.GDGlobalLightObjects2= [];
gdjs.CreditsCode.GDCoreLightPlayer2Objects1= [];
gdjs.CreditsCode.GDCoreLightPlayer2Objects2= [];
gdjs.CreditsCode.GDCoreLightPlayer1Objects1= [];
gdjs.CreditsCode.GDCoreLightPlayer1Objects2= [];
gdjs.CreditsCode.GDMusicTitleObjects1= [];
gdjs.CreditsCode.GDMusicTitleObjects2= [];
gdjs.CreditsCode.GDMusicObjects1= [];
gdjs.CreditsCode.GDMusicObjects2= [];
gdjs.CreditsCode.GDDevelopersObjects1= [];
gdjs.CreditsCode.GDDevelopersObjects2= [];
gdjs.CreditsCode.GDThanksObjects1= [];
gdjs.CreditsCode.GDThanksObjects2= [];
gdjs.CreditsCode.GDDevelopersTitleObjects1= [];
gdjs.CreditsCode.GDDevelopersTitleObjects2= [];

gdjs.CreditsCode.conditionTrue_0 = {val:false};
gdjs.CreditsCode.condition0IsTrue_0 = {val:false};
gdjs.CreditsCode.condition1IsTrue_0 = {val:false};


gdjs.CreditsCode.eventsList0 = function(runtimeScene) {

{

/* Reuse gdjs.CreditsCode.GDMusicObjects1 */

gdjs.CreditsCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.CreditsCode.GDMusicObjects1.length;i<l;++i) {
    if ( gdjs.CreditsCode.GDMusicObjects1[i].getAABBBottom() <= 0 ) {
        gdjs.CreditsCode.condition0IsTrue_0.val = true;
        gdjs.CreditsCode.GDMusicObjects1[k] = gdjs.CreditsCode.GDMusicObjects1[i];
        ++k;
    }
}
gdjs.CreditsCode.GDMusicObjects1.length = k;}if (gdjs.CreditsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.CreditsCode.GDDevelopersObjects1 */
/* Reuse gdjs.CreditsCode.GDDevelopersTitleObjects1 */
/* Reuse gdjs.CreditsCode.GDMusicObjects1 */
/* Reuse gdjs.CreditsCode.GDMusicTitleObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Thanks"), gdjs.CreditsCode.GDThanksObjects1);
{for(var i = 0, len = gdjs.CreditsCode.GDMusicTitleObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDMusicTitleObjects1[i].removeTimer("credits");
}
for(var i = 0, len = gdjs.CreditsCode.GDMusicObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDMusicObjects1[i].removeTimer("credits");
}
for(var i = 0, len = gdjs.CreditsCode.GDDevelopersObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDDevelopersObjects1[i].removeTimer("credits");
}
for(var i = 0, len = gdjs.CreditsCode.GDDevelopersTitleObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDDevelopersTitleObjects1[i].removeTimer("credits");
}
}{for(var i = 0, len = gdjs.CreditsCode.GDThanksObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDThanksObjects1[i].resetTimer("thaks");
}
}}

}


};gdjs.CreditsCode.eventsList1 = function(runtimeScene) {

{

/* Reuse gdjs.CreditsCode.GDThanksObjects1 */

gdjs.CreditsCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.CreditsCode.GDThanksObjects1.length;i<l;++i) {
    if ( gdjs.CreditsCode.GDThanksObjects1[i].getAABBBottom() <= 0 ) {
        gdjs.CreditsCode.condition0IsTrue_0.val = true;
        gdjs.CreditsCode.GDThanksObjects1[k] = gdjs.CreditsCode.GDThanksObjects1[i];
        ++k;
    }
}
gdjs.CreditsCode.GDThanksObjects1.length = k;}if (gdjs.CreditsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.CreditsCode.eventsList2 = function(runtimeScene) {

{


gdjs.CreditsCode.condition0IsTrue_0.val = false;
{
gdjs.CreditsCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.CreditsCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Developers"), gdjs.CreditsCode.GDDevelopersObjects1);
gdjs.copyArray(runtimeScene.getObjects("DevelopersTitle"), gdjs.CreditsCode.GDDevelopersTitleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Music"), gdjs.CreditsCode.GDMusicObjects1);
gdjs.copyArray(runtimeScene.getObjects("MusicTitle"), gdjs.CreditsCode.GDMusicTitleObjects1);
{for(var i = 0, len = gdjs.CreditsCode.GDMusicTitleObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDMusicTitleObjects1[i].resetTimer("credits");
}
for(var i = 0, len = gdjs.CreditsCode.GDMusicObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDMusicObjects1[i].resetTimer("credits");
}
for(var i = 0, len = gdjs.CreditsCode.GDDevelopersObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDDevelopersObjects1[i].resetTimer("credits");
}
for(var i = 0, len = gdjs.CreditsCode.GDDevelopersTitleObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDDevelopersTitleObjects1[i].resetTimer("credits");
}
}{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "assets\\sound\\music\\Techno-Celebration-Looping.mp3", 1, false, 20, 1);
}}

}


{


gdjs.CreditsCode.condition0IsTrue_0.val = false;
{
gdjs.CreditsCode.condition0IsTrue_0.val = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
}if (gdjs.CreditsCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Developers"), gdjs.CreditsCode.GDDevelopersObjects1);
gdjs.copyArray(runtimeScene.getObjects("DevelopersTitle"), gdjs.CreditsCode.GDDevelopersTitleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Music"), gdjs.CreditsCode.GDMusicObjects1);
gdjs.copyArray(runtimeScene.getObjects("MusicTitle"), gdjs.CreditsCode.GDMusicTitleObjects1);

gdjs.CreditsCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.CreditsCode.GDMusicTitleObjects1.length;i<l;++i) {
    if ( gdjs.CreditsCode.GDMusicTitleObjects1[i].getTimerElapsedTimeInSecondsOrNaN("credits") >= 0.5 ) {
        gdjs.CreditsCode.condition0IsTrue_0.val = true;
        gdjs.CreditsCode.GDMusicTitleObjects1[k] = gdjs.CreditsCode.GDMusicTitleObjects1[i];
        ++k;
    }
}
gdjs.CreditsCode.GDMusicTitleObjects1.length = k;for(var i = 0, k = 0, l = gdjs.CreditsCode.GDMusicObjects1.length;i<l;++i) {
    if ( gdjs.CreditsCode.GDMusicObjects1[i].getTimerElapsedTimeInSecondsOrNaN("credits") >= 0.5 ) {
        gdjs.CreditsCode.condition0IsTrue_0.val = true;
        gdjs.CreditsCode.GDMusicObjects1[k] = gdjs.CreditsCode.GDMusicObjects1[i];
        ++k;
    }
}
gdjs.CreditsCode.GDMusicObjects1.length = k;for(var i = 0, k = 0, l = gdjs.CreditsCode.GDDevelopersObjects1.length;i<l;++i) {
    if ( gdjs.CreditsCode.GDDevelopersObjects1[i].getTimerElapsedTimeInSecondsOrNaN("credits") >= 0.5 ) {
        gdjs.CreditsCode.condition0IsTrue_0.val = true;
        gdjs.CreditsCode.GDDevelopersObjects1[k] = gdjs.CreditsCode.GDDevelopersObjects1[i];
        ++k;
    }
}
gdjs.CreditsCode.GDDevelopersObjects1.length = k;for(var i = 0, k = 0, l = gdjs.CreditsCode.GDDevelopersTitleObjects1.length;i<l;++i) {
    if ( gdjs.CreditsCode.GDDevelopersTitleObjects1[i].getTimerElapsedTimeInSecondsOrNaN("credits") >= 0.5 ) {
        gdjs.CreditsCode.condition0IsTrue_0.val = true;
        gdjs.CreditsCode.GDDevelopersTitleObjects1[k] = gdjs.CreditsCode.GDDevelopersTitleObjects1[i];
        ++k;
    }
}
gdjs.CreditsCode.GDDevelopersTitleObjects1.length = k;}if (gdjs.CreditsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.CreditsCode.GDDevelopersObjects1 */
/* Reuse gdjs.CreditsCode.GDDevelopersTitleObjects1 */
/* Reuse gdjs.CreditsCode.GDMusicObjects1 */
/* Reuse gdjs.CreditsCode.GDMusicTitleObjects1 */
{for(var i = 0, len = gdjs.CreditsCode.GDMusicTitleObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDMusicTitleObjects1[i].setY(gdjs.CreditsCode.GDMusicTitleObjects1[i].getY() - (16));
}
for(var i = 0, len = gdjs.CreditsCode.GDMusicObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDMusicObjects1[i].setY(gdjs.CreditsCode.GDMusicObjects1[i].getY() - (16));
}
for(var i = 0, len = gdjs.CreditsCode.GDDevelopersObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDDevelopersObjects1[i].setY(gdjs.CreditsCode.GDDevelopersObjects1[i].getY() - (16));
}
for(var i = 0, len = gdjs.CreditsCode.GDDevelopersTitleObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDDevelopersTitleObjects1[i].setY(gdjs.CreditsCode.GDDevelopersTitleObjects1[i].getY() - (16));
}
}{for(var i = 0, len = gdjs.CreditsCode.GDMusicTitleObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDMusicTitleObjects1[i].resetTimer("credits");
}
for(var i = 0, len = gdjs.CreditsCode.GDMusicObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDMusicObjects1[i].resetTimer("credits");
}
for(var i = 0, len = gdjs.CreditsCode.GDDevelopersObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDDevelopersObjects1[i].resetTimer("credits");
}
for(var i = 0, len = gdjs.CreditsCode.GDDevelopersTitleObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDDevelopersTitleObjects1[i].resetTimer("credits");
}
}
{ //Subevents
gdjs.CreditsCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Thanks"), gdjs.CreditsCode.GDThanksObjects1);

gdjs.CreditsCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.CreditsCode.GDThanksObjects1.length;i<l;++i) {
    if ( gdjs.CreditsCode.GDThanksObjects1[i].getTimerElapsedTimeInSecondsOrNaN("thaks") >= 0.4 ) {
        gdjs.CreditsCode.condition0IsTrue_0.val = true;
        gdjs.CreditsCode.GDThanksObjects1[k] = gdjs.CreditsCode.GDThanksObjects1[i];
        ++k;
    }
}
gdjs.CreditsCode.GDThanksObjects1.length = k;}if (gdjs.CreditsCode.condition0IsTrue_0.val) {
/* Reuse gdjs.CreditsCode.GDThanksObjects1 */
{for(var i = 0, len = gdjs.CreditsCode.GDThanksObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDThanksObjects1[i].setY(gdjs.CreditsCode.GDThanksObjects1[i].getY() - (16));
}
}{for(var i = 0, len = gdjs.CreditsCode.GDThanksObjects1.length ;i < len;++i) {
    gdjs.CreditsCode.GDThanksObjects1[i].resetTimer("thaks");
}
}
{ //Subevents
gdjs.CreditsCode.eventsList1(runtimeScene);} //End of subevents
}

}


};

gdjs.CreditsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.CreditsCode.GDBulletObjects1.length = 0;
gdjs.CreditsCode.GDBulletObjects2.length = 0;
gdjs.CreditsCode.GDBlockCannonObjects1.length = 0;
gdjs.CreditsCode.GDBlockCannonObjects2.length = 0;
gdjs.CreditsCode.GDCannonAimObjects1.length = 0;
gdjs.CreditsCode.GDCannonAimObjects2.length = 0;
gdjs.CreditsCode.GDtileBackgroungObjects1.length = 0;
gdjs.CreditsCode.GDtileBackgroungObjects2.length = 0;
gdjs.CreditsCode.GDGlobalLightObjects1.length = 0;
gdjs.CreditsCode.GDGlobalLightObjects2.length = 0;
gdjs.CreditsCode.GDCoreLightPlayer2Objects1.length = 0;
gdjs.CreditsCode.GDCoreLightPlayer2Objects2.length = 0;
gdjs.CreditsCode.GDCoreLightPlayer1Objects1.length = 0;
gdjs.CreditsCode.GDCoreLightPlayer1Objects2.length = 0;
gdjs.CreditsCode.GDMusicTitleObjects1.length = 0;
gdjs.CreditsCode.GDMusicTitleObjects2.length = 0;
gdjs.CreditsCode.GDMusicObjects1.length = 0;
gdjs.CreditsCode.GDMusicObjects2.length = 0;
gdjs.CreditsCode.GDDevelopersObjects1.length = 0;
gdjs.CreditsCode.GDDevelopersObjects2.length = 0;
gdjs.CreditsCode.GDThanksObjects1.length = 0;
gdjs.CreditsCode.GDThanksObjects2.length = 0;
gdjs.CreditsCode.GDDevelopersTitleObjects1.length = 0;
gdjs.CreditsCode.GDDevelopersTitleObjects2.length = 0;

gdjs.CreditsCode.eventsList2(runtimeScene);
return;

}

gdjs['CreditsCode'] = gdjs.CreditsCode;
