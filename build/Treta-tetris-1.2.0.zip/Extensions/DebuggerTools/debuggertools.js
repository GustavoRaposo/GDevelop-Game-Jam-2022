var gdjs;(function(n){let c;(function(r){let p;(function(a){a.pause=function(e){e.getGame().pause(!0)},a.log=function(e,t,o){n.Logger.getLoggerOutput().log(o,e,t,!1)},a.enableDebugDraw=function(e,t,o,i,u){e.enableDebugDraw(t,o,i,u)}})(p=r.debuggerTools||(r.debuggerTools={}))})(c=n.evtTools||(n.evtTools={}))})(gdjs||(gdjs={}));
//# sourceMappingURL=debuggertools.js.map
